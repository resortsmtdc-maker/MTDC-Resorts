function e(t) {
    var n, r, i = ``;
    if (typeof t == `string` || typeof t == `number`) i += t;
    else if (typeof t == `object`) {
        if (Array.isArray(t)) {
            var a = t.length;
            for (n = 0; n < a; n++) t[n] && (r = e(t[n])) && (i && (i += ` `), i += r)
        } else
            for (r in t) t[r] && (i && (i += ` `), i += r)
    }
    return i
}

function t() {
    for (var t, n, r = 0, i = ``, a = arguments.length; r < a; r++)(t = arguments[r]) && (n = e(t)) && (i && (i += ` `), i += n);
    return i
}
var n = (e, t) => {
        let n = Array(e.length + t.length);
        for (let t = 0; t < e.length; t++) n[t] = e[t];
        for (let r = 0; r < t.length; r++) n[e.length + r] = t[r];
        return n
    },
    r = (e, t) => ({
        classGroupId: e,
        validator: t
    }),
    i = (e = new Map, t = null, n) => ({
        nextPart: e,
        validators: t,
        classGroupId: n
    }),
    a = `-`,
    o = [],
    s = `arbitrary..`,
    c = e => {
        let t = d(e),
            {
                conflictingClassGroups: r,
                conflictingClassGroupModifiers: i
            } = e;
        return {
            getClassGroupId: e => {
                if (e.startsWith(`[`) && e.endsWith(`]`)) return u(e);
                let n = e.split(a);
                return l(n, +(n[0] === `` && n.length > 1), t)
            },
            getConflictingClassGroupIds: (e, t) => {
                if (t) {
                    let t = i[e],
                        a = r[e];
                    return t ? a ? n(a, t) : t : a || o
                }
                return r[e] || o
            }
        }
    },
    l = (e, t, n) => {
        if (e.length - t === 0) return n.classGroupId;
        let r = e[t],
            i = n.nextPart.get(r);
        if (i) {
            let n = l(e, t + 1, i);
            if (n) return n
        }
        let o = n.validators;
        if (o === null) return;
        let s = t === 0 ? e.join(a) : e.slice(t).join(a),
            c = o.length;
        for (let e = 0; e < c; e++) {
            let t = o[e];
            if (t.validator(s)) return t.classGroupId
        }
    },
    u = e => e.slice(1, -1).indexOf(`:`) === -1 ? void 0 : (() => {
        let t = e.slice(1, -1),
            n = t.indexOf(`:`),
            r = t.slice(0, n);
        return r ? s + r : void 0
    })(),
    d = e => {
        let {
            theme: t,
            classGroups: n
        } = e;
        return ee(n, t)
    },
    ee = (e, t) => {
        let n = i();
        for (let r in e) {
            let i = e[r];
            f(i, n, r, t)
        }
        return n
    },
    f = (e, t, n, r) => {
        let i = e.length;
        for (let a = 0; a < i; a++) {
            let i = e[a];
            p(i, t, n, r)
        }
    },
    p = (e, t, n, r) => {
        if (typeof e == `string`) {
            m(e, t, n);
            return
        }
        if (typeof e == `function`) {
            h(e, t, n, r);
            return
        }
        g(e, t, n, r)
    },
    m = (e, t, n) => {
        let r = e === `` ? t : _(t, e);
        r.classGroupId = n
    },
    h = (e, t, n, i) => {
        if (v(e)) {
            f(e(i), t, n, i);
            return
        }
        t.validators === null && (t.validators = []), t.validators.push(r(n, e))
    },
    g = (e, t, n, r) => {
        let i = Object.entries(e),
            a = i.length;
        for (let e = 0; e < a; e++) {
            let [a, o] = i[e];
            f(o, _(t, a), n, r)
        }
    },
    _ = (e, t) => {
        let n = e,
            r = t.split(a),
            o = r.length;
        for (let e = 0; e < o; e++) {
            let t = r[e],
                a = n.nextPart.get(t);
            a || (a = i(), n.nextPart.set(t, a)), n = a
        }
        return n
    },
    v = e => `isThemeGetter` in e && e.isThemeGetter === !0,
    y = e => {
        if (e < 1) return {
            get: () => void 0,
            set: () => {}
        };
        let t = 0,
            n = Object.create(null),
            r = Object.create(null),
            i = (i, a) => {
                n[i] = a, t++, t > e && (t = 0, r = n, n = Object.create(null))
            };
        return {
            get(e) {
                let t = n[e];
                if (t !== void 0) return t;
                if ((t = r[e]) !== void 0) return i(e, t), t
            },
            set(e, t) {
                e in n ? n[e] = t : i(e, t)
            }
        }
    },
    b = `!`,
    x = `:`,
    S = [],
    C = (e, t, n, r, i) => ({
        modifiers: e,
        hasImportantModifier: t,
        baseClassName: n,
        maybePostfixModifierPosition: r,
        isExternal: i
    }),
    w = e => {
        let {
            prefix: t,
            experimentalParseClassName: n
        } = e, r = e => {
            let t = [],
                n = 0,
                r = 0,
                i = 0,
                a, o = e.length;
            for (let s = 0; s < o; s++) {
                let o = e[s];
                if (n === 0 && r === 0) {
                    if (o === x) {
                        t.push(e.slice(i, s)), i = s + 1;
                        continue
                    }
                    if (o === `/`) {
                        a = s;
                        continue
                    }
                }
                o === `[` ? n++ : o === `]` ? n-- : o === `(` ? r++ : o === `)` && r--
            }
            let s = t.length === 0 ? e : e.slice(i),
                c = s,
                l = !1;
            s.endsWith(b) ? (c = s.slice(0, -1), l = !0) : s.startsWith(b) && (c = s.slice(1), l = !0);
            let u = a && a > i ? a - i : void 0;
            return C(t, l, c, u)
        };
        if (t) {
            let e = t + x,
                n = r;
            r = t => t.startsWith(e) ? n(t.slice(e.length)) : C(S, !1, t, void 0, !0)
        }
        if (n) {
            let e = r;
            r = t => n({
                className: t,
                parseClassName: e
            })
        }
        return r
    },
    te = e => {
        let t = new Map;
        return e.orderSensitiveModifiers.forEach((e, n) => {
            t.set(e, 1e6 + n)
        }), e => {
            let n = [],
                r = [];
            for (let i = 0; i < e.length; i++) {
                let a = e[i],
                    o = a[0] === `[`,
                    s = t.has(a);
                o || s ? (r.length > 0 && (r.sort(), n.push(...r), r = []), n.push(a)) : r.push(a)
            }
            return r.length > 0 && (r.sort(), n.push(...r)), n
        }
    },
    ne = e => ({
        cache: y(e.cacheSize),
        parseClassName: w(e),
        sortModifiers: te(e),
        postfixLookupClassGroupIds: T(e),
        ...c(e)
    }),
    T = e => {
        let t = Object.create(null),
            n = e.postfixLookupClassGroups;
        if (n)
            for (let e = 0; e < n.length; e++) t[n[e]] = !0;
        return t
    },
    re = /\s+/,
    E = (e, t) => {
        let {
            parseClassName: n,
            getClassGroupId: r,
            getConflictingClassGroupIds: i,
            sortModifiers: a,
            postfixLookupClassGroupIds: o
        } = t, s = [], c = e.trim().split(re), l = ``;
        for (let e = c.length - 1; e >= 0; --e) {
            let t = c[e],
                {
                    isExternal: u,
                    modifiers: d,
                    hasImportantModifier: ee,
                    baseClassName: f,
                    maybePostfixModifierPosition: p
                } = n(t);
            if (u) {
                l = t + (l.length > 0 ? ` ` + l : l);
                continue
            }
            let m = !!p,
                h;
            if (m) {
                h = r(f.substring(0, p));
                let e = h && o[h] ? r(f) : void 0;
                e && e !== h && (h = e, m = !1)
            } else h = r(f);
            if (!h) {
                if (!m) {
                    l = t + (l.length > 0 ? ` ` + l : l);
                    continue
                }
                if (h = r(f), !h) {
                    l = t + (l.length > 0 ? ` ` + l : l);
                    continue
                }
                m = !1
            }
            let g = d.length === 0 ? `` : d.length === 1 ? d[0] : a(d).join(`:`),
                _ = ee ? g + b : g,
                v = _ + h;
            if (s.indexOf(v) > -1) continue;
            s.push(v);
            let y = i(h, m);
            for (let e = 0; e < y.length; ++e) {
                let t = y[e];
                s.push(_ + t)
            }
            l = t + (l.length > 0 ? ` ` + l : l)
        }
        return l
    },
    D = (...e) => {
        let t = 0,
            n, r, i = ``;
        for (; t < e.length;)(n = e[t++]) && (r = O(n)) && (i && (i += ` `), i += r);
        return i
    },
    O = e => {
        if (typeof e == `string`) return e;
        let t, n = ``;
        for (let r = 0; r < e.length; r++) e[r] && (t = O(e[r])) && (n && (n += ` `), n += t);
        return n
    },
    k = (e, ...t) => {
        let n, r, i, a, o = o => (n = ne(t.reduce((e, t) => t(e), e())), r = n.cache.get, i = n.cache.set, a = s, s(o)),
            s = e => {
                let t = r(e);
                if (t) return t;
                let a = E(e, n);
                return i(e, a), a
            };
        return a = o, (...e) => a(D(...e))
    },
    A = [],
    j = e => {
        let t = t => t[e] || A;
        return t.isThemeGetter = !0, t
    },
    M = /^\[(?:(\w[\w-]*):)?(.+)\]$/i,
    N = /^\((?:(\w[\w-]*):)?(.+)\)$/i,
    ie = /^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/,
    ae = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,
    oe = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,
    P = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/,
    F = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,
    I = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,
    L = e => ie.test(e),
    R = e => !!e && !Number.isNaN(Number(e)),
    z = e => !!e && Number.isInteger(Number(e)),
    se = e => e.endsWith(`%`) && R(e.slice(0, -1)),
    B = e => ae.test(e),
    ce = () => !0,
    V = e => oe.test(e) && !P.test(e),
    H = () => !1,
    U = e => F.test(e),
    le = e => I.test(e),
    ue = e => !W(e) && !q(e),
    de = e => e.startsWith(`@container`) && (e[10] === `/` && e[11] !== void 0 || e[11] === `s` && e[16] !== void 0 && e.startsWith(`-size/`, 10) || e[11] === `n` && e[18] !== void 0 && e.startsWith(`-normal/`, 10)),
    fe = e => X(e, Ce, H),
    W = e => M.test(e),
    G = e => X(e, we, V),
    pe = e => X(e, Te, R),
    me = e => X(e, De, ce),
    he = e => X(e, Ee, H),
    ge = e => X(e, Q, H),
    _e = e => X(e, $, le),
    K = e => X(e, Oe, U),
    q = e => N.test(e),
    J = e => Z(e, we),
    ve = e => Z(e, Ee),
    ye = e => Z(e, Q),
    be = e => Z(e, Ce),
    xe = e => Z(e, $),
    Y = e => Z(e, Oe, !0),
    Se = e => Z(e, De, !0),
    X = (e, t, n) => {
        let r = M.exec(e);
        return r ? r[1] ? t(r[1]) : n(r[2]) : !1
    },
    Z = (e, t, n = !1) => {
        let r = N.exec(e);
        return r ? r[1] ? t(r[1]) : n : !1
    },
    Q = e => e === `position` || e === `percentage`,
    $ = e => e === `image` || e === `url`,
    Ce = e => e === `length` || e === `size` || e === `bg-size`,
    we = e => e === `length`,
    Te = e => e === `number`,
    Ee = e => e === `family-name`,
    De = e => e === `number` || e === `weight`,
    Oe = e => e === `shadow`,
    ke = k(() => {
        let e = j(`color`),
            t = j(`font`),
            n = j(`text`),
            r = j(`font-weight`),
            i = j(`tracking`),
            a = j(`leading`),
            o = j(`breakpoint`),
            s = j(`container`),
            c = j(`spacing`),
            l = j(`radius`),
            u = j(`shadow`),
            d = j(`inset-shadow`),
            ee = j(`text-shadow`),
            f = j(`drop-shadow`),
            p = j(`blur`),
            m = j(`perspective`),
            h = j(`aspect`),
            g = j(`ease`),
            _ = j(`animate`),
            v = () => [`auto`, `avoid`, `all`, `avoid-page`, `page`, `left`, `right`, `column`],
            y = () => [`center`, `top`, `bottom`, `left`, `right`, `top-left`, `left-top`, `top-right`, `right-top`, `bottom-right`, `right-bottom`, `bottom-left`, `left-bottom`],
            b = () => [...y(), q, W],
            x = () => [`auto`, `hidden`, `clip`, `visible`, `scroll`],
            S = () => [`auto`, `contain`, `none`],
            C = () => [q, W, c],
            w = () => [L, `full`, `auto`, ...C()],
            te = () => [z, `none`, `subgrid`, q, W],
            ne = () => [`auto`, {
                span: [`full`, z, q, W]
            }, z, q, W],
            T = () => [z, `auto`, q, W],
            re = () => [`auto`, `min`, `max`, `fr`, q, W],
            E = () => [`start`, `end`, `center`, `between`, `around`, `evenly`, `stretch`, `baseline`, `center-safe`, `end-safe`],
            D = () => [`start`, `end`, `center`, `stretch`, `center-safe`, `end-safe`],
            O = () => [`auto`, ...C()],
            k = () => [L, `auto`, `full`, `dvw`, `dvh`, `lvw`, `lvh`, `svw`, `svh`, `min`, `max`, `fit`, ...C()],
            A = () => [L, `screen`, `full`, `dvw`, `lvw`, `svw`, `min`, `max`, `fit`, ...C()],
            M = () => [L, `screen`, `full`, `lh`, `dvh`, `lvh`, `svh`, `min`, `max`, `fit`, ...C()],
            N = () => [e, q, W],
            ie = () => [...y(), ye, ge, {
                position: [q, W]
            }],
            ae = () => [`no-repeat`, {
                repeat: [``, `x`, `y`, `space`, `round`]
            }],
            oe = () => [`auto`, `cover`, `contain`, be, fe, {
                size: [q, W]
            }],
            P = () => [se, J, G],
            F = () => [``, `none`, `full`, l, q, W],
            I = () => [``, R, J, G],
            V = () => [`solid`, `dashed`, `dotted`, `double`],
            H = () => [`normal`, `multiply`, `screen`, `overlay`, `darken`, `lighten`, `color-dodge`, `color-burn`, `hard-light`, `soft-light`, `difference`, `exclusion`, `hue`, `saturation`, `color`, `luminosity`],
            U = () => [R, se, ye, ge],
            le = () => [``, `none`, p, q, W],
            X = () => [`none`, R, q, W],
            Z = () => [`none`, R, q, W],
            Q = () => [R, q, W],
            $ = () => [L, `full`, ...C()];
        return {
            cacheSize: 500,
            theme: {
                animate: [`spin`, `ping`, `pulse`, `bounce`],
                aspect: [`video`],
                blur: [B],
                breakpoint: [B],
                color: [ce],
                container: [B],
                "drop-shadow": [B],
                ease: [`in`, `out`, `in-out`],
                font: [ue],
                "font-weight": [`thin`, `extralight`, `light`, `normal`, `medium`, `semibold`, `bold`, `extrabold`, `black`],
                "inset-shadow": [B],
                leading: [`none`, `tight`, `snug`, `normal`, `relaxed`, `loose`],
                perspective: [`dramatic`, `near`, `normal`, `midrange`, `distant`, `none`],
                radius: [B],
                shadow: [B],
                spacing: [`px`, R],
                text: [B],
                "text-shadow": [B],
                tracking: [`tighter`, `tight`, `normal`, `wide`, `wider`, `widest`]
            },
            classGroups: {
                aspect: [{
                    aspect: [`auto`, `square`, L, W, q, h]
                }],
                container: [`container`],
                "container-type": [{
                    "@container": [``, `normal`, `size`, q, W]
                }],
                "container-named": [de],
                columns: [{
                    columns: [R, W, q, s]
                }],
                "break-after": [{
                    "break-after": v()
                }],
                "break-before": [{
                    "break-before": v()
                }],
                "break-inside": [{
                    "break-inside": [`auto`, `avoid`, `avoid-page`, `avoid-column`]
                }],
                "box-decoration": [{
                    "box-decoration": [`slice`, `clone`]
                }],
                box: [{
                    box: [`border`, `content`]
                }],
                display: [`block`, `inline-block`, `inline`, `flex`, `inline-flex`, `table`, `inline-table`, `table-caption`, `table-cell`, `table-column`, `table-column-group`, `table-footer-group`, `table-header-group`, `table-row-group`, `table-row`, `flow-root`, `grid`, `inline-grid`, `contents`, `list-item`, `hidden`],
                sr: [`sr-only`, `not-sr-only`],
                float: [{
                    float: [`right`, `left`, `none`, `start`, `end`]
                }],
                clear: [{
                    clear: [`left`, `right`, `both`, `none`, `start`, `end`]
                }],
                isolation: [`isolate`, `isolation-auto`],
                "object-fit": [{
                    object: [`contain`, `cover`, `fill`, `none`, `scale-down`]
                }],
                "object-position": [{
                    object: b()
                }],
                overflow: [{
                    overflow: x()
                }],
                "overflow-x": [{
                    "overflow-x": x()
                }],
                "overflow-y": [{
                    "overflow-y": x()
                }],
                overscroll: [{
                    overscroll: S()
                }],
                "overscroll-x": [{
                    "overscroll-x": S()
                }],
                "overscroll-y": [{
                    "overscroll-y": S()
                }],
                position: [`static`, `fixed`, `absolute`, `relative`, `sticky`],
                inset: [{
                    inset: w()
                }],
                "inset-x": [{
                    "inset-x": w()
                }],
                "inset-y": [{
                    "inset-y": w()
                }],
                start: [{
                    "inset-s": w(),
                    start: w()
                }],
                end: [{
                    "inset-e": w(),
                    end: w()
                }],
                "inset-bs": [{
                    "inset-bs": w()
                }],
                "inset-be": [{
                    "inset-be": w()
                }],
                top: [{
                    top: w()
                }],
                right: [{
                    right: w()
                }],
                bottom: [{
                    bottom: w()
                }],
                left: [{
                    left: w()
                }],
                visibility: [`visible`, `invisible`, `collapse`],
                z: [{
                    z: [z, `auto`, q, W]
                }],
                basis: [{
                    basis: [L, `full`, `auto`, s, ...C()]
                }],
                "flex-direction": [{
                    flex: [`row`, `row-reverse`, `col`, `col-reverse`]
                }],
                "flex-wrap": [{
                    flex: [`nowrap`, `wrap`, `wrap-reverse`]
                }],
                flex: [{
                    flex: [R, L, `auto`, `initial`, `none`, W]
                }],
                grow: [{
                    grow: [``, R, q, W]
                }],
                shrink: [{
                    shrink: [``, R, q, W]
                }],
                order: [{
                    order: [z, `first`, `last`, `none`, q, W]
                }],
                "grid-cols": [{
                    "grid-cols": te()
                }],
                "col-start-end": [{
                    col: ne()
                }],
                "col-start": [{
                    "col-start": T()
                }],
                "col-end": [{
                    "col-end": T()
                }],
                "grid-rows": [{
                    "grid-rows": te()
                }],
                "row-start-end": [{
                    row: ne()
                }],
                "row-start": [{
                    "row-start": T()
                }],
                "row-end": [{
                    "row-end": T()
                }],
                "grid-flow": [{
                    "grid-flow": [`row`, `col`, `dense`, `row-dense`, `col-dense`]
                }],
                "auto-cols": [{
                    "auto-cols": re()
                }],
                "auto-rows": [{
                    "auto-rows": re()
                }],
                gap: [{
                    gap: C()
                }],
                "gap-x": [{
                    "gap-x": C()
                }],
                "gap-y": [{
                    "gap-y": C()
                }],
                "justify-content": [{
                    justify: [...E(), `normal`]
                }],
                "justify-items": [{
                    "justify-items": [...D(), `normal`]
                }],
                "justify-self": [{
                    "justify-self": [`auto`, ...D()]
                }],
                "align-content": [{
                    content: [`normal`, ...E()]
                }],
                "align-items": [{
                    items: [...D(), {
                        baseline: [``, `last`]
                    }]
                }],
                "align-self": [{
                    self: [`auto`, ...D(), {
                        baseline: [``, `last`]
                    }]
                }],
                "place-content": [{
                    "place-content": E()
                }],
                "place-items": [{
                    "place-items": [...D(), `baseline`]
                }],
                "place-self": [{
                    "place-self": [`auto`, ...D()]
                }],
                p: [{
                    p: C()
                }],
                px: [{
                    px: C()
                }],
                py: [{
                    py: C()
                }],
                ps: [{
                    ps: C()
                }],
                pe: [{
                    pe: C()
                }],
                pbs: [{
                    pbs: C()
                }],
                pbe: [{
                    pbe: C()
                }],
                pt: [{
                    pt: C()
                }],
                pr: [{
                    pr: C()
                }],
                pb: [{
                    pb: C()
                }],
                pl: [{
                    pl: C()
                }],
                m: [{
                    m: O()
                }],
                mx: [{
                    mx: O()
                }],
                my: [{
                    my: O()
                }],
                ms: [{
                    ms: O()
                }],
                me: [{
                    me: O()
                }],
                mbs: [{
                    mbs: O()
                }],
                mbe: [{
                    mbe: O()
                }],
                mt: [{
                    mt: O()
                }],
                mr: [{
                    mr: O()
                }],
                mb: [{
                    mb: O()
                }],
                ml: [{
                    ml: O()
                }],
                "space-x": [{
                    "space-x": C()
                }],
                "space-x-reverse": [`space-x-reverse`],
                "space-y": [{
                    "space-y": C()
                }],
                "space-y-reverse": [`space-y-reverse`],
                size: [{
                    size: k()
                }],
                "inline-size": [{
                    inline: [`auto`, ...A()]
                }],
                "min-inline-size": [{
                    "min-inline": [`auto`, ...A()]
                }],
                "max-inline-size": [{
                    "max-inline": [`none`, ...A()]
                }],
                "block-size": [{
                    block: [`auto`, ...M()]
                }],
                "min-block-size": [{
                    "min-block": [`auto`, ...M()]
                }],
                "max-block-size": [{
                    "max-block": [`none`, ...M()]
                }],
                w: [{
                    w: [s, `screen`, ...k()]
                }],
                "min-w": [{
                    "min-w": [s, `screen`, `none`, ...k()]
                }],
                "max-w": [{
                    "max-w": [s, `screen`, `none`, `prose`, {
                        screen: [o]
                    }, ...k()]
                }],
                h: [{
                    h: [`screen`, `lh`, ...k()]
                }],
                "min-h": [{
                    "min-h": [`screen`, `lh`, `none`, ...k()]
                }],
                "max-h": [{
                    "max-h": [`screen`, `lh`, ...k()]
                }],
                "font-size": [{
                    text: [`base`, n, J, G]
                }],
                "font-smoothing": [`antialiased`, `subpixel-antialiased`],
                "font-style": [`italic`, `not-italic`],
                "font-weight": [{
                    font: [r, Se, me]
                }],
                "font-stretch": [{
                    "font-stretch": [`ultra-condensed`, `extra-condensed`, `condensed`, `semi-condensed`, `normal`, `semi-expanded`, `expanded`, `extra-expanded`, `ultra-expanded`, se, W]
                }],
                "font-family": [{
                    font: [ve, he, t]
                }],
                "font-features": [{
                    "font-features": [W]
                }],
                "fvn-normal": [`normal-nums`],
                "fvn-ordinal": [`ordinal`],
                "fvn-slashed-zero": [`slashed-zero`],
                "fvn-figure": [`lining-nums`, `oldstyle-nums`],
                "fvn-spacing": [`proportional-nums`, `tabular-nums`],
                "fvn-fraction": [`diagonal-fractions`, `stacked-fractions`],
                tracking: [{
                    tracking: [i, q, W]
                }],
                "line-clamp": [{
                    "line-clamp": [R, `none`, q, pe]
                }],
                leading: [{
                    leading: [a, ...C()]
                }],
                "list-image": [{
                    "list-image": [`none`, q, W]
                }],
                "list-style-position": [{
                    list: [`inside`, `outside`]
                }],
                "list-style-type": [{
                    list: [`disc`, `decimal`, `none`, q, W]
                }],
                "text-alignment": [{
                    text: [`left`, `center`, `right`, `justify`, `start`, `end`]
                }],
                "placeholder-color": [{
                    placeholder: N()
                }],
                "text-color": [{
                    text: N()
                }],
                "text-decoration": [`underline`, `overline`, `line-through`, `no-underline`],
                "text-decoration-style": [{
                    decoration: [...V(), `wavy`]
                }],
                "text-decoration-thickness": [{
                    decoration: [R, `from-font`, `auto`, q, G]
                }],
                "text-decoration-color": [{
                    decoration: N()
                }],
                "underline-offset": [{
                    "underline-offset": [R, `auto`, q, W]
                }],
                "text-transform": [`uppercase`, `lowercase`, `capitalize`, `normal-case`],
                "text-overflow": [`truncate`, `text-ellipsis`, `text-clip`],
                "text-wrap": [{
                    text: [`wrap`, `nowrap`, `balance`, `pretty`]
                }],
                indent: [{
                    indent: C()
                }],
                "tab-size": [{
                    tab: [z, q, W]
                }],
                "vertical-align": [{
                    align: [`baseline`, `top`, `middle`, `bottom`, `text-top`, `text-bottom`, `sub`, `super`, q, W]
                }],
                whitespace: [{
                    whitespace: [`normal`, `nowrap`, `pre`, `pre-line`, `pre-wrap`, `break-spaces`]
                }],
                break: [{
                    break: [`normal`, `words`, `all`, `keep`]
                }],
                wrap: [{
                    wrap: [`break-word`, `anywhere`, `normal`]
                }],
                hyphens: [{
                    hyphens: [`none`, `manual`, `auto`]
                }],
                content: [{
                    content: [`none`, q, W]
                }],
                "bg-attachment": [{
                    bg: [`fixed`, `local`, `scroll`]
                }],
                "bg-clip": [{
                    "bg-clip": [`border`, `padding`, `content`, `text`]
                }],
                "bg-origin": [{
                    "bg-origin": [`border`, `padding`, `content`]
                }],
                "bg-position": [{
                    bg: ie()
                }],
                "bg-repeat": [{
                    bg: ae()
                }],
                "bg-size": [{
                    bg: oe()
                }],
                "bg-image": [{
                    bg: [`none`, {
                        linear: [{
                            to: [`t`, `tr`, `r`, `br`, `b`, `bl`, `l`, `tl`]
                        }, z, q, W],
                        radial: [``, q, W],
                        conic: [z, q, W]
                    }, xe, _e]
                }],
                "bg-color": [{
                    bg: N()
                }],
                "gradient-from-pos": [{
                    from: P()
                }],
                "gradient-via-pos": [{
                    via: P()
                }],
                "gradient-to-pos": [{
                    to: P()
                }],
                "gradient-from": [{
                    from: N()
                }],
                "gradient-via": [{
                    via: N()
                }],
                "gradient-to": [{
                    to: N()
                }],
                rounded: [{
                    rounded: F()
                }],
                "rounded-s": [{
                    "rounded-s": F()
                }],
                "rounded-e": [{
                    "rounded-e": F()
                }],
                "rounded-t": [{
                    "rounded-t": F()
                }],
                "rounded-r": [{
                    "rounded-r": F()
                }],
                "rounded-b": [{
                    "rounded-b": F()
                }],
                "rounded-l": [{
                    "rounded-l": F()
                }],
                "rounded-ss": [{
                    "rounded-ss": F()
                }],
                "rounded-se": [{
                    "rounded-se": F()
                }],
                "rounded-ee": [{
                    "rounded-ee": F()
                }],
                "rounded-es": [{
                    "rounded-es": F()
                }],
                "rounded-tl": [{
                    "rounded-tl": F()
                }],
                "rounded-tr": [{
                    "rounded-tr": F()
                }],
                "rounded-br": [{
                    "rounded-br": F()
                }],
                "rounded-bl": [{
                    "rounded-bl": F()
                }],
                "border-w": [{
                    border: I()
                }],
                "border-w-x": [{
                    "border-x": I()
                }],
                "border-w-y": [{
                    "border-y": I()
                }],
                "border-w-s": [{
                    "border-s": I()
                }],
                "border-w-e": [{
                    "border-e": I()
                }],
                "border-w-bs": [{
                    "border-bs": I()
                }],
                "border-w-be": [{
                    "border-be": I()
                }],
                "border-w-t": [{
                    "border-t": I()
                }],
                "border-w-r": [{
                    "border-r": I()
                }],
                "border-w-b": [{
                    "border-b": I()
                }],
                "border-w-l": [{
                    "border-l": I()
                }],
                "divide-x": [{
                    "divide-x": I()
                }],
                "divide-x-reverse": [`divide-x-reverse`],
                "divide-y": [{
                    "divide-y": I()
                }],
                "divide-y-reverse": [`divide-y-reverse`],
                "border-style": [{
                    border: [...V(), `hidden`, `none`]
                }],
                "divide-style": [{
                    divide: [...V(), `hidden`, `none`]
                }],
                "border-color": [{
                    border: N()
                }],
                "border-color-x": [{
                    "border-x": N()
                }],
                "border-color-y": [{
                    "border-y": N()
                }],
                "border-color-s": [{
                    "border-s": N()
                }],
                "border-color-e": [{
                    "border-e": N()
                }],
                "border-color-bs": [{
                    "border-bs": N()
                }],
                "border-color-be": [{
                    "border-be": N()
                }],
                "border-color-t": [{
                    "border-t": N()
                }],
                "border-color-r": [{
                    "border-r": N()
                }],
                "border-color-b": [{
                    "border-b": N()
                }],
                "border-color-l": [{
                    "border-l": N()
                }],
                "divide-color": [{
                    divide: N()
                }],
                "outline-style": [{
                    outline: [...V(), `none`, `hidden`]
                }],
                "outline-offset": [{
                    "outline-offset": [R, q, W]
                }],
                "outline-w": [{
                    outline: [``, R, J, G]
                }],
                "outline-color": [{
                    outline: N()
                }],
                shadow: [{
                    shadow: [``, `none`, u, Y, K]
                }],
                "shadow-color": [{
                    shadow: N()
                }],
                "inset-shadow": [{
                    "inset-shadow": [`none`, d, Y, K]
                }],
                "inset-shadow-color": [{
                    "inset-shadow": N()
                }],
                "ring-w": [{
                    ring: I()
                }],
                "ring-w-inset": [`ring-inset`],
                "ring-color": [{
                    ring: N()
                }],
                "ring-offset-w": [{
                    "ring-offset": [R, G]
                }],
                "ring-offset-color": [{
                    "ring-offset": N()
                }],
                "inset-ring-w": [{
                    "inset-ring": I()
                }],
                "inset-ring-color": [{
                    "inset-ring": N()
                }],
                "text-shadow": [{
                    "text-shadow": [`none`, ee, Y, K]
                }],
                "text-shadow-color": [{
                    "text-shadow": N()
                }],
                opacity: [{
                    opacity: [R, q, W]
                }],
                "mix-blend": [{
                    "mix-blend": [...H(), `plus-darker`, `plus-lighter`]
                }],
                "bg-blend": [{
                    "bg-blend": H()
                }],
                "mask-clip": [{
                    "mask-clip": [`border`, `padding`, `content`, `fill`, `stroke`, `view`]
                }, `mask-no-clip`],
                "mask-composite": [{
                    mask: [`add`, `subtract`, `intersect`, `exclude`]
                }],
                "mask-image-linear-pos": [{
                    "mask-linear": [R]
                }],
                "mask-image-linear-from-pos": [{
                    "mask-linear-from": U()
                }],
                "mask-image-linear-to-pos": [{
                    "mask-linear-to": U()
                }],
                "mask-image-linear-from-color": [{
                    "mask-linear-from": N()
                }],
                "mask-image-linear-to-color": [{
                    "mask-linear-to": N()
                }],
                "mask-image-t-from-pos": [{
                    "mask-t-from": U()
                }],
                "mask-image-t-to-pos": [{
                    "mask-t-to": U()
                }],
                "mask-image-t-from-color": [{
                    "mask-t-from": N()
                }],
                "mask-image-t-to-color": [{
                    "mask-t-to": N()
                }],
                "mask-image-r-from-pos": [{
                    "mask-r-from": U()
                }],
                "mask-image-r-to-pos": [{
                    "mask-r-to": U()
                }],
                "mask-image-r-from-color": [{
                    "mask-r-from": N()
                }],
                "mask-image-r-to-color": [{
                    "mask-r-to": N()
                }],
                "mask-image-b-from-pos": [{
                    "mask-b-from": U()
                }],
                "mask-image-b-to-pos": [{
                    "mask-b-to": U()
                }],
                "mask-image-b-from-color": [{
                    "mask-b-from": N()
                }],
                "mask-image-b-to-color": [{
                    "mask-b-to": N()
                }],
                "mask-image-l-from-pos": [{
                    "mask-l-from": U()
                }],
                "mask-image-l-to-pos": [{
                    "mask-l-to": U()
                }],
                "mask-image-l-from-color": [{
                    "mask-l-from": N()
                }],
                "mask-image-l-to-color": [{
                    "mask-l-to": N()
                }],
                "mask-image-x-from-pos": [{
                    "mask-x-from": U()
                }],
                "mask-image-x-to-pos": [{
                    "mask-x-to": U()
                }],
                "mask-image-x-from-color": [{
                    "mask-x-from": N()
                }],
                "mask-image-x-to-color": [{
                    "mask-x-to": N()
                }],
                "mask-image-y-from-pos": [{
                    "mask-y-from": U()
                }],
                "mask-image-y-to-pos": [{
                    "mask-y-to": U()
                }],
                "mask-image-y-from-color": [{
                    "mask-y-from": N()
                }],
                "mask-image-y-to-color": [{
                    "mask-y-to": N()
                }],
                "mask-image-radial": [{
                    "mask-radial": [q, W]
                }],
                "mask-image-radial-from-pos": [{
                    "mask-radial-from": U()
                }],
                "mask-image-radial-to-pos": [{
                    "mask-radial-to": U()
                }],
                "mask-image-radial-from-color": [{
                    "mask-radial-from": N()
                }],
                "mask-image-radial-to-color": [{
                    "mask-radial-to": N()
                }],
                "mask-image-radial-shape": [{
                    "mask-radial": [`circle`, `ellipse`]
                }],
                "mask-image-radial-size": [{
                    "mask-radial": [{
                        closest: [`side`, `corner`],
                        farthest: [`side`, `corner`]
                    }]
                }],
                "mask-image-radial-pos": [{
                    "mask-radial-at": y()
                }],
                "mask-image-conic-pos": [{
                    "mask-conic": [R]
                }],
                "mask-image-conic-from-pos": [{
                    "mask-conic-from": U()
                }],
                "mask-image-conic-to-pos": [{
                    "mask-conic-to": U()
                }],
                "mask-image-conic-from-color": [{
                    "mask-conic-from": N()
                }],
                "mask-image-conic-to-color": [{
                    "mask-conic-to": N()
                }],
                "mask-mode": [{
                    mask: [`alpha`, `luminance`, `match`]
                }],
                "mask-origin": [{
                    "mask-origin": [`border`, `padding`, `content`, `fill`, `stroke`, `view`]
                }],
                "mask-position": [{
                    mask: ie()
                }],
                "mask-repeat": [{
                    mask: ae()
                }],
                "mask-size": [{
                    mask: oe()
                }],
                "mask-type": [{
                    "mask-type": [`alpha`, `luminance`]
                }],
                "mask-image": [{
                    mask: [`none`, q, W]
                }],
                filter: [{
                    filter: [``, `none`, q, W]
                }],
                blur: [{
                    blur: le()
                }],
                brightness: [{
                    brightness: [R, q, W]
                }],
                contrast: [{
                    contrast: [R, q, W]
                }],
                "drop-shadow": [{
                    "drop-shadow": [``, `none`, f, Y, K]
                }],
                "drop-shadow-color": [{
                    "drop-shadow": N()
                }],
                grayscale: [{
                    grayscale: [``, R, q, W]
                }],
                "hue-rotate": [{
                    "hue-rotate": [R, q, W]
                }],
                invert: [{
                    invert: [``, R, q, W]
                }],
                saturate: [{
                    saturate: [R, q, W]
                }],
                sepia: [{
                    sepia: [``, R, q, W]
                }],
                "backdrop-filter": [{
                    "backdrop-filter": [``, `none`, q, W]
                }],
                "backdrop-blur": [{
                    "backdrop-blur": le()
                }],
                "backdrop-brightness": [{
                    "backdrop-brightness": [R, q, W]
                }],
                "backdrop-contrast": [{
                    "backdrop-contrast": [R, q, W]
                }],
                "backdrop-grayscale": [{
                    "backdrop-grayscale": [``, R, q, W]
                }],
                "backdrop-hue-rotate": [{
                    "backdrop-hue-rotate": [R, q, W]
                }],
                "backdrop-invert": [{
                    "backdrop-invert": [``, R, q, W]
                }],
                "backdrop-opacity": [{
                    "backdrop-opacity": [R, q, W]
                }],
                "backdrop-saturate": [{
                    "backdrop-saturate": [R, q, W]
                }],
                "backdrop-sepia": [{
                    "backdrop-sepia": [``, R, q, W]
                }],
                "border-collapse": [{
                    border: [`collapse`, `separate`]
                }],
                "border-spacing": [{
                    "border-spacing": C()
                }],
                "border-spacing-x": [{
                    "border-spacing-x": C()
                }],
                "border-spacing-y": [{
                    "border-spacing-y": C()
                }],
                "table-layout": [{
                    table: [`auto`, `fixed`]
                }],
                caption: [{
                    caption: [`top`, `bottom`]
                }],
                transition: [{
                    transition: [``, `all`, `colors`, `opacity`, `shadow`, `transform`, `none`, q, W]
                }],
                "transition-behavior": [{
                    transition: [`normal`, `discrete`]
                }],
                duration: [{
                    duration: [R, `initial`, q, W]
                }],
                ease: [{
                    ease: [`linear`, `initial`, g, q, W]
                }],
                delay: [{
                    delay: [R, q, W]
                }],
                animate: [{
                    animate: [`none`, _, q, W]
                }],
                backface: [{
                    backface: [`hidden`, `visible`]
                }],
                perspective: [{
                    perspective: [m, q, W]
                }],
                "perspective-origin": [{
                    "perspective-origin": b()
                }],
                rotate: [{
                    rotate: X()
                }],
                "rotate-x": [{
                    "rotate-x": X()
                }],
                "rotate-y": [{
                    "rotate-y": X()
                }],
                "rotate-z": [{
                    "rotate-z": X()
                }],
                scale: [{
                    scale: Z()
                }],
                "scale-x": [{
                    "scale-x": Z()
                }],
                "scale-y": [{
                    "scale-y": Z()
                }],
                "scale-z": [{
                    "scale-z": Z()
                }],
                "scale-3d": [`scale-3d`],
                skew: [{
                    skew: Q()
                }],
                "skew-x": [{
                    "skew-x": Q()
                }],
                "skew-y": [{
                    "skew-y": Q()
                }],
                transform: [{
                    transform: [q, W, ``, `none`, `gpu`, `cpu`]
                }],
                "transform-origin": [{
                    origin: b()
                }],
                "transform-style": [{
                    transform: [`3d`, `flat`]
                }],
                translate: [{
                    translate: $()
                }],
                "translate-x": [{
                    "translate-x": $()
                }],
                "translate-y": [{
                    "translate-y": $()
                }],
                "translate-z": [{
                    "translate-z": $()
                }],
                "translate-none": [`translate-none`],
                zoom: [{
                    zoom: [z, q, W]
                }],
                accent: [{
                    accent: N()
                }],
                appearance: [{
                    appearance: [`none`, `auto`]
                }],
                "caret-color": [{
                    caret: N()
                }],
                "color-scheme": [{
                    scheme: [`normal`, `dark`, `light`, `light-dark`, `only-dark`, `only-light`]
                }],
                cursor: [{
                    cursor: [`auto`, `default`, `pointer`, `wait`, `text`, `move`, `help`, `not-allowed`, `none`, `context-menu`, `progress`, `cell`, `crosshair`, `vertical-text`, `alias`, `copy`, `no-drop`, `grab`, `grabbing`, `all-scroll`, `col-resize`, `row-resize`, `n-resize`, `e-resize`, `s-resize`, `w-resize`, `ne-resize`, `nw-resize`, `se-resize`, `sw-resize`, `ew-resize`, `ns-resize`, `nesw-resize`, `nwse-resize`, `zoom-in`, `zoom-out`, q, W]
                }],
                "field-sizing": [{
                    "field-sizing": [`fixed`, `content`]
                }],
                "pointer-events": [{
                    "pointer-events": [`auto`, `none`]
                }],
                resize: [{
                    resize: [`none`, ``, `y`, `x`]
                }],
                "scroll-behavior": [{
                    scroll: [`auto`, `smooth`]
                }],
                "scrollbar-thumb-color": [{
                    "scrollbar-thumb": N()
                }],
                "scrollbar-track-color": [{
                    "scrollbar-track": N()
                }],
                "scrollbar-gutter": [{
                    "scrollbar-gutter": [`auto`, `stable`, `both`]
                }],
                "scrollbar-w": [{
                    scrollbar: [`auto`, `thin`, `none`]
                }],
                "scroll-m": [{
                    "scroll-m": C()
                }],
                "scroll-mx": [{
                    "scroll-mx": C()
                }],
                "scroll-my": [{
                    "scroll-my": C()
                }],
                "scroll-ms": [{
                    "scroll-ms": C()
                }],
                "scroll-me": [{
                    "scroll-me": C()
                }],
                "scroll-mbs": [{
                    "scroll-mbs": C()
                }],
                "scroll-mbe": [{
                    "scroll-mbe": C()
                }],
                "scroll-mt": [{
                    "scroll-mt": C()
                }],
                "scroll-mr": [{
                    "scroll-mr": C()
                }],
                "scroll-mb": [{
                    "scroll-mb": C()
                }],
                "scroll-ml": [{
                    "scroll-ml": C()
                }],
                "scroll-p": [{
                    "scroll-p": C()
                }],
                "scroll-px": [{
                    "scroll-px": C()
                }],
                "scroll-py": [{
                    "scroll-py": C()
                }],
                "scroll-ps": [{
                    "scroll-ps": C()
                }],
                "scroll-pe": [{
                    "scroll-pe": C()
                }],
                "scroll-pbs": [{
                    "scroll-pbs": C()
                }],
                "scroll-pbe": [{
                    "scroll-pbe": C()
                }],
                "scroll-pt": [{
                    "scroll-pt": C()
                }],
                "scroll-pr": [{
                    "scroll-pr": C()
                }],
                "scroll-pb": [{
                    "scroll-pb": C()
                }],
                "scroll-pl": [{
                    "scroll-pl": C()
                }],
                "snap-align": [{
                    snap: [`start`, `end`, `center`, `align-none`]
                }],
                "snap-stop": [{
                    snap: [`normal`, `always`]
                }],
                "snap-type": [{
                    snap: [`none`, `x`, `y`, `both`]
                }],
                "snap-strictness": [{
                    snap: [`mandatory`, `proximity`]
                }],
                touch: [{
                    touch: [`auto`, `none`, `manipulation`]
                }],
                "touch-x": [{
                    "touch-pan": [`x`, `left`, `right`]
                }],
                "touch-y": [{
                    "touch-pan": [`y`, `up`, `down`]
                }],
                "touch-pz": [`touch-pinch-zoom`],
                select: [{
                    select: [`none`, `text`, `all`, `auto`]
                }],
                "will-change": [{
                    "will-change": [`auto`, `scroll`, `contents`, `transform`, q, W]
                }],
                fill: [{
                    fill: [`none`, ...N()]
                }],
                "stroke-w": [{
                    stroke: [R, J, G, pe]
                }],
                stroke: [{
                    stroke: [`none`, ...N()]
                }],
                "forced-color-adjust": [{
                    "forced-color-adjust": [`auto`, `none`]
                }]
            },
            conflictingClassGroups: {
                "container-named": [`container-type`],
                overflow: [`overflow-x`, `overflow-y`],
                overscroll: [`overscroll-x`, `overscroll-y`],
                inset: [`inset-x`, `inset-y`, `inset-bs`, `inset-be`, `start`, `end`, `top`, `right`, `bottom`, `left`],
                "inset-x": [`right`, `left`],
                "inset-y": [`top`, `bottom`],
                flex: [`basis`, `grow`, `shrink`],
                gap: [`gap-x`, `gap-y`],
                p: [`px`, `py`, `ps`, `pe`, `pbs`, `pbe`, `pt`, `pr`, `pb`, `pl`],
                px: [`pr`, `pl`],
                py: [`pt`, `pb`],
                m: [`mx`, `my`, `ms`, `me`, `mbs`, `mbe`, `mt`, `mr`, `mb`, `ml`],
                mx: [`mr`, `ml`],
                my: [`mt`, `mb`],
                size: [`w`, `h`],
                "font-size": [`leading`],
                "fvn-normal": [`fvn-ordinal`, `fvn-slashed-zero`, `fvn-figure`, `fvn-spacing`, `fvn-fraction`],
                "fvn-ordinal": [`fvn-normal`],
                "fvn-slashed-zero": [`fvn-normal`],
                "fvn-figure": [`fvn-normal`],
                "fvn-spacing": [`fvn-normal`],
                "fvn-fraction": [`fvn-normal`],
                "line-clamp": [`display`, `overflow`],
                rounded: [`rounded-s`, `rounded-e`, `rounded-t`, `rounded-r`, `rounded-b`, `rounded-l`, `rounded-ss`, `rounded-se`, `rounded-ee`, `rounded-es`, `rounded-tl`, `rounded-tr`, `rounded-br`, `rounded-bl`],
                "rounded-s": [`rounded-ss`, `rounded-es`],
                "rounded-e": [`rounded-se`, `rounded-ee`],
                "rounded-t": [`rounded-tl`, `rounded-tr`],
                "rounded-r": [`rounded-tr`, `rounded-br`],
                "rounded-b": [`rounded-br`, `rounded-bl`],
                "rounded-l": [`rounded-tl`, `rounded-bl`],
                "border-spacing": [`border-spacing-x`, `border-spacing-y`],
                "border-w": [`border-w-x`, `border-w-y`, `border-w-s`, `border-w-e`, `border-w-bs`, `border-w-be`, `border-w-t`, `border-w-r`, `border-w-b`, `border-w-l`],
                "border-w-x": [`border-w-r`, `border-w-l`],
                "border-w-y": [`border-w-t`, `border-w-b`],
                "border-color": [`border-color-x`, `border-color-y`, `border-color-s`, `border-color-e`, `border-color-bs`, `border-color-be`, `border-color-t`, `border-color-r`, `border-color-b`, `border-color-l`],
                "border-color-x": [`border-color-r`, `border-color-l`],
                "border-color-y": [`border-color-t`, `border-color-b`],
                translate: [`translate-x`, `translate-y`, `translate-none`],
                "translate-none": [`translate`, `translate-x`, `translate-y`, `translate-z`],
                "scroll-m": [`scroll-mx`, `scroll-my`, `scroll-ms`, `scroll-me`, `scroll-mbs`, `scroll-mbe`, `scroll-mt`, `scroll-mr`, `scroll-mb`, `scroll-ml`],
                "scroll-mx": [`scroll-mr`, `scroll-ml`],
                "scroll-my": [`scroll-mt`, `scroll-mb`],
                "scroll-p": [`scroll-px`, `scroll-py`, `scroll-ps`, `scroll-pe`, `scroll-pbs`, `scroll-pbe`, `scroll-pt`, `scroll-pr`, `scroll-pb`, `scroll-pl`],
                "scroll-px": [`scroll-pr`, `scroll-pl`],
                "scroll-py": [`scroll-pt`, `scroll-pb`],
                touch: [`touch-x`, `touch-y`, `touch-pz`],
                "touch-x": [`touch`],
                "touch-y": [`touch`],
                "touch-pz": [`touch`]
            },
            conflictingClassGroupModifiers: {
                "font-size": [`leading`]
            },
            postfixLookupClassGroups: [`container-type`],
            orderSensitiveModifiers: [`*`, `**`, `after`, `backdrop`, `before`, `details-content`, `file`, `first-letter`, `first-line`, `marker`, `placeholder`, `selection`]
        }
    });

function Ae(...e) {
    return ke(t(e))
}
export {
    t as n, Ae as t
};