import {
    t as e
} from "./rolldown-runtime-hePW80VL.js";
var t = e((e => {
        var t = Symbol.for(`react.transitional.element`),
            n = Symbol.for(`react.portal`),
            r = Symbol.for(`react.fragment`),
            i = Symbol.for(`react.strict_mode`),
            a = Symbol.for(`react.profiler`),
            o = Symbol.for(`react.consumer`),
            s = Symbol.for(`react.context`),
            c = Symbol.for(`react.forward_ref`),
            l = Symbol.for(`react.suspense`),
            u = Symbol.for(`react.memo`),
            d = Symbol.for(`react.lazy`),
            f = Symbol.for(`react.activity`),
            p = Symbol.iterator;

        function m(e) {
            return typeof e != `object` || !e ? null : (e = p && e[p] || e[`@@iterator`], typeof e == `function` ? e : null)
        }
        var h = {
                isMounted: function() {
                    return !1
                },
                enqueueForceUpdate: function() {},
                enqueueReplaceState: function() {},
                enqueueSetState: function() {}
            },
            g = Object.assign,
            _ = {};

        function v(e, t, n) {
            this.props = e, this.context = t, this.refs = _, this.updater = n || h
        }
        v.prototype.isReactComponent = {}, v.prototype.setState = function(e, t) {
            if (typeof e != `object` && typeof e != `function` && e != null) throw Error(`takes an object of state variables to update or a function which returns an object of state variables.`);
            this.updater.enqueueSetState(this, e, t, `setState`)
        }, v.prototype.forceUpdate = function(e) {
            this.updater.enqueueForceUpdate(this, e, `forceUpdate`)
        };

        function y() {}
        y.prototype = v.prototype;

        function b(e, t, n) {
            this.props = e, this.context = t, this.refs = _, this.updater = n || h
        }
        var x = b.prototype = new y;
        x.constructor = b, g(x, v.prototype), x.isPureReactComponent = !0;
        var S = Array.isArray;

        function C() {}
        var w = {
                H: null,
                A: null,
                T: null,
                S: null
            },
            T = Object.prototype.hasOwnProperty;

        function E(e, n, r) {
            var i = r.ref;
            return {
                $$typeof: t,
                type: e,
                key: n,
                ref: i === void 0 ? null : i,
                props: r
            }
        }

        function D(e, t) {
            return E(e.type, t, e.props)
        }

        function O(e) {
            return typeof e == `object` && !!e && e.$$typeof === t
        }

        function k(e) {
            var t = {
                "=": `=0`,
                ":": `=2`
            };
            return `$` + e.replace(/[=:]/g, function(e) {
                return t[e]
            })
        }
        var A = /\/+/g;

        function j(e, t) {
            return typeof e == `object` && e && e.key != null ? k(`` + e.key) : t.toString(36)
        }

        function M(e) {
            switch (e.status) {
                case `fulfilled`:
                    return e.value;
                case `rejected`:
                    throw e.reason;
                default:
                    switch (typeof e.status == `string` ? e.then(C, C) : (e.status = `pending`, e.then(function(t) {
                        e.status === `pending` && (e.status = `fulfilled`, e.value = t)
                    }, function(t) {
                        e.status === `pending` && (e.status = `rejected`, e.reason = t)
                    })), e.status) {
                        case `fulfilled`:
                            return e.value;
                        case `rejected`:
                            throw e.reason
                    }
            }
            throw e
        }

        function N(e, r, i, a, o) {
            var s = typeof e;
            (s === `undefined` || s === `boolean`) && (e = null);
            var c = !1;
            if (e === null) c = !0;
            else switch (s) {
                case `bigint`:
                case `string`:
                case `number`:
                    c = !0;
                    break;
                case `object`:
                    switch (e.$$typeof) {
                        case t:
                        case n:
                            c = !0;
                            break;
                        case d:
                            return c = e._init, N(c(e._payload), r, i, a, o)
                    }
            }
            if (c) return o = o(e), c = a === `` ? `.` + j(e, 0) : a, S(o) ? (i = ``, c != null && (i = c.replace(A, `$&/`) + `/`), N(o, r, i, ``, function(e) {
                return e
            })) : o != null && (O(o) && (o = D(o, i + (o.key == null || e && e.key === o.key ? `` : (`` + o.key).replace(A, `$&/`) + `/`) + c)), r.push(o)), 1;
            c = 0;
            var l = a === `` ? `.` : a + `:`;
            if (S(e))
                for (var u = 0; u < e.length; u++) a = e[u], s = l + j(a, u), c += N(a, r, i, s, o);
            else if (u = m(e), typeof u == `function`)
                for (e = u.call(e), u = 0; !(a = e.next()).done;) a = a.value, s = l + j(a, u++), c += N(a, r, i, s, o);
            else if (s === `object`) {
                if (typeof e.then == `function`) return N(M(e), r, i, a, o);
                throw r = String(e), Error(`Objects are not valid as a React child (found: ` + (r === `[object Object]` ? `object with keys {` + Object.keys(e).join(`, `) + `}` : r) + `). If you meant to render a collection of children, use an array instead.`)
            }
            return c
        }

        function P(e, t, n) {
            if (e == null) return e;
            var r = [],
                i = 0;
            return N(e, r, ``, ``, function(e) {
                return t.call(n, e, i++)
            }), r
        }

        function F(e) {
            if (e._status === -1) {
                var t = e._result;
                t = t(), t.then(function(t) {
                    (e._status === 0 || e._status === -1) && (e._status = 1, e._result = t)
                }, function(t) {
                    (e._status === 0 || e._status === -1) && (e._status = 2, e._result = t)
                }), e._status === -1 && (e._status = 0, e._result = t)
            }
            if (e._status === 1) return e._result.default;
            throw e._result
        }
        var I = typeof reportError == `function` ? reportError : function(e) {
                if (typeof window == `object` && typeof window.ErrorEvent == `function`) {
                    var t = new window.ErrorEvent(`error`, {
                        bubbles: !0,
                        cancelable: !0,
                        message: typeof e == `object` && e && typeof e.message == `string` ? String(e.message) : String(e),
                        error: e
                    });
                    if (!window.dispatchEvent(t)) return
                } else if (typeof process == `object` && typeof process.emit == `function`) {
                    process.emit(`uncaughtException`, e);
                    return
                }
                console.error(e)
            },
            L = {
                map: P,
                forEach: function(e, t, n) {
                    P(e, function() {
                        t.apply(this, arguments)
                    }, n)
                },
                count: function(e) {
                    var t = 0;
                    return P(e, function() {
                        t++
                    }), t
                },
                toArray: function(e) {
                    return P(e, function(e) {
                        return e
                    }) || []
                },
                only: function(e) {
                    if (!O(e)) throw Error(`React.Children.only expected to receive a single React element child.`);
                    return e
                }
            };
        e.Activity = f, e.Children = L, e.Component = v, e.Fragment = r, e.Profiler = a, e.PureComponent = b, e.StrictMode = i, e.Suspense = l, e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = w, e.__COMPILER_RUNTIME = {
            __proto__: null,
            c: function(e) {
                return w.H.useMemoCache(e)
            }
        }, e.cache = function(e) {
            return function() {
                return e.apply(null, arguments)
            }
        }, e.cacheSignal = function() {
            return null
        }, e.cloneElement = function(e, t, n) {
            if (e == null) throw Error(`The argument must be a React element, but you passed ` + e + `.`);
            var r = g({}, e.props),
                i = e.key;
            if (t != null)
                for (a in t.key !== void 0 && (i = `` + t.key), t) !T.call(t, a) || a === `key` || a === `__self` || a === `__source` || a === `ref` && t.ref === void 0 || (r[a] = t[a]);
            var a = arguments.length - 2;
            if (a === 1) r.children = n;
            else if (1 < a) {
                for (var o = Array(a), s = 0; s < a; s++) o[s] = arguments[s + 2];
                r.children = o
            }
            return E(e.type, i, r)
        }, e.createContext = function(e) {
            return e = {
                $$typeof: s,
                _currentValue: e,
                _currentValue2: e,
                _threadCount: 0,
                Provider: null,
                Consumer: null
            }, e.Provider = e, e.Consumer = {
                $$typeof: o,
                _context: e
            }, e
        }, e.createElement = function(e, t, n) {
            var r, i = {},
                a = null;
            if (t != null)
                for (r in t.key !== void 0 && (a = `` + t.key), t) T.call(t, r) && r !== `key` && r !== `__self` && r !== `__source` && (i[r] = t[r]);
            var o = arguments.length - 2;
            if (o === 1) i.children = n;
            else if (1 < o) {
                for (var s = Array(o), c = 0; c < o; c++) s[c] = arguments[c + 2];
                i.children = s
            }
            if (e && e.defaultProps)
                for (r in o = e.defaultProps, o) i[r] === void 0 && (i[r] = o[r]);
            return E(e, a, i)
        }, e.createRef = function() {
            return {
                current: null
            }
        }, e.forwardRef = function(e) {
            return {
                $$typeof: c,
                render: e
            }
        }, e.isValidElement = O, e.lazy = function(e) {
            return {
                $$typeof: d,
                _payload: {
                    _status: -1,
                    _result: e
                },
                _init: F
            }
        }, e.memo = function(e, t) {
            return {
                $$typeof: u,
                type: e,
                compare: t === void 0 ? null : t
            }
        }, e.startTransition = function(e) {
            var t = w.T,
                n = {};
            w.T = n;
            try {
                var r = e(),
                    i = w.S;
                i !== null && i(n, r), typeof r == `object` && r && typeof r.then == `function` && r.then(C, I)
            } catch (e) {
                I(e)
            } finally {
                t !== null && n.types !== null && (t.types = n.types), w.T = t
            }
        }, e.unstable_useCacheRefresh = function() {
            return w.H.useCacheRefresh()
        }, e.use = function(e) {
            return w.H.use(e)
        }, e.useActionState = function(e, t, n) {
            return w.H.useActionState(e, t, n)
        }, e.useCallback = function(e, t) {
            return w.H.useCallback(e, t)
        }, e.useContext = function(e) {
            return w.H.useContext(e)
        }, e.useDebugValue = function() {}, e.useDeferredValue = function(e, t) {
            return w.H.useDeferredValue(e, t)
        }, e.useEffect = function(e, t) {
            return w.H.useEffect(e, t)
        }, e.useEffectEvent = function(e) {
            return w.H.useEffectEvent(e)
        }, e.useId = function() {
            return w.H.useId()
        }, e.useImperativeHandle = function(e, t, n) {
            return w.H.useImperativeHandle(e, t, n)
        }, e.useInsertionEffect = function(e, t) {
            return w.H.useInsertionEffect(e, t)
        }, e.useLayoutEffect = function(e, t) {
            return w.H.useLayoutEffect(e, t)
        }, e.useMemo = function(e, t) {
            return w.H.useMemo(e, t)
        }, e.useOptimistic = function(e, t) {
            return w.H.useOptimistic(e, t)
        }, e.useReducer = function(e, t, n) {
            return w.H.useReducer(e, t, n)
        }, e.useRef = function(e) {
            return w.H.useRef(e)
        }, e.useState = function(e) {
            return w.H.useState(e)
        }, e.useSyncExternalStore = function(e, t, n) {
            return w.H.useSyncExternalStore(e, t, n)
        }, e.useTransition = function() {
            return w.H.useTransition()
        }, e.version = `19.2.8`
    })),
    n = e(((e, n) => {
        n.exports = t()
    })),
    r = e((e => {
        var t = Symbol.for(`react.transitional.element`),
            n = Symbol.for(`react.fragment`);

        function r(e, n, r) {
            var i = null;
            if (r !== void 0 && (i = `` + r), n.key !== void 0 && (i = `` + n.key), `key` in n)
                for (var a in r = {}, n) a !== `key` && (r[a] = n[a]);
            else r = n;
            return n = r.ref, {
                $$typeof: t,
                type: e,
                key: i,
                ref: n === void 0 ? null : n,
                props: r
            }
        }
        e.Fragment = n, e.jsx = r, e.jsxs = r
    })),
    i = e(((e, t) => {
        t.exports = r()
    }));
export {
    n,
    i as t
};