import {
    t as e
} from "./createLucideIcon-BZ5eRbaK.js";
var t = e(`check`, [
    [`path`, {
        d: `M20 6 9 17l-5-5`,
        key: `1gmf2c`
    }]
]);
export {
    t
};