import {
    r as e
} from "./rolldown-runtime-hePW80VL.js";
import {
    n as t
} from "./jsx-runtime-DE3RlOCf.js";
import {
    n
} from "./dist-CICBZQnc.js";
var r = e(t(), 1),
    i = Object.defineProperty,
    a = (e, t) => i(e, `name`, {
        value: t,
        configurable: !0
    });

function o(e) {
    let [t, i] = r.useState(void 0);
    return n(() => {
        if (e) {
            i({
                width: e.offsetWidth,
                height: e.offsetHeight
            });
            let t = new ResizeObserver(t => {
                if (!Array.isArray(t) || !t.length) return;
                let n = t[0],
                    r, a;
                if (`borderBoxSize` in n) {
                    let e = n.borderBoxSize,
                        t = Array.isArray(e) ? e[0] : e;
                    r = t.inlineSize, a = t.blockSize
                } else r = e.offsetWidth, a = e.offsetHeight;
                i({
                    width: r,
                    height: a
                })
            });
            return t.observe(e, {
                box: `border-box`
            }), () => t.unobserve(e)
        }
        i(void 0)
    }, [e]), t
}
a(o, `useSize`);
export {
    o as t
};