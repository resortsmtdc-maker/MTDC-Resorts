import {
    t as e
} from "./createLucideIcon-BZ5eRbaK.js";
var t = e(`mail`, [
    [`path`, {
        d: `m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7`,
        key: `132q7q`
    }],
    [`rect`, {
        x: `2`,
        y: `4`,
        width: `20`,
        height: `16`,
        rx: `2`,
        key: `izxlao`
    }]
]);
export {
    t
};