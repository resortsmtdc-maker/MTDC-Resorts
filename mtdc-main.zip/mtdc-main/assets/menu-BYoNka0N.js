import {
    t as e
} from "./createLucideIcon-BZ5eRbaK.js";
var t = e(`menu`, [
    [`path`, {
        d: `M4 5h16`,
        key: `1tepv9`
    }],
    [`path`, {
        d: `M4 12h16`,
        key: `1lakjw`
    }],
    [`path`, {
        d: `M4 19h16`,
        key: `1djgab`
    }]
]);
export {
    t
};