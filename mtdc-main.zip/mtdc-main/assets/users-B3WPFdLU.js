import {
    t as e
} from "./createLucideIcon-BZ5eRbaK.js";
var t = e(`users`, [
    [`path`, {
        d: `M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2`,
        key: `1yyitq`
    }],
    [`path`, {
        d: `M16 3.128a4 4 0 0 1 0 7.744`,
        key: `16gr8j`
    }],
    [`path`, {
        d: `M22 21v-2a4 4 0 0 0-3-3.87`,
        key: `kshegd`
    }],
    [`circle`, {
        cx: `9`,
        cy: `7`,
        r: `4`,
        key: `nufk8`
    }]
]);
export {
    t
};