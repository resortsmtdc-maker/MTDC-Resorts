var e = Symbol.for(`@supabase/supabase-js.traceContextExtractor`);

function t() {
    return globalThis[e]
}
var n = function() {
    return n = Object.assign || function(e) {
        for (var t, n = 1, r = arguments.length; n < r; n++)
            for (var i in t = arguments[n], t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
        return e
    }, n.apply(this, arguments)
};

function r(e, t) {
    var n = {};
    for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
    if (e != null && typeof Object.getOwnPropertySymbols == `function`)
        for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
    return n
}

function i(e, t, n, r) {
    function i(e) {
        return e instanceof n ? e : new n(function(t) {
            t(e)
        })
    }
    return new(n ||= Promise)(function(n, a) {
        function o(e) {
            try {
                c(r.next(e))
            } catch (e) {
                a(e)
            }
        }

        function s(e) {
            try {
                c(r.throw(e))
            } catch (e) {
                a(e)
            }
        }

        function c(e) {
            e.done ? n(e.value) : i(e.value).then(o, s)
        }
        c((r = r.apply(e, t || [])).next())
    })
}

function a(e, t, n) {
    if (n || arguments.length === 2)
        for (var r = 0, i = t.length, a; r < i; r++)(a || !(r in t)) && (a ||= Array.prototype.slice.call(t, 0, r), a[r] = t[r]);
    return e.concat(a || Array.prototype.slice.call(t))
}
var o = e => e ? (...t) => e(...t) : (...e) => fetch(...e),
    s = class extends Error {
        constructor(e, t = `FunctionsError`, n) {
            super(e), this.name = t, this.context = n
        }
        toJSON() {
            return {
                name: this.name,
                message: this.message,
                context: this.context
            }
        }
    },
    c = class extends s {
        constructor(e) {
            super(`Failed to send a request to the Edge Function`, `FunctionsFetchError`, e)
        }
    },
    l = class extends s {
        constructor(e) {
            super(`Relay Error invoking the Edge Function`, `FunctionsRelayError`, e)
        }
    },
    u = class extends s {
        constructor(e) {
            super(`Edge Function returned a non-2xx status code`, `FunctionsHttpError`, e)
        }
    },
    d;
(function(e) {
    e.Any = `any`, e.ApNortheast1 = `ap-northeast-1`, e.ApNortheast2 = `ap-northeast-2`, e.ApSouth1 = `ap-south-1`, e.ApSoutheast1 = `ap-southeast-1`, e.ApSoutheast2 = `ap-southeast-2`, e.CaCentral1 = `ca-central-1`, e.EuCentral1 = `eu-central-1`, e.EuWest1 = `eu-west-1`, e.EuWest2 = `eu-west-2`, e.EuWest3 = `eu-west-3`, e.SaEast1 = `sa-east-1`, e.UsEast1 = `us-east-1`, e.UsWest1 = `us-west-1`, e.UsWest2 = `us-west-2`
})(d ||= {});
var f = class {
        constructor(e, {
            headers: t = {},
            customFetch: n,
            region: r = d.Any
        } = {}) {
            this.url = e, this.headers = t, this.region = r, this.fetch = o(n)
        }
        setAuth(e) {
            this.headers.Authorization = `Bearer ${e}`
        }
        invoke(e) {
            return i(this, arguments, void 0, function*(e, t = {}) {
                var n;
                let r, i, a;
                try {
                    let {
                        headers: n,
                        method: o,
                        body: s,
                        signal: d,
                        timeout: f
                    } = t, p = {}, {
                        region: m
                    } = t;
                    m ||= this.region;
                    let h = new URL(`${this.url}/${e}`);
                    m && m !== `any` && (p[`x-region`] = m, h.searchParams.set(`forceFunctionRegion`, m));
                    let g, ee = !!n && Object.keys(n).some(e => e.toLowerCase() === `content-type`);
                    s && !ee ? typeof Blob < `u` && s instanceof Blob || s instanceof ArrayBuffer ? (p[`Content-Type`] = `application/octet-stream`, g = s) : typeof s == `string` ? (p[`Content-Type`] = `text/plain`, g = s) : typeof FormData < `u` && s instanceof FormData ? g = s : (p[`Content-Type`] = `application/json`, g = JSON.stringify(s)) : g = s && typeof s != `string` && !(typeof Blob < `u` && s instanceof Blob) && !(s instanceof ArrayBuffer) && !(typeof FormData < `u` && s instanceof FormData) ? JSON.stringify(s) : s;
                    let _ = d;
                    f && (i = new AbortController, r = setTimeout(() => i.abort(), f), d ? (_ = i.signal, a = () => i.abort(), d.addEventListener(`abort`, a)) : _ = i.signal);
                    let v = yield this.fetch(h.toString(), {
                        method: o || `POST`,
                        headers: Object.assign(Object.assign(Object.assign({}, p), this.headers), n),
                        body: g,
                        signal: _
                    }).catch(e => {
                        throw new c(e)
                    }), te = v.headers.get(`x-relay-error`);
                    if (te && te === `true`) throw new l(v);
                    if (!v.ok) throw new u(v);
                    let ne = (v.headers.get(`Content-Type`) ?? `text/plain`).split(`;`)[0].trim().toLowerCase(),
                        re;
                    return re = ne === `application/json` ? yield v.json(): ne === `application/octet-stream` || ne === `application/pdf` ? yield v.blob(): ne === `text/event-stream` ? v : ne === `multipart/form-data` ? yield v.formData(): yield v.text(), {
                        data: re,
                        error: null,
                        response: v
                    }
                } catch (e) {
                    return {
                        data: null,
                        error: e,
                        response: e instanceof u || e instanceof l ? e.context : void 0
                    }
                } finally {
                    r && clearTimeout(r), a && ((n = t.signal) == null || n.removeEventListener(`abort`, a))
                }
            })
        }
    },
    p = 3,
    m = e => Math.min(1e3 * 2 ** e, 3e4),
    h = [520, 503],
    g = [`GET`, `HEAD`, `OPTIONS`],
    ee = class extends Error {
        constructor(e) {
            super(e.message), this.name = `PostgrestError`, this.details = e.details, this.hint = e.hint, this.code = e.code
        }
        toJSON() {
            return {
                name: this.name,
                message: this.message,
                details: this.details,
                hint: this.hint,
                code: this.code
            }
        }
    };

function _(e) {
    "@babel/helpers - typeof";
    return _ = typeof Symbol == `function` && typeof Symbol.iterator == `symbol` ? function(e) {
        return typeof e
    } : function(e) {
        return e && typeof Symbol == `function` && e.constructor === Symbol && e !== Symbol.prototype ? `symbol` : typeof e
    }, _(e)
}

function v(e, t) {
    if (_(e) != `object` || !e) return e;
    var n = e[Symbol.toPrimitive];
    if (n !== void 0) {
        var r = n.call(e, t || `default`);
        if (_(r) != `object`) return r;
        throw TypeError(`@@toPrimitive must return a primitive value.`)
    }
    return (t === `string` ? String : Number)(e)
}

function te(e) {
    var t = v(e, `string`);
    return _(t) == `symbol` ? t : t + ``
}

function ne(e, t, n) {
    return (t = te(t)) in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function re(e, t) {
    var n = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t && (r = r.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable
        })), n.push.apply(n, r)
    }
    return n
}

function y(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] == null ? {} : arguments[t];
        t % 2 ? re(Object(n), !0).forEach(function(t) {
            ne(e, t, n[t])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : re(Object(n)).forEach(function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
        })
    }
    return e
}

function ie(e, t) {
    return new Promise(n => {
        if (t ?.aborted) {
            n();
            return
        }
        let r = setTimeout(() => {
            t ?.removeEventListener(`abort`, i), n()
        }, e);

        function i() {
            clearTimeout(r), n()
        }
        t ?.addEventListener(`abort`, i)
    })
}

function ae(e, t, n, r) {
    return !(!r || n >= p || !g.includes(e) || !h.includes(t))
}
var oe = class {
        constructor(e) {
            this.shouldThrowOnError = !1, this.retryEnabled = !0, this.method = e.method, this.url = e.url, this.headers = new Headers(e.headers), this.schema = e.schema, this.body = e.body, this.shouldThrowOnError = e.shouldThrowOnError ?? !1, this.signal = e.signal, this.isMaybeSingle = e.isMaybeSingle ?? !1, this.shouldStripNulls = e.shouldStripNulls ?? !1, this.urlLengthLimit = e.urlLengthLimit ?? 8e3, this.retryEnabled = e.retry ?? !0, this.fetch = e.fetch ? e.fetch : fetch
        }
        throwOnError() {
            return this.shouldThrowOnError = !0, this
        }
        stripNulls() {
            if (this.headers.get(`Accept`) === `text/csv`) throw Error(`stripNulls() cannot be used with csv()`);
            return this.shouldStripNulls = !0, this
        }
        setHeader(e, t) {
            return this.headers = new Headers(this.headers), this.headers.set(e, t), this
        }
        retry(e) {
            return this.retryEnabled = e, this
        }
        then(e, t) {
            var n = this;
            if (this.schema === void 0 || ([`GET`, `HEAD`].includes(this.method) ? this.headers.set(`Accept-Profile`, this.schema) : this.headers.set(`Content-Profile`, this.schema)), this.method !== `GET` && this.method !== `HEAD` && this.headers.set(`Content-Type`, `application/json`), this.shouldStripNulls) {
                let e = this.headers.get(`Accept`);
                e === `application/vnd.pgrst.object+json` ? this.headers.set(`Accept`, `application/vnd.pgrst.object+json;nulls=stripped`) : (!e || e === `application/json`) && this.headers.set(`Accept`, `application/vnd.pgrst.array+json;nulls=stripped`)
            }
            let r = this.fetch,
                i = (async () => {
                    let e = 0;
                    for (;;) {
                        let t = {};
                        n.headers.forEach((e, n) => {
                            t[n] = e
                        }), e > 0 && (t[`X-Retry-Count`] = String(e));
                        let i;
                        try {
                            i = await r(n.url.toString(), {
                                method: n.method,
                                headers: t,
                                body: JSON.stringify(n.body, (e, t) => typeof t == `bigint` ? t.toString() : t),
                                signal: n.signal
                            })
                        } catch (t) {
                            if (t ?.name === `AbortError` || t ?.code === `ABORT_ERR` || !g.includes(n.method)) throw t;
                            if (n.retryEnabled && e < p) {
                                let t = m(e);
                                e++, await ie(t, n.signal);
                                continue
                            }
                            throw t
                        }
                        if (ae(n.method, i.status, e, n.retryEnabled)) {
                            let t = i.headers ?.get(`Retry-After`) ?? null,
                                r = t === null ? m(e) : Math.max(0, parseInt(t, 10) || 0) * 1e3;
                            await i.text(), e++, await ie(r, n.signal);
                            continue
                        }
                        return await n.processResponse(i)
                    }
                })();
            return this.shouldThrowOnError || (i = i.catch(e => {
                let t = ``,
                    n = ``,
                    r = ``,
                    i = e ?.cause;
                if (i) {
                    let n = i ?.message ?? ``,
                        r = i ?.code ?? ``;
                    t = `${e?.name??`FetchError`}: ${e?.message}`, t += `\n\nCaused by: ${i?.name??`Error`}: ${n}`, r && (t += ` (${r})`), i ?.stack && (t += `\n${i.stack}`)
                } else t = e ?.stack ?? ``;
                let a = this.url.toString().length;
                return e ?.name === `AbortError` || e ?.code === `ABORT_ERR` ? (r = ``, n = `Request was aborted (timeout or manual cancellation)`, a > this.urlLengthLimit && (n += `. Note: Your request URL is ${a} characters, which may exceed server limits. If selecting many fields, consider using views. If filtering with large arrays (e.g., .in('id', [many IDs])), consider using an RPC function to pass values server-side.`)) : (i ?.name === `HeadersOverflowError` || i ?.code === `UND_ERR_HEADERS_OVERFLOW`) && (r = ``, n = `HTTP headers exceeded server limits (typically 16KB)`, a > this.urlLengthLimit && (n += `. Your request URL is ${a} characters. If selecting many fields, consider using views. If filtering with large arrays (e.g., .in('id', [200+ IDs])), consider using an RPC function instead.`)), {
                    success: !1,
                    error: {
                        message: `${e?.name??`FetchError`}: ${e?.message}`,
                        details: t,
                        hint: n,
                        code: r
                    },
                    data: null,
                    count: null,
                    status: 0,
                    statusText: ``
                }
            })), i.then(e, t)
        }
        async processResponse(e) {
            var t = this;
            let n = null,
                r = null,
                i = null,
                a = e.status,
                o = e.statusText;
            if (e.ok) {
                if (t.method !== `HEAD`) {
                    let i = await e.text();
                    if (i !== ``) {
                        if (t.headers.get(`Accept`) === `text/csv`) r = i;
                        else if (t.headers.get(`Accept`) && t.headers.get(`Accept`) ?.includes(`application/vnd.pgrst.plan+text`)) r = i;
                        else try {
                            r = JSON.parse(i)
                        } catch {
                            if (n = {
                                    message: i
                                }, r = null, t.shouldThrowOnError) throw new ee({
                                message: i,
                                details: ``,
                                hint: ``,
                                code: ``
                            })
                        }
                    }
                }
                let s = t.headers.get(`Prefer`) ?.match(/count=(exact|planned|estimated)/),
                    c = e.headers.get(`content-range`) ?.split(`/`);
                if (s && c && c.length > 1 && (i = parseInt(c[1])), t.isMaybeSingle && Array.isArray(r)) {
                    if (r.length > 1) {
                        if (n = {
                                code: `PGRST116`,
                                details: `Results contain ${r.length} rows, application/vnd.pgrst.object+json requires 1 row`,
                                hint: null,
                                message: `JSON object requested, multiple (or no) rows returned`
                            }, r = null, i = null, a = 406, o = `Not Acceptable`, t.shouldThrowOnError) throw new ee(y(y({}, n), {}, {
                            hint: n.hint ?? ``
                        }))
                    } else r = r.length === 1 ? r[0] : null
                }
            } else {
                let i = await e.text();
                try {
                    n = JSON.parse(i), Array.isArray(n) && e.status === 404 && (r = [], n = null, a = 200, o = `OK`)
                } catch {
                    e.status === 404 && i === `` ? (a = 204, o = `No Content`) : n = {
                        message: i
                    }
                }
                if (n && t.shouldThrowOnError) throw new ee(n)
            }
            return {
                success: n === null,
                error: n,
                data: r,
                count: i,
                status: a,
                statusText: o
            }
        }
        returns() {
            return this
        }
        overrideTypes() {
            return this
        }
    },
    se = class extends oe {
        throwOnError() {
            return super.throwOnError()
        }
        select(e) {
            let t = !1,
                n = (e ?? `*`).split(``).map(e => /\s/.test(e) && !t ? `` : (e === `"` && (t = !t), e)).join(``);
            return this.url.searchParams.set(`select`, n), this.headers.append(`Prefer`, `return=representation`), this
        }
        order(e, {
            ascending: t = !0,
            nullsFirst: n,
            foreignTable: r,
            referencedTable: i = r
        } = {}) {
            let a = i ? `${i}.order` : `order`,
                o = this.url.searchParams.get(a);
            return this.url.searchParams.set(a, `${o?`${o},`:``}${e}.${t?`asc`:`desc`}${n===void 0?``:n?`.nullsfirst`:`.nullslast`}`), this
        }
        limit(e, {
            foreignTable: t,
            referencedTable: n = t
        } = {}) {
            let r = n === void 0 ? `limit` : `${n}.limit`;
            return this.url.searchParams.set(r, `${e}`), this
        }
        range(e, t, {
            foreignTable: n,
            referencedTable: r = n
        } = {}) {
            let i = r === void 0 ? `offset` : `${r}.offset`,
                a = r === void 0 ? `limit` : `${r}.limit`;
            return this.url.searchParams.set(i, `${e}`), this.url.searchParams.set(a, `${t-e+1}`), this
        }
        abortSignal(e) {
            return this.signal = e, this
        }
        single() {
            return this.headers.set(`Accept`, `application/vnd.pgrst.object+json`), this
        }
        maybeSingle() {
            return this.isMaybeSingle = !0, this
        }
        csv() {
            return this.headers.set(`Accept`, `text/csv`), this
        }
        geojson() {
            return this.headers.set(`Accept`, `application/geo+json`), this
        }
        explain({
            analyze: e = !1,
            verbose: t = !1,
            settings: n = !1,
            buffers: r = !1,
            wal: i = !1,
            format: a = `text`
        } = {}) {
            let o = [e ? `analyze` : null, t ? `verbose` : null, n ? `settings` : null, r ? `buffers` : null, i ? `wal` : null].filter(Boolean).join(`|`),
                s = this.headers.get(`Accept`) ?? `application/json`;
            return this.headers.set(`Accept`, `application/vnd.pgrst.plan+${a}; for="${s}"; options=${o};`), this
        }
        rollback() {
            return this.headers.append(`Prefer`, `tx=rollback`), this
        }
        returns() {
            return this
        }
        maxAffected(e) {
            return this.headers.append(`Prefer`, `handling=strict`), this.headers.append(`Prefer`, `max-affected=${e}`), this
        }
    },
    ce = RegExp(`[,()]`),
    b = class extends se {
        throwOnError() {
            return super.throwOnError()
        }
        eq(e, t) {
            return this.url.searchParams.append(e, `eq.${t}`), this
        }
        neq(e, t) {
            return this.url.searchParams.append(e, `neq.${t}`), this
        }
        gt(e, t) {
            return this.url.searchParams.append(e, `gt.${t}`), this
        }
        gte(e, t) {
            return this.url.searchParams.append(e, `gte.${t}`), this
        }
        lt(e, t) {
            return this.url.searchParams.append(e, `lt.${t}`), this
        }
        lte(e, t) {
            return this.url.searchParams.append(e, `lte.${t}`), this
        }
        like(e, t) {
            return this.url.searchParams.append(e, `like.${t}`), this
        }
        likeAllOf(e, t) {
            return this.url.searchParams.append(e, `like(all).{${t.join(`,`)}}`), this
        }
        likeAnyOf(e, t) {
            return this.url.searchParams.append(e, `like(any).{${t.join(`,`)}}`), this
        }
        ilike(e, t) {
            return this.url.searchParams.append(e, `ilike.${t}`), this
        }
        ilikeAllOf(e, t) {
            return this.url.searchParams.append(e, `ilike(all).{${t.join(`,`)}}`), this
        }
        ilikeAnyOf(e, t) {
            return this.url.searchParams.append(e, `ilike(any).{${t.join(`,`)}}`), this
        }
        regexMatch(e, t) {
            return this.url.searchParams.append(e, `match.${t}`), this
        }
        regexIMatch(e, t) {
            return this.url.searchParams.append(e, `imatch.${t}`), this
        }
        is(e, t) {
            return this.url.searchParams.append(e, `is.${t}`), this
        }
        isDistinct(e, t) {
            return this.url.searchParams.append(e, `isdistinct.${t}`), this
        } in (e, t) {
            let n = Array.from(new Set(t)).map(e => typeof e == `string` && ce.test(e) ? `"${e}"` : `${e}`).join(`,`);
            return this.url.searchParams.append(e, `in.(${n})`), this
        }
        notIn(e, t) {
            let n = Array.from(new Set(t)).map(e => typeof e == `string` && ce.test(e) ? `"${e}"` : `${e}`).join(`,`);
            return this.url.searchParams.append(e, `not.in.(${n})`), this
        }
        contains(e, t) {
            return typeof t == `string` ? this.url.searchParams.append(e, `cs.${t}`) : Array.isArray(t) ? this.url.searchParams.append(e, `cs.{${t.join(`,`)}}`) : this.url.searchParams.append(e, `cs.${JSON.stringify(t)}`), this
        }
        containedBy(e, t) {
            return typeof t == `string` ? this.url.searchParams.append(e, `cd.${t}`) : Array.isArray(t) ? this.url.searchParams.append(e, `cd.{${t.join(`,`)}}`) : this.url.searchParams.append(e, `cd.${JSON.stringify(t)}`), this
        }
        rangeGt(e, t) {
            return this.url.searchParams.append(e, `sr.${t}`), this
        }
        rangeGte(e, t) {
            return this.url.searchParams.append(e, `nxl.${t}`), this
        }
        rangeLt(e, t) {
            return this.url.searchParams.append(e, `sl.${t}`), this
        }
        rangeLte(e, t) {
            return this.url.searchParams.append(e, `nxr.${t}`), this
        }
        rangeAdjacent(e, t) {
            return this.url.searchParams.append(e, `adj.${t}`), this
        }
        overlaps(e, t) {
            return typeof t == `string` ? this.url.searchParams.append(e, `ov.${t}`) : this.url.searchParams.append(e, `ov.{${t.join(`,`)}}`), this
        }
        textSearch(e, t, {
            config: n,
            type: r
        } = {}) {
            let i = ``;
            r === `plain` ? i = `pl` : r === `phrase` ? i = `ph` : r === `websearch` && (i = `w`);
            let a = n === void 0 ? `` : `(${n})`;
            return this.url.searchParams.append(e, `${i}fts${a}.${t}`), this
        }
        match(e) {
            return Object.entries(e).filter(([e, t]) => t !== void 0).forEach(([e, t]) => {
                this.url.searchParams.append(e, `eq.${t}`)
            }), this
        }
        not(e, t, n) {
            return this.url.searchParams.append(e, `not.${t}.${n}`), this
        }
        or(e, {
            foreignTable: t,
            referencedTable: n = t
        } = {}) {
            let r = n ? `${n}.or` : `or`;
            return this.url.searchParams.append(r, `(${e})`), this
        }
        filter(e, t, n) {
            return this.url.searchParams.append(e, `${t}.${n}`), this
        }
    },
    le = class {
        constructor(e, {
            headers: t = {},
            schema: n,
            fetch: r,
            urlLengthLimit: i = 8e3,
            retry: a
        }) {
            this.url = e, this.headers = new Headers(t), this.schema = n, this.fetch = r, this.urlLengthLimit = i, this.retry = a
        }
        cloneRequestState() {
            return {
                url: new URL(this.url.toString()),
                headers: new Headers(this.headers)
            }
        }
        select(e, t) {
            let {
                head: n = !1,
                count: r
            } = t ?? {}, i = n ? `HEAD` : `GET`, a = !1, o = (e ?? `*`).split(``).map(e => /\s/.test(e) && !a ? `` : (e === `"` && (a = !a), e)).join(``), {
                url: s,
                headers: c
            } = this.cloneRequestState();
            return s.searchParams.set(`select`, o), r && c.append(`Prefer`, `count=${r}`), new b({
                method: i,
                url: s,
                headers: c,
                schema: this.schema,
                fetch: this.fetch,
                urlLengthLimit: this.urlLengthLimit,
                retry: this.retry
            })
        }
        insert(e, {
            count: t,
            defaultToNull: n = !0
        } = {}) {
            let {
                url: r,
                headers: i
            } = this.cloneRequestState();
            if (t && i.append(`Prefer`, `count=${t}`), n || i.append(`Prefer`, `missing=default`), Array.isArray(e)) {
                let t = e.reduce((e, t) => e.concat(Object.keys(t)), []);
                if (t.length > 0) {
                    let e = [...new Set(t)].map(e => `"${e}"`);
                    r.searchParams.set(`columns`, e.join(`,`))
                }
            }
            return new b({
                method: `POST`,
                url: r,
                headers: i,
                schema: this.schema,
                body: e,
                fetch: this.fetch ?? fetch,
                urlLengthLimit: this.urlLengthLimit,
                retry: this.retry
            })
        }
        upsert(e, {
            onConflict: t,
            ignoreDuplicates: n = !1,
            count: r,
            defaultToNull: i = !0
        } = {}) {
            let {
                url: a,
                headers: o
            } = this.cloneRequestState();
            if (o.append(`Prefer`, `resolution=${n?`ignore`:`merge`}-duplicates`), t !== void 0 && a.searchParams.set(`on_conflict`, t), r && o.append(`Prefer`, `count=${r}`), i || o.append(`Prefer`, `missing=default`), Array.isArray(e)) {
                let t = e.reduce((e, t) => e.concat(Object.keys(t)), []);
                if (t.length > 0) {
                    let e = [...new Set(t)].map(e => `"${e}"`);
                    a.searchParams.set(`columns`, e.join(`,`))
                }
            }
            return new b({
                method: `POST`,
                url: a,
                headers: o,
                schema: this.schema,
                body: e,
                fetch: this.fetch ?? fetch,
                urlLengthLimit: this.urlLengthLimit,
                retry: this.retry
            })
        }
        update(e, {
            count: t
        } = {}) {
            let {
                url: n,
                headers: r
            } = this.cloneRequestState();
            return t && r.append(`Prefer`, `count=${t}`), new b({
                method: `PATCH`,
                url: n,
                headers: r,
                schema: this.schema,
                body: e,
                fetch: this.fetch ?? fetch,
                urlLengthLimit: this.urlLengthLimit,
                retry: this.retry
            })
        }
        delete({
            count: e
        } = {}) {
            let {
                url: t,
                headers: n
            } = this.cloneRequestState();
            return e && n.append(`Prefer`, `count=${e}`), new b({
                method: `DELETE`,
                url: t,
                headers: n,
                schema: this.schema,
                fetch: this.fetch ?? fetch,
                urlLengthLimit: this.urlLengthLimit,
                retry: this.retry
            })
        }
    },
    ue = class e {
        constructor(e, {
            headers: t = {},
            schema: n,
            fetch: r,
            timeout: i,
            urlLengthLimit: a = 8e3,
            retry: o
        } = {}) {
            this.url = e, this.headers = new Headers(t), this.schemaName = n, this.urlLengthLimit = a;
            let s = r ?? globalThis.fetch;
            this.fetch = i !== void 0 && i > 0 ? (e, t) => {
                let n = new AbortController,
                    r = setTimeout(() => n.abort(), i),
                    a = t ?.signal;
                if (a) {
                    if (a.aborted) return clearTimeout(r), s(e, t);
                    let i = () => {
                        clearTimeout(r), n.abort()
                    };
                    return a.addEventListener(`abort`, i, {
                        once: !0
                    }), s(e, y(y({}, t), {}, {
                        signal: n.signal
                    })).finally(() => {
                        clearTimeout(r), a.removeEventListener(`abort`, i)
                    })
                }
                return s(e, y(y({}, t), {}, {
                    signal: n.signal
                })).finally(() => clearTimeout(r))
            } : s, this.retry = o
        }
        from(e) {
            if (!e || typeof e != `string` || e.trim() === ``) throw Error(`Invalid relation name: relation must be a non-empty string.`);
            return new le(new URL(`${this.url}/${e}`), {
                headers: new Headers(this.headers),
                schema: this.schemaName,
                fetch: this.fetch,
                urlLengthLimit: this.urlLengthLimit,
                retry: this.retry
            })
        }
        schema(t) {
            return new e(this.url, {
                headers: this.headers,
                schema: t,
                fetch: this.fetch,
                urlLengthLimit: this.urlLengthLimit,
                retry: this.retry
            })
        }
        rpc(e, t = {}, {
            head: n = !1,
            get: r = !1,
            count: i
        } = {}) {
            let a, o = new URL(`${this.url}/rpc/${e}`),
                s, c = e => typeof e == `object` && !!e && (!Array.isArray(e) || e.some(c)),
                l = n && Object.values(t).some(c);
            l ? (a = `POST`, s = t) : n || r ? (a = n ? `HEAD` : `GET`, Object.entries(t).filter(([e, t]) => t !== void 0).map(([e, t]) => [e, Array.isArray(t) ? `{${t.join(`,`)}}` : `${t}`]).forEach(([e, t]) => {
                o.searchParams.append(e, t)
            })) : (a = `POST`, s = t);
            let u = new Headers(this.headers);
            return l ? u.set(`Prefer`, i ? `count=${i},return=minimal` : `return=minimal`) : i && u.set(`Prefer`, `count=${i}`), new b({
                method: a,
                url: o,
                headers: u,
                schema: this.schemaName,
                body: s,
                fetch: this.fetch ?? fetch,
                urlLengthLimit: this.urlLengthLimit,
                retry: this.retry
            })
        }
    },
    de = class {
        constructor() {}
        static detectEnvironment() {
            if (typeof WebSocket < `u`) return {
                type: `native`,
                wsConstructor: WebSocket
            };
            let e = globalThis;
            if (typeof globalThis < `u` && e.WebSocket !== void 0) return {
                type: `native`,
                wsConstructor: e.WebSocket
            };
            let t = typeof global < `u` ? global : void 0;
            if (t && t.WebSocket !== void 0) return {
                type: `native`,
                wsConstructor: t.WebSocket
            };
            if (typeof globalThis < `u` && e.WebSocketPair !== void 0 && globalThis.WebSocket === void 0) return {
                type: `cloudflare`,
                error: `Cloudflare Workers detected. WebSocket clients are not supported in Cloudflare Workers.`,
                workaround: `Use Cloudflare Workers WebSocket API for server-side WebSocket handling, or deploy to a different runtime.`
            };
            if (typeof globalThis < `u` && e.EdgeRuntime || typeof navigator < `u` && navigator.userAgent ?.includes(`Vercel-Edge`)) return {
                type: `unsupported`,
                error: `Edge runtime detected (Vercel Edge/Netlify Edge). WebSockets are not supported in edge functions.`,
                workaround: `Use serverless functions or a different deployment target for WebSocket functionality.`
            };
            let n = globalThis.process;
            if (n) {
                let e = n.versions;
                if (e && e.node) return {
                    type: `unsupported`,
                    error: `Node.js detected but native WebSocket not found.`,
                    workaround: `Ensure you are running Node.js 22+ or provide a WebSocket implementation via the transport option.`
                }
            }
            return {
                type: `unsupported`,
                error: `Unknown JavaScript runtime without WebSocket support.`,
                workaround: `Ensure you're running in a supported environment (browser, Node.js, Deno) or provide a custom WebSocket implementation.`
            }
        }
        static getWebSocketConstructor() {
            let e = this.detectEnvironment();
            if (e.wsConstructor) return e.wsConstructor;
            let t = e.error || `WebSocket not supported in this environment.`;
            throw e.workaround && (t += `\n\nSuggested solution: ${e.workaround}`), Error(t)
        }
        static isWebSocketSupported() {
            try {
                return this.detectEnvironment().type === `native`
            } catch {
                return !1
            }
        }
    },
    fe = `realtime-js/2.112.2`,
    pe = `1.0.0`,
    me = `2.0.0`,
    he = me,
    ge = 1e4,
    x = {
        closed: `closed`,
        errored: `errored`,
        joined: `joined`,
        joining: `joining`,
        leaving: `leaving`
    },
    _e = {
        close: `phx_close`,
        error: `phx_error`,
        join: `phx_join`,
        reply: `phx_reply`,
        leave: `phx_leave`,
        access_token: `access_token`
    },
    ve = {
        connecting: `connecting`,
        open: `open`,
        closing: `closing`,
        closed: `closed`
    },
    ye = class {
        constructor(e) {
            this.HEADER_LENGTH = 1, this.USER_BROADCAST_PUSH_META_LENGTH = 6, this.KINDS = {
                userBroadcastPush: 3,
                userBroadcast: 4
            }, this.BINARY_ENCODING = 0, this.JSON_ENCODING = 1, this.BROADCAST_EVENT = `broadcast`, this.allowedMetadataKeys = [], this.allowedMetadataKeys = e ?? []
        }
        encode(e, t) {
            if (e.event === this.BROADCAST_EVENT && !(e.payload instanceof ArrayBuffer) && typeof e.payload.event == `string`) return t(this._binaryEncodeUserBroadcastPush(e));
            let n = [e.join_ref, e.ref, e.topic, e.event, e.payload];
            return t(JSON.stringify(n))
        }
        _binaryEncodeUserBroadcastPush(e) {
            return this._isArrayBuffer(e.payload ?.payload) ? this._encodeBinaryUserBroadcastPush(e) : this._encodeJsonUserBroadcastPush(e)
        }
        _encodeBinaryUserBroadcastPush(e) {
            let t = e.payload ?.payload ?? new ArrayBuffer(0);
            return this._encodeUserBroadcastPush(e, this.BINARY_ENCODING, t)
        }
        _encodeJsonUserBroadcastPush(e) {
            let t = e.payload ?.payload ?? {},
                n = new TextEncoder().encode(JSON.stringify(t)).buffer;
            return this._encodeUserBroadcastPush(e, this.JSON_ENCODING, n)
        }
        _encodeUserBroadcastPush(e, t, n) {
            let r = new TextEncoder,
                i = r.encode(e.topic),
                a = r.encode(e.ref ?? ``),
                o = r.encode(e.join_ref ?? ``),
                s = r.encode(e.payload.event),
                c = this.allowedMetadataKeys ? this._pick(e.payload, this.allowedMetadataKeys) : {},
                l = r.encode(Object.keys(c).length === 0 ? `` : JSON.stringify(c));
            if (o.length > 255) throw Error(`joinRef length ${o.length} exceeds maximum of 255`);
            if (a.length > 255) throw Error(`ref length ${a.length} exceeds maximum of 255`);
            if (i.length > 255) throw Error(`topic length ${i.length} exceeds maximum of 255`);
            if (s.length > 255) throw Error(`userEvent length ${s.length} exceeds maximum of 255`);
            if (l.length > 255) throw Error(`metadata length ${l.length} exceeds maximum of 255`);
            let u = this.USER_BROADCAST_PUSH_META_LENGTH + o.length + a.length + i.length + s.length + l.length,
                d = new ArrayBuffer(this.HEADER_LENGTH + u),
                f = new DataView(d),
                p = new Uint8Array(d),
                m = 0;
            f.setUint8(m++, this.KINDS.userBroadcastPush), f.setUint8(m++, o.length), f.setUint8(m++, a.length), f.setUint8(m++, i.length), f.setUint8(m++, s.length), f.setUint8(m++, l.length), f.setUint8(m++, t), p.set(o, m), m += o.length, p.set(a, m), m += a.length, p.set(i, m), m += i.length, p.set(s, m), m += s.length, p.set(l, m), m += l.length;
            var h = new Uint8Array(d.byteLength + n.byteLength);
            return h.set(new Uint8Array(d), 0), h.set(new Uint8Array(n), d.byteLength), h.buffer
        }
        decode(e, t) {
            if (this._isArrayBuffer(e)) return t(this._binaryDecode(e));
            if (typeof e == `string`) {
                let [n, r, i, a, o] = JSON.parse(e);
                return t({
                    join_ref: n,
                    ref: r,
                    topic: i,
                    event: a,
                    payload: o
                })
            }
            return t({})
        }
        _binaryDecode(e) {
            let t = new DataView(e),
                n = t.getUint8(0),
                r = new TextDecoder;
            switch (n) {
                case this.KINDS.userBroadcast:
                    return this._decodeUserBroadcast(e, t, r)
            }
        }
        _decodeUserBroadcast(e, t, n) {
            let r = t.getUint8(1),
                i = t.getUint8(2),
                a = t.getUint8(3),
                o = t.getUint8(4),
                s = this.HEADER_LENGTH + 4,
                c = n.decode(e.slice(s, s + r));
            s += r;
            let l = n.decode(e.slice(s, s + i));
            s += i;
            let u = n.decode(e.slice(s, s + a));
            s += a;
            let d = e.slice(s, e.byteLength),
                f = o === this.JSON_ENCODING ? JSON.parse(n.decode(d)) : d,
                p = {
                    type: this.BROADCAST_EVENT,
                    event: l,
                    payload: f
                };
            return a > 0 && (p.meta = JSON.parse(u)), {
                join_ref: null,
                ref: null,
                topic: c,
                event: this.BROADCAST_EVENT,
                payload: p
            }
        }
        _isArrayBuffer(e) {
            return e instanceof ArrayBuffer || e ?.constructor ?.name === `ArrayBuffer`
        }
        _pick(e, t) {
            return !e || typeof e != `object` ? {} : Object.fromEntries(Object.entries(e).filter(([e]) => t.includes(e)))
        }
    },
    S;
(function(e) {
    e.abstime = `abstime`, e.bool = `bool`, e.date = `date`, e.daterange = `daterange`, e.float4 = `float4`, e.float8 = `float8`, e.int2 = `int2`, e.int4 = `int4`, e.int4range = `int4range`, e.int8 = `int8`, e.int8range = `int8range`, e.json = `json`, e.jsonb = `jsonb`, e.money = `money`, e.numeric = `numeric`, e.oid = `oid`, e.reltime = `reltime`, e.text = `text`, e.time = `time`, e.timestamp = `timestamp`, e.timestamptz = `timestamptz`, e.timetz = `timetz`, e.tsrange = `tsrange`, e.tstzrange = `tstzrange`
})(S ||= {});
var be = (e, t, n = {}) => {
        let r = n.skipTypes ?? [];
        return t ? Object.keys(t).reduce((n, i) => (n[i] = xe(i, e, t, r), n), {}) : {}
    },
    xe = (e, t, n, r) => {
        let i = t.find(t => t.name === e) ?.type,
            a = n[e];
        return i && !r.includes(i) ? Se(i, a) : Ce(a)
    },
    Se = (e, t) => {
        if (e.charAt(0) === `_`) return De(t, e.slice(1, e.length));
        switch (e) {
            case S.bool:
                return we(t);
            case S.float4:
            case S.float8:
            case S.int2:
            case S.int4:
            case S.int8:
            case S.numeric:
            case S.oid:
                return Te(t);
            case S.json:
            case S.jsonb:
                return Ee(t);
            case S.timestamp:
                return Oe(t);
            case S.abstime:
            case S.date:
            case S.daterange:
            case S.int4range:
            case S.int8range:
            case S.money:
            case S.reltime:
            case S.text:
            case S.time:
            case S.timestamptz:
            case S.timetz:
            case S.tsrange:
            case S.tstzrange:
                return Ce(t);
            default:
                return Ce(t)
        }
    },
    Ce = e => e,
    we = e => {
        switch (e) {
            case `t`:
                return !0;
            case `f`:
                return !1;
            default:
                return e
        }
    },
    Te = e => {
        if (typeof e == `string`) {
            let t = parseFloat(e);
            if (!Number.isNaN(t)) return t
        }
        return e
    },
    Ee = e => {
        if (typeof e == `string`) try {
            return JSON.parse(e)
        } catch {
            return e
        }
        return e
    },
    De = (e, t) => {
        if (typeof e != `string`) return e;
        let n = e.length - 1,
            r = e[n];
        if (e[0] === `{` && r === `}`) {
            let r, i = e.slice(1, n);
            try {
                r = JSON.parse(`[` + i + `]`)
            } catch {
                r = i ? i.split(`,`) : []
            }
            return r.map(e => Se(t, e))
        }
        return e
    },
    Oe = e => typeof e == `string` ? e.replace(` `, `T`) : e,
    ke = e => {
        let t = new URL(e);
        return t.protocol = t.protocol.replace(/^ws/i, `http`), t.pathname = t.pathname.replace(/\/+$/, ``).replace(/\/socket\/websocket$/i, ``).replace(/\/socket$/i, ``).replace(/\/websocket$/i, ``), t.pathname === `` || t.pathname === `/` ? t.pathname = `/api/broadcast` : t.pathname += `/api/broadcast`, t.href
    },
    Ae = e => typeof e == `function` ? e : function() {
        return e
    },
    je = typeof self < `u` ? self : null,
    Me = typeof window < `u` ? window : null,
    C = je || Me || globalThis,
    Ne = `2.0.0`,
    Pe = 1e4,
    Fe = 1e3,
    Ie = 100,
    w = {
        connecting: 0,
        open: 1,
        closing: 2,
        closed: 3
    },
    T = {
        closed: `closed`,
        errored: `errored`,
        joined: `joined`,
        joining: `joining`,
        leaving: `leaving`
    },
    E = {
        close: `phx_close`,
        error: `phx_error`,
        join: `phx_join`,
        reply: `phx_reply`,
        leave: `phx_leave`
    },
    Le = {
        longpoll: `longpoll`,
        websocket: `websocket`
    },
    Re = {
        complete: 4
    },
    ze = `base64url.bearer.phx.`,
    Be = class {
        constructor(e, t, n, r) {
            this.channel = e, this.event = t, this.payload = n || function() {
                return {}
            }, this.receivedResp = null, this.timeout = r, this.timeoutTimer = null, this.recHooks = [], this.sent = !1, this.ref = void 0
        }
        resend(e) {
            this.timeout = e, this.reset(), this.send()
        }
        send() {
            this.hasReceived(`timeout`) || (this.startTimeout(), this.sent = !0, this.channel.socket.push({
                topic: this.channel.topic,
                event: this.event,
                payload: this.payload(),
                ref: this.ref,
                join_ref: this.channel.joinRef()
            }))
        }
        receive(e, t) {
            return this.hasReceived(e) && t(this.receivedResp.response), this.recHooks.push({
                status: e,
                callback: t
            }), this
        }
        reset() {
            this.cancelRefEvent(), this.ref = null, this.refEvent = null, this.receivedResp = null, this.sent = !1
        }
        destroy() {
            this.cancelRefEvent(), this.cancelTimeout()
        }
        matchReceive({
            status: e,
            response: t,
            _ref: n
        }) {
            this.recHooks.filter(t => t.status === e).forEach(e => e.callback(t))
        }
        cancelRefEvent() {
            this.refEvent && this.channel.off(this.refEvent)
        }
        cancelTimeout() {
            clearTimeout(this.timeoutTimer), this.timeoutTimer = null
        }
        startTimeout() {
            this.timeoutTimer && this.cancelTimeout(), this.ref = this.channel.socket.makeRef(), this.refEvent = this.channel.replyEventName(this.ref), this.channel.on(this.refEvent, e => {
                this.cancelRefEvent(), this.cancelTimeout(), this.receivedResp = e, this.matchReceive(e)
            }), this.timeoutTimer = setTimeout(() => {
                this.trigger(`timeout`, {})
            }, this.timeout)
        }
        hasReceived(e) {
            return this.receivedResp && this.receivedResp.status === e
        }
        trigger(e, t) {
            this.channel.trigger(this.refEvent, {
                status: e,
                response: t
            })
        }
    },
    Ve = class {
        constructor(e, t) {
            this.callback = e, this.timerCalc = t, this.timer = void 0, this.tries = 0
        }
        reset() {
            this.tries = 0, clearTimeout(this.timer)
        }
        scheduleTimeout() {
            clearTimeout(this.timer), this.timer = setTimeout(() => {
                this.tries += 1, this.callback()
            }, this.timerCalc(this.tries + 1))
        }
    },
    He = class {
        constructor(e, t, n) {
            this.state = T.closed, this.topic = e, this.params = Ae(t || {}), this.socket = n, this.bindings = [], this.bindingRef = 0, this.timeout = this.socket.timeout, this.joinedOnce = !1, this.joinPush = new Be(this, E.join, this.params, this.timeout), this.pushBuffer = [], this.stateChangeRefs = [], this.rejoinTimer = new Ve(() => {
                this.socket.isConnected() && this.rejoin()
            }, this.socket.rejoinAfterMs), this.stateChangeRefs.push(this.socket.onError(() => this.rejoinTimer.reset())), this.stateChangeRefs.push(this.socket.onOpen(() => {
                this.rejoinTimer.reset(), this.isErrored() && this.rejoin()
            })), this.joinPush.receive(`ok`, () => {
                this.state = T.joined, this.rejoinTimer.reset(), this.pushBuffer.forEach(e => e.send()), this.pushBuffer = []
            }), this.joinPush.receive(`error`, e => {
                this.state = T.errored, this.socket.hasLogger() && this.socket.log(`channel`, `error ${this.topic}`, e), this.socket.isConnected() && this.rejoinTimer.scheduleTimeout()
            }), this.onClose(() => {
                this.rejoinTimer.reset(), this.socket.hasLogger() && this.socket.log(`channel`, `close ${this.topic}`), this.state = T.closed, this.socket.remove(this)
            }), this.onError(e => {
                this.socket.hasLogger() && this.socket.log(`channel`, `error ${this.topic}`, e), this.isJoining() && this.joinPush.reset(), this.state = T.errored, this.socket.isConnected() && this.rejoinTimer.scheduleTimeout()
            }), this.joinPush.receive(`timeout`, () => {
                this.socket.hasLogger() && this.socket.log(`channel`, `timeout ${this.topic}`, this.joinPush.timeout), new Be(this, E.leave, Ae({}), this.timeout).send(), this.state = T.errored, this.joinPush.reset(), this.socket.isConnected() && this.rejoinTimer.scheduleTimeout()
            }), this.on(E.reply, (e, t) => {
                this.trigger(this.replyEventName(t), e)
            })
        }
        join(e = this.timeout) {
            if (this.joinedOnce) throw Error(`tried to join multiple times. 'join' can only be called a single time per channel instance`);
            return this.timeout = e, this.joinedOnce = !0, this.rejoin(), this.joinPush
        }
        teardown() {
            this.pushBuffer.forEach(e => e.destroy()), this.pushBuffer = [], this.rejoinTimer.reset(), this.joinPush.destroy(), this.state = T.closed, this.bindings = []
        }
        onClose(e) {
            this.on(E.close, e)
        }
        onError(e) {
            return this.on(E.error, t => e(t))
        }
        on(e, t) {
            let n = this.bindingRef++;
            return this.bindings.push({
                event: e,
                ref: n,
                callback: t
            }), n
        }
        off(e, t) {
            this.bindings = this.bindings.filter(n => n.event !== e || t !== void 0 && t !== n.ref)
        }
        canPush() {
            return this.socket.isConnected() && this.isJoined()
        }
        push(e, t, n = this.timeout) {
            if (t ||= {}, !this.joinedOnce) throw Error(`tried to push '${e}' to '${this.topic}' before joining. Use channel.join() before pushing events`);
            let r = new Be(this, e, function() {
                return t
            }, n);
            return this.canPush() ? r.send() : (r.startTimeout(), this.pushBuffer.push(r)), r
        }
        leave(e = this.timeout) {
            this.rejoinTimer.reset(), this.joinPush.cancelTimeout(), this.state = T.leaving;
            let t = () => {
                    this.socket.hasLogger() && this.socket.log(`channel`, `leave ${this.topic}`), this.trigger(E.close, `leave`)
                },
                n = new Be(this, E.leave, Ae({}), e);
            return n.receive(`ok`, () => t()).receive(`timeout`, () => t()), n.send(), this.canPush() || n.trigger(`ok`, {}), n
        }
        onMessage(e, t, n) {
            return t
        }
        filterBindings(e, t, n) {
            return !0
        }
        isMember(e, t, n, r) {
            return this.topic === e ? r && r !== this.joinRef() ? (this.socket.hasLogger() && this.socket.log(`channel`, `dropping outdated message`, {
                topic: e,
                event: t,
                payload: n,
                joinRef: r
            }), !1) : !0 : !1
        }
        joinRef() {
            return this.joinPush.ref
        }
        rejoin(e = this.timeout) {
            this.isLeaving() || (this.socket.leaveOpenTopic(this.topic), this.state = T.joining, this.joinPush.resend(e))
        }
        trigger(e, t, n, r) {
            let i = this.onMessage(e, t, n, r);
            if (t && !i) throw Error(`channel onMessage callbacks must return the payload, modified or unmodified`);
            let a = this.bindings.filter(r => r.event === e && this.filterBindings(r, t, n));
            for (let e = 0; e < a.length; e++) a[e].callback(i, n, r || this.joinRef())
        }
        replyEventName(e) {
            return `chan_reply_${e}`
        }
        isClosed() {
            return this.state === T.closed
        }
        isErrored() {
            return this.state === T.errored
        }
        isJoined() {
            return this.state === T.joined
        }
        isJoining() {
            return this.state === T.joining
        }
        isLeaving() {
            return this.state === T.leaving
        }
    },
    Ue = class {
        static request(e, t, n, r, i, a, o) {
            if (C.XDomainRequest) {
                let n = new C.XDomainRequest;
                return this.xdomainRequest(n, e, t, r, i, a, o)
            }
            if (C.XMLHttpRequest) {
                let s = new C.XMLHttpRequest;
                return this.xhrRequest(s, e, t, n, r, i, a, o)
            }
            if (C.fetch && C.AbortController) return this.fetchRequest(e, t, n, r, i, a, o);
            throw Error(`No suitable XMLHttpRequest implementation found`)
        }
        static fetchRequest(e, t, n, r, i, a, o) {
            let s = {
                    method: e,
                    headers: n,
                    body: r
                },
                c = null;
            return i && (c = new AbortController, setTimeout(() => c.abort(), i), s.signal = c.signal), C.fetch(t, s).then(e => e.text()).then(e => this.parseJSON(e)).then(e => o && o(e)).catch(e => {
                e.name === `AbortError` && a ? a() : o && o(null)
            }), c
        }
        static xdomainRequest(e, t, n, r, i, a, o) {
            return e.timeout = i, e.open(t, n), e.onload = () => {
                let t = this.parseJSON(e.responseText);
                o && o(t)
            }, a && (e.ontimeout = a), e.onprogress = () => {}, e.send(r), e
        }
        static xhrRequest(e, t, n, r, i, a, o, s) {
            e.open(t, n, !0), e.timeout = a;
            for (let [t, n] of Object.entries(r)) e.setRequestHeader(t, n);
            return e.onerror = () => s && s(null), e.onreadystatechange = () => {
                e.readyState === Re.complete && s && s(this.parseJSON(e.responseText))
            }, o && (e.ontimeout = o), e.send(i), e
        }
        static parseJSON(e) {
            if (!e || e === ``) return null;
            try {
                return JSON.parse(e)
            } catch {
                return console && console.log(`failed to parse JSON response`, e), null
            }
        }
        static serialize(e, t) {
            let n = [];
            for (var r in e) {
                if (!Object.prototype.hasOwnProperty.call(e, r)) continue;
                let i = t ? `${t}[${r}]` : r,
                    a = e[r];
                typeof a == `object` ? n.push(this.serialize(a, i)) : n.push(encodeURIComponent(i) + `=` + encodeURIComponent(a))
            }
            return n.join(`&`)
        }
        static appendParams(e, t) {
            return Object.keys(t).length === 0 ? e : `${e}${e.match(/\?/)?`&`:`?`}${this.serialize(t)}`
        }
    },
    We = e => {
        let t = ``,
            n = new Uint8Array(e),
            r = n.byteLength;
        for (let e = 0; e < r; e++) t += String.fromCharCode(n[e]);
        return btoa(t)
    },
    D = class {
        constructor(e, t) {
            t && t.length === 2 && t[1].startsWith(ze) && (this.authToken = atob(t[1].slice(ze.length))), this.endPoint = null, this.token = null, this.skipHeartbeat = !0, this.reqs = new Set, this.awaitingBatchAck = !1, this.currentBatch = null, this.currentBatchTimer = null, this.batchBuffer = [], this.onopen = function() {}, this.onerror = function() {}, this.onmessage = function() {}, this.onclose = function() {}, this.pollEndpoint = this.normalizeEndpoint(e), this.readyState = w.connecting, setTimeout(() => this.poll(), 0)
        }
        normalizeEndpoint(e) {
            return e.replace(`ws://`, `http://`).replace(`wss://`, `https://`).replace(RegExp(`(.*)/` + Le.websocket), `$1/` + Le.longpoll)
        }
        endpointURL() {
            return Ue.appendParams(this.pollEndpoint, {
                token: this.token
            })
        }
        closeAndRetry(e, t, n) {
            this.close(e, t, n), this.readyState = w.connecting
        }
        ontimeout() {
            this.onerror(`timeout`), this.closeAndRetry(1005, `timeout`, !1)
        }
        isActive() {
            return this.readyState === w.open || this.readyState === w.connecting
        }
        poll() {
            let e = {
                Accept: `application/json`
            };
            this.authToken && (e[`X-Phoenix-AuthToken`] = this.authToken), this.ajax(`GET`, e, null, () => this.ontimeout(), e => {
                if (e) {
                    var {
                        status: t,
                        token: n,
                        messages: r
                    } = e;
                    if (t === 410 && this.token !== null) {
                        this.onerror(410), this.closeAndRetry(3410, `session_gone`, !1);
                        return
                    }
                    this.token = n
                } else t = 0;
                switch (t) {
                    case 200:
                        r.forEach(e => {
                            setTimeout(() => this.onmessage({
                                data: e
                            }), 0)
                        }), this.poll();
                        break;
                    case 204:
                        this.poll();
                        break;
                    case 410:
                        this.readyState = w.open, this.onopen({}), this.poll();
                        break;
                    case 403:
                        this.onerror(403), this.close(1008, `forbidden`, !1);
                        break;
                    case 0:
                    case 500:
                        this.onerror(500), this.closeAndRetry(1011, `internal server error`, 500);
                        break;
                    default:
                        throw Error(`unhandled poll status ${t}`)
                }
            })
        }
        send(e) {
            typeof e != `string` && (e = We(e)), this.currentBatch ? this.currentBatch.push(e) : this.awaitingBatchAck ? this.batchBuffer.push(e) : (this.currentBatch = [e], this.currentBatchTimer = setTimeout(() => {
                this.batchSend(this.currentBatch), this.currentBatch = null
            }, 0))
        }
        batchSend(e, t = 0) {
            this.awaitingBatchAck = !0;
            let n = t + Ie,
                r = e.slice(t, n);
            this.ajax(`POST`, {
                "Content-Type": `application/x-ndjson`
            }, r.join(`
`), () => this.onerror(`timeout`), t => {
                !t || t.status !== 200 ? (this.awaitingBatchAck = !1, this.onerror(t && t.status), this.closeAndRetry(1011, `internal server error`, !1)) : n < e.length ? this.batchSend(e, n) : this.batchBuffer.length > 0 ? (this.batchSend(this.batchBuffer), this.batchBuffer = []) : this.awaitingBatchAck = !1
            })
        }
        close(e, t, n) {
            for (let e of this.reqs) e.abort();
            this.readyState = w.closed;
            let r = Object.assign({
                code: 1e3,
                reason: void 0,
                wasClean: !0
            }, {
                code: e,
                reason: t,
                wasClean: n
            });
            this.batchBuffer = [], clearTimeout(this.currentBatchTimer), this.currentBatchTimer = null, typeof CloseEvent < `u` ? this.onclose(new CloseEvent(`close`, r)) : this.onclose(r)
        }
        ajax(e, t, n, r, i) {
            let a;
            a = Ue.request(e, this.endpointURL(), t, n, this.timeout, () => {
                this.reqs.delete(a), r()
            }, e => {
                this.reqs.delete(a), this.isActive() && i(e)
            }), this.reqs.add(a)
        }
    },
    Ge = class e {
        constructor(t, n = {}) {
            let r = n.events || {
                state: `presence_state`,
                diff: `presence_diff`
            };
            this.state = Object.create(null), this.pendingDiffs = [], this.channel = t, this.joinRef = null, this.caller = {
                onJoin: function() {},
                onLeave: function() {},
                onSync: function() {}
            }, this.channel.on(r.state, t => {
                let {
                    onJoin: n,
                    onLeave: r,
                    onSync: i
                } = this.caller;
                this.joinRef = this.channel.joinRef(), this.state = e.syncState(this.state, t, n, r), this.pendingDiffs.forEach(t => {
                    this.state = e.syncDiff(this.state, t, n, r)
                }), this.pendingDiffs = [], i()
            }), this.channel.on(r.diff, t => {
                let {
                    onJoin: n,
                    onLeave: r,
                    onSync: i
                } = this.caller;
                this.inPendingSyncState() ? this.pendingDiffs.push(t) : (this.state = e.syncDiff(this.state, t, n, r), i())
            })
        }
        onJoin(e) {
            this.caller.onJoin = e
        }
        onLeave(e) {
            this.caller.onLeave = e
        }
        onSync(e) {
            this.caller.onSync = e
        }
        list(t) {
            return e.list(this.state, t)
        }
        inPendingSyncState() {
            return !this.joinRef || this.joinRef !== this.channel.joinRef()
        }
        static syncState(e, t, n, r) {
            let i = this.toNullProtoObj(this.clone(e));
            t = this.toNullProtoObj(t);
            let a = Object.create(null),
                o = Object.create(null);
            return this.map(i, (e, n) => {
                t[e] || (o[e] = n)
            }), this.map(t, (e, t) => {
                let n = i[e];
                if (n) {
                    let r = t.metas.map(e => e.phx_ref),
                        i = n.metas.map(e => e.phx_ref),
                        s = t.metas.filter(e => i.indexOf(e.phx_ref) < 0),
                        c = n.metas.filter(e => r.indexOf(e.phx_ref) < 0);
                    s.length > 0 && (a[e] = t, a[e].metas = s), c.length > 0 && (o[e] = this.clone(n), o[e].metas = c)
                } else a[e] = t
            }), this.syncDiff(i, {
                joins: a,
                leaves: o
            }, n, r)
        }
        static syncDiff(e, t, n, r) {
            e = this.toNullProtoObj(e);
            let {
                joins: i,
                leaves: a
            } = this.clone(t);
            return n ||= function() {}, r ||= function() {}, this.map(i, (t, r) => {
                let i = e[t];
                if (e[t] = this.clone(r), i) {
                    let n = e[t].metas.map(e => e.phx_ref),
                        r = i.metas.filter(e => n.indexOf(e.phx_ref) < 0);
                    e[t].metas.unshift(...r)
                }
                n(t, i, r)
            }), this.map(a, (t, n) => {
                let i = e[t];
                if (!i) return;
                let a = n.metas.map(e => e.phx_ref);
                i.metas = i.metas.filter(e => a.indexOf(e.phx_ref) < 0), r(t, i, n), i.metas.length === 0 && delete e[t]
            }), e
        }
        static list(e, t) {
            return t ||= function(e, t) {
                return t
            }, this.map(e, (e, n) => t(e, n))
        }
        static map(e, t) {
            return Object.getOwnPropertyNames(e).map(n => t(n, e[n]))
        }
        static toNullProtoObj(e) {
            if (Object.getPrototypeOf(e) === null) return e;
            let t = Object.create(null);
            return Object.getOwnPropertyNames(e).forEach(n => {
                t[n] = e[n]
            }), t
        }
        static clone(e) {
            return JSON.parse(JSON.stringify(e))
        }
    },
    Ke = {
        HEADER_LENGTH: 1,
        META_LENGTH: 4,
        KINDS: {
            push: 0,
            reply: 1,
            broadcast: 2
        },
        encode(e, t) {
            if (e.payload.constructor === ArrayBuffer) return t(this.binaryEncode(e)); {
                let n = [e.join_ref, e.ref, e.topic, e.event, e.payload];
                return t(JSON.stringify(n))
            }
        },
        decode(e, t) {
            if (e.constructor === ArrayBuffer) return t(this.binaryDecode(e)); {
                let [n, r, i, a, o] = JSON.parse(e);
                return t({
                    join_ref: n,
                    ref: r,
                    topic: i,
                    event: a,
                    payload: o
                })
            }
        },
        binaryEncode(e) {
            let {
                join_ref: t,
                ref: n,
                event: r,
                topic: i,
                payload: a
            } = e, o = new TextEncoder, s = o.encode(t), c = o.encode(n), l = o.encode(i), u = o.encode(r);
            this.assertFieldSize(s.byteLength, `join_ref`), this.assertFieldSize(c.byteLength, `ref`), this.assertFieldSize(l.byteLength, `topic`), this.assertFieldSize(u.byteLength, `event`);
            let d = this.META_LENGTH + s.byteLength + c.byteLength + l.byteLength + u.byteLength,
                f = new ArrayBuffer(this.HEADER_LENGTH + d),
                p = new Uint8Array(f),
                m = new DataView(f),
                h = 0;
            m.setUint8(h++, this.KINDS.push), m.setUint8(h++, s.byteLength), m.setUint8(h++, c.byteLength), m.setUint8(h++, l.byteLength), m.setUint8(h++, u.byteLength), p.set(s, h), h += s.byteLength, p.set(c, h), h += c.byteLength, p.set(l, h), h += l.byteLength, p.set(u, h), h += u.byteLength;
            var g = new Uint8Array(f.byteLength + a.byteLength);
            return g.set(p, 0), g.set(new Uint8Array(a), f.byteLength), g.buffer
        },
        assertFieldSize(e, t) {
            if (e > 255) throw Error(`unable to convert ${t} to binary: must be less than or equal to 255 bytes, but is ${e} bytes`)
        },
        binaryDecode(e) {
            let t = new DataView(e),
                n = t.getUint8(0),
                r = new TextDecoder;
            switch (n) {
                case this.KINDS.push:
                    return this.decodePush(e, t, r);
                case this.KINDS.reply:
                    return this.decodeReply(e, t, r);
                case this.KINDS.broadcast:
                    return this.decodeBroadcast(e, t, r)
            }
        },
        decodePush(e, t, n) {
            let r = t.getUint8(1),
                i = t.getUint8(2),
                a = t.getUint8(3),
                o = this.HEADER_LENGTH + this.META_LENGTH - 1,
                s = n.decode(e.slice(o, o + r));
            o += r;
            let c = n.decode(e.slice(o, o + i));
            o += i;
            let l = n.decode(e.slice(o, o + a));
            return o += a, {
                join_ref: s,
                ref: null,
                topic: c,
                event: l,
                payload: e.slice(o, e.byteLength)
            }
        },
        decodeReply(e, t, n) {
            let r = t.getUint8(1),
                i = t.getUint8(2),
                a = t.getUint8(3),
                o = t.getUint8(4),
                s = this.HEADER_LENGTH + this.META_LENGTH,
                c = n.decode(e.slice(s, s + r));
            s += r;
            let l = n.decode(e.slice(s, s + i));
            s += i;
            let u = n.decode(e.slice(s, s + a));
            s += a;
            let d = n.decode(e.slice(s, s + o));
            s += o;
            let f = {
                status: d,
                response: e.slice(s, e.byteLength)
            };
            return {
                join_ref: c,
                ref: l,
                topic: u,
                event: E.reply,
                payload: f
            }
        },
        decodeBroadcast(e, t, n) {
            let r = t.getUint8(1),
                i = t.getUint8(2),
                a = this.HEADER_LENGTH + 2,
                o = n.decode(e.slice(a, a + r));
            a += r;
            let s = n.decode(e.slice(a, a + i));
            return a += i, {
                join_ref: null,
                ref: null,
                topic: o,
                event: s,
                payload: e.slice(a, e.byteLength)
            }
        }
    },
    qe = class {
        constructor(e, t = {}) {
            this.stateChangeCallbacks = {
                open: [],
                close: [],
                error: [],
                message: []
            }, this.channels = [], this.sendBuffer = [], this.ref = 0, this.fallbackRef = null, this.timeout = t.timeout || Pe, this.transport = t.transport || C.WebSocket || D, this.conn = void 0, this.primaryPassedHealthCheck = !1, this.longPollFallbackMs = t.longPollFallbackMs, this.fallbackTimer = null;
            let n = null;
            try {
                n = C && C.sessionStorage
            } catch {}
            this.sessionStore = t.sessionStorage || n, this.establishedConnections = 0, this.defaultEncoder = Ke.encode.bind(Ke), this.defaultDecoder = Ke.decode.bind(Ke), this.closeWasClean = !0, this.disconnecting = !1, this.binaryType = t.binaryType || `arraybuffer`, this.connectClock = 1, this.pageHidden = !1, this.encode = void 0, this.decode = void 0, this.transport === D ? (this.encode = this.defaultEncoder, this.decode = this.defaultDecoder) : (this.encode = t.encode || this.defaultEncoder, this.decode = t.decode || this.defaultDecoder);
            let r = null;
            Me && Me.addEventListener && (Me.addEventListener(`pagehide`, e => {
                this.conn && (this.disconnect(), r = this.connectClock)
            }), Me.addEventListener(`pageshow`, e => {
                r === this.connectClock && (r = null, this.connect())
            }), Me.addEventListener(`visibilitychange`, () => {
                document.visibilityState === `hidden` ? this.pageHidden = !0 : (this.pageHidden = !1, !this.isConnected() && !this.closeWasClean && this.teardown(() => this.connect()))
            })), this.heartbeatIntervalMs = t.heartbeatIntervalMs || 3e4, this.autoSendHeartbeat = t.autoSendHeartbeat ?? !0, this.heartbeatCallback = t.heartbeatCallback ?? (() => {}), this.rejoinAfterMs = e => t.rejoinAfterMs ? t.rejoinAfterMs(e) : [1e3, 2e3, 5e3][e - 1] || 1e4, this.reconnectAfterMs = e => t.reconnectAfterMs ? t.reconnectAfterMs(e) : [10, 50, 100, 150, 200, 250, 500, 1e3, 2e3][e - 1] || 5e3, this.logger = t.logger || null, !this.logger && t.debug && (this.logger = (e, t, n) => {
                console.log(`${e}: ${t}`, n)
            }), this.longpollerTimeout = t.longpollerTimeout || 2e4, this.params = Ae(t.params || {}), this.endPoint = `${e}/${Le.websocket}`, this.vsn = t.vsn || Ne, this.heartbeatTimeoutTimer = null, this.heartbeatTimer = null, this.heartbeatSentAt = null, this.pendingHeartbeatRef = null, this.reconnectTimer = new Ve(() => {
                if (this.pageHidden) {
                    this.log(`Not reconnecting as page is hidden!`), this.teardown();
                    return
                }
                this.teardown(async () => {
                    t.beforeReconnect && await t.beforeReconnect(), this.connect()
                })
            }, this.reconnectAfterMs), this.authToken = t.authToken && Ae(t.authToken)
        }
        getLongPollTransport() {
            return D
        }
        replaceTransport(e) {
            this.connectClock++, this.closeWasClean = !0, clearTimeout(this.fallbackTimer), this.reconnectTimer.reset(), this.conn &&= (this.conn.close(), null), this.transport = e
        }
        protocol() {
            return location.protocol.match(/^https/) ? `wss` : `ws`
        }
        endPointURL() {
            let e = Ue.appendParams(Ue.appendParams(this.endPoint, this.params()), {
                vsn: this.vsn
            });
            return e.charAt(0) === `/` ? e.charAt(1) === `/` ? `${this.protocol()}:${e}` : `${this.protocol()}://${location.host}${e}` : e
        }
        disconnect(e, t, n) {
            this.connectClock++, this.disconnecting = !0, this.closeWasClean = !0, clearTimeout(this.fallbackTimer), this.reconnectTimer.reset(), this.teardown(() => {
                this.disconnecting = !1, e && e()
            }, t, n)
        }
        connect(e) {
            e && (console && console.log(`passing params to connect is deprecated. Instead pass :params to the Socket constructor`), this.params = Ae(e)), !(this.conn && !this.disconnecting) && (this.longPollFallbackMs && this.transport !== D ? this.connectWithFallback(D, this.longPollFallbackMs) : this.transportConnect())
        }
        log(e, t, n) {
            this.logger && this.logger(e, t, n)
        }
        hasLogger() {
            return this.logger !== null
        }
        onOpen(e) {
            let t = this.makeRef();
            return this.stateChangeCallbacks.open.push([t, e]), t
        }
        onClose(e) {
            let t = this.makeRef();
            return this.stateChangeCallbacks.close.push([t, e]), t
        }
        onError(e) {
            let t = this.makeRef();
            return this.stateChangeCallbacks.error.push([t, e]), t
        }
        onMessage(e) {
            let t = this.makeRef();
            return this.stateChangeCallbacks.message.push([t, e]), t
        }
        onHeartbeat(e) {
            this.heartbeatCallback = e
        }
        ping(e) {
            if (!this.isConnected()) return !1;
            let t = this.makeRef(),
                n = Date.now();
            this.push({
                topic: `phoenix`,
                event: `heartbeat`,
                payload: {},
                ref: t
            });
            let r = this.onMessage(i => {
                i.ref === t && (this.off([r]), e(Date.now() - n))
            });
            return !0
        }
        transportName(e) {
            switch (e) {
                case D:
                    return `LongPoll`;
                default:
                    return e.name
            }
        }
        transportConnect() {
            this.connectClock++, this.closeWasClean = !1;
            let e;
            this.authToken && (e = [`phoenix`, `${ze}${btoa(this.authToken()).replace(/=/g,``)}`]), this.conn = new this.transport(this.endPointURL(), e), this.conn.binaryType = this.binaryType, this.conn.timeout = this.longpollerTimeout, this.conn.onopen = () => this.onConnOpen(), this.conn.onerror = e => this.onConnError(e), this.conn.onmessage = e => this.onConnMessage(e), this.conn.onclose = e => this.onConnClose(e)
        }
        getSession(e) {
            return this.sessionStore && this.sessionStore.getItem(e)
        }
        storeSession(e, t) {
            this.sessionStore && this.sessionStore.setItem(e, t)
        }
        connectWithFallback(e, t = 2500) {
            clearTimeout(this.fallbackTimer);
            let n = !1,
                r = !0,
                i, a, o = this.transportName(e),
                s = t => {
                    this.log(`transport`, `falling back to ${o}...`, t), this.off([i, a]), r = !1, this.replaceTransport(e), this.transportConnect()
                };
            if (this.getSession(`phx:fallback:${o}`)) return s(`memorized`);
            this.fallbackTimer = setTimeout(s, t), a = this.onError(e => {
                this.log(`transport`, `error`, e), r && !n && (clearTimeout(this.fallbackTimer), s(e))
            }), this.fallbackRef && this.off([this.fallbackRef]), this.fallbackRef = this.onOpen(() => {
                if (n = !0, !r) {
                    let t = this.transportName(e);
                    return this.primaryPassedHealthCheck || this.storeSession(`phx:fallback:${t}`, `true`), this.log(`transport`, `established ${t} fallback`)
                }
                clearTimeout(this.fallbackTimer), this.fallbackTimer = setTimeout(s, t), this.ping(e => {
                    this.log(`transport`, `connected to primary after`, e), this.primaryPassedHealthCheck = !0, clearTimeout(this.fallbackTimer)
                })
            }), this.transportConnect()
        }
        clearHeartbeats() {
            clearTimeout(this.heartbeatTimer), clearTimeout(this.heartbeatTimeoutTimer)
        }
        onConnOpen() {
            this.hasLogger() && this.log(`transport`, `connected to ${this.endPointURL()}`), this.closeWasClean = !1, this.disconnecting = !1, this.establishedConnections++, this.flushSendBuffer(), this.reconnectTimer.reset(), this.autoSendHeartbeat && this.resetHeartbeat(), this.triggerStateCallbacks(`open`)
        }
        heartbeatTimeout() {
            if (this.pendingHeartbeatRef) {
                this.pendingHeartbeatRef = null, this.heartbeatSentAt = null, this.hasLogger() && this.log(`transport`, `heartbeat timeout. Attempting to re-establish connection`);
                try {
                    this.heartbeatCallback(`timeout`)
                } catch (e) {
                    this.log(`error`, `error in heartbeat callback`, e)
                }
                this.triggerChanError(Error(`heartbeat timeout`)), this.closeWasClean = !1, this.teardown(() => this.reconnectTimer.scheduleTimeout(), Fe, `heartbeat timeout`)
            }
        }
        resetHeartbeat() {
            this.conn && this.conn.skipHeartbeat || (this.pendingHeartbeatRef = null, this.clearHeartbeats(), this.heartbeatTimer = setTimeout(() => this.sendHeartbeat(), this.heartbeatIntervalMs))
        }
        teardown(e, t, n) {
            if (!this.conn) return e && e();
            let r = this.conn;
            this.waitForBufferDone(r, () => {
                t ? r.close(t, n || ``) : r.close(), this.waitForSocketClosed(r, () => {
                    this.conn === r && (this.conn.onopen = function() {}, this.conn.onerror = function() {}, this.conn.onmessage = function() {}, this.conn.onclose = function() {}, this.conn = null), e && e()
                })
            })
        }
        waitForBufferDone(e, t, n = 1) {
            if (n === 5 || !e.bufferedAmount) {
                t();
                return
            }
            setTimeout(() => {
                this.waitForBufferDone(e, t, n + 1)
            }, 150 * n)
        }
        waitForSocketClosed(e, t, n = 1) {
            if (n === 5 || e.readyState === w.closed) {
                t();
                return
            }
            setTimeout(() => {
                this.waitForSocketClosed(e, t, n + 1)
            }, 150 * n)
        }
        onConnClose(e) {
            this.conn && (this.conn.onclose = () => {}), this.hasLogger() && this.log(`transport`, `close`, e), this.triggerChanError(e), this.clearHeartbeats(), this.closeWasClean || this.reconnectTimer.scheduleTimeout(), this.triggerStateCallbacks(`close`, e)
        }
        onConnError(e) {
            this.hasLogger() && this.log(`transport`, `error`, e);
            let t = this.transport,
                n = this.establishedConnections;
            this.triggerStateCallbacks(`error`, e, t, n), (t === this.transport || n > 0) && this.triggerChanError(e)
        }
        triggerChanError(e) {
            this.channels.forEach(t => {
                t.isErrored() || t.isLeaving() || t.isClosed() || t.trigger(E.error, e)
            })
        }
        connectionState() {
            switch (this.conn && this.conn.readyState) {
                case w.connecting:
                    return `connecting`;
                case w.open:
                    return `open`;
                case w.closing:
                    return `closing`;
                default:
                    return `closed`
            }
        }
        isConnected() {
            return this.connectionState() === `open`
        }
        remove(e) {
            this.off(e.stateChangeRefs), this.channels = this.channels.filter(t => t !== e)
        }
        off(e) {
            for (let t in this.stateChangeCallbacks) this.stateChangeCallbacks[t] = this.stateChangeCallbacks[t].filter(([t]) => e.indexOf(t) === -1)
        }
        channel(e, t = {}) {
            let n = new He(e, t, this);
            return this.channels.push(n), n
        }
        push(e) {
            if (this.hasLogger()) {
                let {
                    topic: t,
                    event: n,
                    payload: r,
                    ref: i,
                    join_ref: a
                } = e;
                this.log(`push`, `${t} ${n} (${a}, ${i})`, r)
            }
            this.isConnected() ? this.encode(e, e => this.conn.send(e)) : this.sendBuffer.push(() => this.encode(e, e => this.conn.send(e)))
        }
        makeRef() {
            let e = this.ref + 1;
            return this.ref = e === this.ref ? 0 : e, this.ref.toString()
        }
        sendHeartbeat() {
            if (!this.isConnected()) {
                try {
                    this.heartbeatCallback(`disconnected`)
                } catch (e) {
                    this.log(`error`, `error in heartbeat callback`, e)
                }
                return
            }
            if (this.pendingHeartbeatRef) {
                this.heartbeatTimeout();
                return
            }
            this.pendingHeartbeatRef = this.makeRef(), this.heartbeatSentAt = Date.now(), this.push({
                topic: `phoenix`,
                event: `heartbeat`,
                payload: {},
                ref: this.pendingHeartbeatRef
            });
            try {
                this.heartbeatCallback(`sent`)
            } catch (e) {
                this.log(`error`, `error in heartbeat callback`, e)
            }
            this.heartbeatTimeoutTimer = setTimeout(() => this.heartbeatTimeout(), this.heartbeatIntervalMs)
        }
        flushSendBuffer() {
            this.isConnected() && this.sendBuffer.length > 0 && (this.sendBuffer.forEach(e => e()), this.sendBuffer = [])
        }
        onConnMessage(e) {
            this.decode(e.data, e => {
                let {
                    topic: t,
                    event: n,
                    payload: r,
                    ref: i,
                    join_ref: a
                } = e;
                if (i && i === this.pendingHeartbeatRef) {
                    let e = this.heartbeatSentAt ? Date.now() - this.heartbeatSentAt : void 0;
                    this.clearHeartbeats();
                    try {
                        this.heartbeatCallback(r.status === `ok` ? `ok` : `error`, e)
                    } catch (e) {
                        this.log(`error`, `error in heartbeat callback`, e)
                    }
                    this.pendingHeartbeatRef = null, this.heartbeatSentAt = null, this.autoSendHeartbeat && (this.heartbeatTimer = setTimeout(() => this.sendHeartbeat(), this.heartbeatIntervalMs))
                }
                this.hasLogger() && this.log(`receive`, `${r.status||``} ${t} ${n} ${i&&`(`+i+`)`||``}`.trim(), r);
                for (let e = 0; e < this.channels.length; e++) {
                    let o = this.channels[e];
                    o.isMember(t, n, r, a) && o.trigger(n, r, i, a)
                }
                this.triggerStateCallbacks(`message`, e)
            })
        }
        triggerStateCallbacks(e, ...t) {
            try {
                this.stateChangeCallbacks[e].forEach(([n, r]) => {
                    try {
                        r(...t)
                    } catch (t) {
                        this.log(`error`, `error in ${e} callback`, t)
                    }
                })
            } catch (t) {
                this.log(`error`, `error triggering ${e} callbacks`, t)
            }
        }
        leaveOpenTopic(e) {
            let t = this.channels.find(t => t.topic === e && (t.isJoined() || t.isJoining()));
            t && (this.hasLogger() && this.log(`transport`, `leaving duplicate topic "${e}"`), t.leave())
        }
    },
    Je = class e {
        constructor(t, n) {
            let r = Ze(n);
            this.presence = new Ge(t.getChannel(), r), this.presence.onJoin((n, r, i) => {
                let a = e.onJoinPayload(n, r, i);
                t.getChannel().trigger(`presence`, a)
            }), this.presence.onLeave((n, r, i) => {
                let a = e.onLeavePayload(n, r, i);
                t.getChannel().trigger(`presence`, a)
            }), this.presence.onSync(() => {
                t.getChannel().trigger(`presence`, {
                    event: `sync`
                })
            })
        }
        get state() {
            return e.transformState(this.presence.state)
        }
        static transformState(e) {
            return e = Xe(e), Object.getOwnPropertyNames(e).reduce((t, n) => {
                let r = e[n];
                return t[n] = Ye(r), t
            }, {})
        }
        static onJoinPayload(e, t, n) {
            return {
                event: `join`,
                key: e,
                currentPresences: Qe(t),
                newPresences: Ye(n)
            }
        }
        static onLeavePayload(e, t, n) {
            return {
                event: `leave`,
                key: e,
                currentPresences: Qe(t),
                leftPresences: Ye(n)
            }
        }
    };

function Ye(e) {
    return e.metas.map(e => {
        let t = Object.getOwnPropertyDescriptors(e),
            n = Object.defineProperties({}, t);
        return n.presence_ref = n.phx_ref, delete n.phx_ref, delete n.phx_ref_prev, n
    })
}

function Xe(e) {
    return JSON.parse(JSON.stringify(e))
}

function Ze(e) {
    return e ?.events && {
        events: e.events
    }
}

function Qe(e) {
    return e ?.metas ? Ye(e) : []
}
var $e;
(function(e) {
    e.SYNC = `sync`, e.JOIN = `join`, e.LEAVE = `leave`
})($e ||= {});
var et = class {
    get state() {
        return this.presenceAdapter.state
    }
    constructor(e, t) {
        this.channel = e, this.presenceAdapter = new Je(this.channel.channelAdapter, t)
    }
};

function tt(e) {
    if (e instanceof Error) return e;
    if (typeof e == `string`) return Error(e);
    if (e && typeof e == `object`) {
        let t = e;
        if (typeof t.code == `number`) {
            let n = typeof t.reason == `string` && t.reason ? ` (${t.reason})` : ``;
            return Error(`socket closed: ${t.code}${n}`, {
                cause: e
            })
        }
        return Error(`channel error: transport failure`, {
            cause: e
        })
    }
    return Error(`channel error: connection lost`)
}
var nt = class {
    constructor(e, t, n) {
        let r = rt(n);
        this.channel = e.getSocket().channel(t, r), this.socket = e
    }
    get state() {
        return this.channel.state
    }
    set state(e) {
        this.channel.state = e
    }
    get joinedOnce() {
        return this.channel.joinedOnce
    }
    get joinPush() {
        return this.channel.joinPush
    }
    get rejoinTimer() {
        return this.channel.rejoinTimer
    }
    on(e, t) {
        return this.channel.on(e, t)
    }
    off(e, t) {
        this.channel.off(e, t)
    }
    subscribe(e) {
        return this.channel.join(e)
    }
    unsubscribe(e) {
        return this.channel.leave(e)
    }
    teardown() {
        this.channel.teardown()
    }
    onClose(e) {
        this.channel.onClose(e)
    }
    onError(e) {
        return this.channel.onError(e)
    }
    push(e, t, n) {
        let r;
        try {
            r = this.channel.push(e, t, n)
        } catch {
            throw Error(`tried to push '${e}' to '${this.channel.topic}' before joining. Use channel.subscribe() before pushing events`)
        }
        if (this.channel.pushBuffer.length > 100) {
            let e = this.channel.pushBuffer.shift();
            e.cancelTimeout(), this.socket.log(`channel`, `discarded push due to buffer overflow: ${e.event}`, e.payload())
        }
        return r
    }
    updateJoinPayload(e) {
        let t = this.channel.joinPush.payload();
        this.channel.joinPush.payload = () => Object.assign(Object.assign({}, t), e)
    }
    canPush() {
        return this.socket.isConnected() && this.state === x.joined
    }
    isJoined() {
        return this.state === x.joined
    }
    isJoining() {
        return this.state === x.joining
    }
    isClosed() {
        return this.state === x.closed
    }
    isLeaving() {
        return this.state === x.leaving
    }
    updateFilterBindings(e) {
        this.channel.filterBindings = e
    }
    updatePayloadTransform(e) {
        this.channel.onMessage = e
    }
    getChannel() {
        return this.channel
    }
};

function rt(e) {
    return {
        config: Object.assign({
            broadcast: {
                ack: !1,
                self: !1
            },
            presence: {
                key: ``,
                enabled: !1
            },
            private: !1
        }, e.config)
    }
}
var it = /[,()"\\]/,
    at = e => it.test(e) || e !== e.trim(),
    ot = e => `"${e.replace(/\\/g,`\\\\`).replace(/"/g,`\\"`)}"`,
    st = e => {
        let t = e === null ? `null` : String(e);
        return at(t) ? ot(t) : t
    },
    ct = e => e === null ? `null` : String(e),
    lt = (e, t) => {
        if (e === `in`) {
            let e = Array.isArray(t) ? t : [t];
            if (e.length === 0) throw Error("Realtime `in` filter requires at least one value.");
            return `in.(${Array.from(new Set(e)).map(e=>st(e)).join(`,`)})`
        }
        return e === `is` ? `is.${ct(t)}` : `${e}.${st(t)}`
    },
    ut = class {
        constructor() {
            this.filters = []
        }
        add(e, t, n, r = !1) {
            let i = r ? `not.` : ``;
            return this.filters.push(`${e}=${i}${lt(t,n)}`), this
        }
        eq(e, t) {
            return this.add(e, `eq`, t)
        }
        neq(e, t) {
            return this.add(e, `neq`, t)
        }
        gt(e, t) {
            return this.add(e, `gt`, t)
        }
        gte(e, t) {
            return this.add(e, `gte`, t)
        }
        lt(e, t) {
            return this.add(e, `lt`, t)
        }
        lte(e, t) {
            return this.add(e, `lte`, t)
        } in (e, t) {
            return this.add(e, `in`, t)
        }
        like(e, t) {
            return this.add(e, `like`, t)
        }
        ilike(e, t) {
            return this.add(e, `ilike`, t)
        }
        match(e, t) {
            return this.add(e, `match`, t)
        }
        imatch(e, t) {
            return this.add(e, `imatch`, t)
        }
        is(e, t) {
            return this.add(e, `is`, t)
        }
        isDistinct(e, t) {
            return this.add(e, `isdistinct`, t)
        }
        not(e, t, n) {
            return this.add(e, t, n, !0)
        }
        build() {
            return this.filters.join(`,`)
        }
        toString() {
            return this.build()
        }
    },
    dt;
(function(e) {
    e.ALL = `*`, e.INSERT = `INSERT`, e.UPDATE = `UPDATE`, e.DELETE = `DELETE`
})(dt ||= {});
var O;
(function(e) {
    e.BROADCAST = `broadcast`, e.PRESENCE = `presence`, e.POSTGRES_CHANGES = `postgres_changes`, e.SYSTEM = `system`
})(O ||= {});
var k;
(function(e) {
    e.SUBSCRIBED = `SUBSCRIBED`, e.TIMED_OUT = `TIMED_OUT`, e.CLOSED = `CLOSED`, e.CHANNEL_ERROR = `CHANNEL_ERROR`
})(k ||= {});
var ft = class e {
        get state() {
            return this.channelAdapter.state
        }
        set state(e) {
            this.channelAdapter.state = e
        }
        get joinedOnce() {
            return this.channelAdapter.joinedOnce
        }
        get timeout() {
            return this.socket.timeout
        }
        get joinPush() {
            return this.channelAdapter.joinPush
        }
        get rejoinTimer() {
            return this.channelAdapter.rejoinTimer
        }
        constructor(e, t = {
            config: {}
        }, n) {
            if (this.topic = e, this.params = t, this.socket = n, this.bindings = {}, this.subTopic = e.replace(/^realtime:/i, ``), this.params.config = Object.assign({
                    broadcast: {
                        ack: !1,
                        self: !1
                    },
                    presence: {
                        key: ``,
                        enabled: !1
                    },
                    private: !1
                }, t.config), this.channelAdapter = new nt(this.socket.socketAdapter, e, this.params), this.presence = new et(this), this._onClose(() => {
                    this.socket._remove(this)
                }), this._updateFilterTransform(), this.broadcastEndpointURL = ke(this.socket.socketAdapter.endPointURL()), this.private = this.params.config.private || !1, !this.private && this.params.config ?.broadcast ?.replay) throw Error(`tried to use replay on public channel '${this.topic}'. It must be a private channel.`)
        }
        subscribe(e, t = this.timeout) {
            if (this.socket.isConnected() || this.socket.connect(), this.channelAdapter.isClosed()) {
                let {
                    config: {
                        broadcast: n,
                        presence: r,
                        private: i
                    }
                } = this.params, a = this.bindings.postgres_changes ?.map(e => e.filter) ?? [], o = !!this.bindings[O.PRESENCE] && this.bindings[O.PRESENCE].length > 0 || this.params.config.presence ?.enabled === !0, s = {}, c = {
                    broadcast: n,
                    presence: Object.assign(Object.assign({}, r), {
                        enabled: o
                    }),
                    postgres_changes: a,
                    private: i
                };
                this.socket.accessTokenValue && (s.access_token = this.socket.accessTokenValue), this._onError(t => {
                    e ?.(k.CHANNEL_ERROR, tt(t))
                }), this._onClose(() => e ?.(k.CLOSED)), this.updateJoinPayload(Object.assign({
                    config: c
                }, s)), this._updateFilterMessage(), this.channelAdapter.subscribe(t).receive(`ok`, async ({
                    postgres_changes: t
                }) => {
                    if (this.socket._isManualToken() || this.socket.setAuth(), t === void 0) {
                        e ?.(k.SUBSCRIBED);
                        return
                    }
                    this._updatePostgresBindings(t, e)
                }).receive(`error`, t => {
                    this.state = x.errored;
                    let n = Object.values(t).join(`, `) || `error`;
                    e ?.(k.CHANNEL_ERROR, Error(n, {
                        cause: t
                    }))
                }).receive(`timeout`, () => {
                    e ?.(k.TIMED_OUT)
                })
            }
            return this
        }
        _updatePostgresBindings(t, n) {
            let r = this.bindings.postgres_changes,
                i = r ?.length ?? 0,
                a = [];
            for (let o = 0; o < i; o++) {
                let i = r[o],
                    {
                        filter: {
                            event: s,
                            schema: c,
                            table: l,
                            filter: u
                        }
                    } = i,
                    d = t && t[o];
                if (d && d.event === s && e.isFilterValueEqual(d.schema, c) && e.isFilterValueEqual(d.table, l) && e.isFilterValueEqual(d.filter, u)) a.push(Object.assign(Object.assign({}, i), {
                    id: d.id
                }));
                else {
                    this.unsubscribe(), this.state = x.errored, n ?.(k.CHANNEL_ERROR, Error(`mismatch between server and client bindings for postgres changes`));
                    return
                }
            }
            this.bindings.postgres_changes = a, this.state != x.errored && n && n(k.SUBSCRIBED)
        }
        presenceState() {
            return this.presence.state
        }
        async track(e, t = {}) {
            return await this.send({
                type: `presence`,
                event: `track`,
                payload: e
            }, t)
        }
        async untrack(e = {}) {
            return await this.send({
                type: `presence`,
                event: `untrack`
            }, e)
        }
        on(e, t, n) {
            let r = this.channelAdapter.isJoined() || this.channelAdapter.isJoining(),
                i = e === O.PRESENCE || e === O.POSTGRES_CHANGES;
            if (r && i) throw this.socket.log(`channel`, `cannot add \`${e}\` callbacks for ${this.topic} after \`subscribe()\`.`), Error(`cannot add \`${e}\` callbacks for ${this.topic} after \`subscribe()\`.`);
            return this._on(e, t, n)
        }
        async httpSend(e, t, n = {}) {
            if (t == null) return Promise.reject(Error(`Payload is required for httpSend()`));
            let r = t instanceof ArrayBuffer || ArrayBuffer.isView(t),
                i = {
                    apikey: this.socket.apiKey ? this.socket.apiKey : ``,
                    "Content-Type": r ? `application/octet-stream` : `application/json`
                };
            this.socket.accessTokenValue && (i.Authorization = `Bearer ${this.socket.accessTokenValue}`);
            let a = new URL(this.broadcastEndpointURL);
            a.pathname += `/${encodeURIComponent(this.subTopic)}/events/${encodeURIComponent(e)}`, this.private && a.searchParams.set(`private`, `true`);
            let o = {
                    method: `POST`,
                    headers: i,
                    body: r ? t : JSON.stringify(t)
                },
                s = await this._fetchWithTimeout(a.toString(), o, n.timeout ?? this.timeout);
            if (s.status === 202) return {
                success: !0
            };
            if (s.status === 404) return Promise.reject(Error(`httpSend() requires Realtime server v2.97.0 or newer; the endpoint returned 404. Update your Supabase CLI to a recent version, or upgrade the Realtime server in your self-hosted setup. See https://github.com/supabase/supabase-js/blob/master/packages/core/realtime-js/migrations/httpsend-server-version.md`));
            let c = s.statusText;
            try {
                let e = await s.json();
                c = e.error || e.message || c
            } catch {}
            return Promise.reject(Error(c))
        }
        async send(e, t = {}) {
            if (!this.channelAdapter.canPush() && e.type === `broadcast`) {
                console.warn(`Realtime send() is automatically falling back to REST API. This behavior will be deprecated in the future. Please use httpSend() explicitly for REST delivery.`);
                let {
                    event: n,
                    payload: r
                } = e, i = {
                    apikey: this.socket.apiKey ? this.socket.apiKey : ``,
                    "Content-Type": `application/json`
                };
                this.socket.accessTokenValue && (i.Authorization = `Bearer ${this.socket.accessTokenValue}`);
                let a = {
                    method: `POST`,
                    headers: i,
                    body: JSON.stringify({
                        messages: [{
                            topic: this.subTopic,
                            event: n,
                            payload: r,
                            private: this.private
                        }]
                    })
                };
                try {
                    let e = await this._fetchWithTimeout(this.broadcastEndpointURL, a, t.timeout ?? this.timeout);
                    return await e.body ?.cancel(), e.ok ? `ok` : `error`
                } catch (e) {
                    return e instanceof Error && e.name === `AbortError` ? `timed out` : `error`
                }
            }
            return new Promise(n => {
                let r = this.channelAdapter.push(e.type, e, t.timeout || this.timeout);
                e.type === `broadcast` && !this.params ?.config ?.broadcast ?.ack && n(`ok`), r.receive(`ok`, () => n(`ok`)), r.receive(`error`, () => n(`error`)), r.receive(`timeout`, () => n(`timed out`))
            })
        }
        updateJoinPayload(e) {
            this.channelAdapter.updateJoinPayload(e)
        }
        async unsubscribe(e = this.timeout) {
            return new Promise(t => {
                this.channelAdapter.unsubscribe(e).receive(`ok`, () => t(`ok`)).receive(`timeout`, () => t(`timed out`)).receive(`error`, () => t(`error`))
            })
        }
        teardown() {
            this.channelAdapter.teardown()
        }
        async _fetchWithTimeout(e, t, n) {
            let r = new AbortController,
                i = setTimeout(() => r.abort(), n),
                a = await this.socket.fetch(e, Object.assign(Object.assign({}, t), {
                    signal: r.signal
                }));
            return clearTimeout(i), a
        }
        _on(t, n, r) {
            let i = t.toLocaleLowerCase(),
                a = n ?.filter;
            if ((a instanceof ut || typeof a == `object` && a && typeof a.build == `function`) && (n = Object.assign(Object.assign({}, n), {
                    filter: a.build()
                })), i === O.POSTGRES_CHANGES && this.bindings[i] ?.find(t => e.isSamePostgresFilter(t.filter, n))) return this.socket.log(`error`, `duplicate \`postgres_changes\` binding for ${this.topic} ignored`, n), this;
            let o = this.channelAdapter.on(t, r),
                s = {
                    type: i,
                    filter: n,
                    callback: r,
                    ref: o
                };
            return this.bindings[i] ? this.bindings[i].push(s) : this.bindings[i] = [s], this._updateFilterMessage(), this
        }
        _onClose(e) {
            this.channelAdapter.onClose(e)
        }
        _onError(e) {
            this.channelAdapter.onError(e)
        }
        _updateFilterMessage() {
            this.channelAdapter.updateFilterBindings((e, t, n) => {
                let r = e.event.toLocaleLowerCase();
                if (this._notThisChannelEvent(r, n)) return !1;
                let i = this.bindings[r] ?.find(t => t.ref === e.ref);
                if (!i) return !0;
                if ([`broadcast`, `presence`, `postgres_changes`].includes(r)) {
                    if (`id` in i) {
                        let e = i.id,
                            n = i.filter ?.event;
                        return e && t.ids ?.includes(e) && (n === `*` || n ?.toLocaleLowerCase() === t.data ?.type.toLocaleLowerCase())
                    } {
                        let e = (i ?.filter ?.event) ?.toLocaleLowerCase();
                        return e === `*` || e === (t ?.event) ?.toLocaleLowerCase()
                    }
                }
                return i.type.toLocaleLowerCase() === r
            })
        }
        _notThisChannelEvent(e, t) {
            let {
                close: n,
                error: r,
                leave: i,
                join: a
            } = _e;
            return t && [n, r, i, a].includes(e) && t !== this.joinPush.ref
        }
        _updateFilterTransform() {
            this.channelAdapter.updatePayloadTransform((e, t, n) => {
                if (typeof t == `object` && `ids` in t) {
                    let e = t.data,
                        {
                            schema: n,
                            table: r,
                            commit_timestamp: i,
                            type: a,
                            errors: o
                        } = e;
                    return Object.assign(Object.assign({}, {
                        schema: n,
                        table: r,
                        commit_timestamp: i,
                        eventType: a,
                        new: {},
                        old: {},
                        errors: o
                    }), this._getPayloadRecords(e))
                }
                return t
            })
        }
        copyBindings(e) {
            if (this.joinedOnce) throw Error(`cannot copy bindings into joined channel`);
            for (let t in e.bindings)
                for (let n of e.bindings[t]) this._on(n.type, n.filter, n.callback)
        }
        static isFilterValueEqual(e, t) {
            return (e ?? void 0) === (t ?? void 0)
        }
        static isSamePostgresFilter(t, n) {
            let r = (t ?.select) ?.join() ?? void 0,
                i = (n ?.select) ?.join() ?? void 0;
            return t ?.event === n ?.event && e.isFilterValueEqual(t ?.schema, n ?.schema) && e.isFilterValueEqual(t ?.table, n ?.table) && e.isFilterValueEqual(t ?.filter, n ?.filter) && r === i
        }
        _getPayloadRecords(e) {
            let t = {
                new: {},
                old: {}
            };
            return (e.type === `INSERT` || e.type === `UPDATE`) && (t.new = be(e.columns, e.record)), (e.type === `UPDATE` || e.type === `DELETE`) && (t.old = be(e.columns, e.old_record)), t
        }
    },
    pt = class {
        constructor(e, t) {
            this.socket = new qe(e, t)
        }
        get timeout() {
            return this.socket.timeout
        }
        get endPoint() {
            return this.socket.endPoint
        }
        get transport() {
            return this.socket.transport
        }
        get heartbeatIntervalMs() {
            return this.socket.heartbeatIntervalMs
        }
        get heartbeatCallback() {
            return this.socket.heartbeatCallback
        }
        set heartbeatCallback(e) {
            this.socket.heartbeatCallback = e
        }
        get heartbeatTimer() {
            return this.socket.heartbeatTimer
        }
        get pendingHeartbeatRef() {
            return this.socket.pendingHeartbeatRef
        }
        get reconnectTimer() {
            return this.socket.reconnectTimer
        }
        get vsn() {
            return this.socket.vsn
        }
        get encode() {
            return this.socket.encode
        }
        get decode() {
            return this.socket.decode
        }
        get reconnectAfterMs() {
            return this.socket.reconnectAfterMs
        }
        get sendBuffer() {
            return this.socket.sendBuffer
        }
        get stateChangeCallbacks() {
            return this.socket.stateChangeCallbacks
        }
        connect() {
            this.socket.connect()
        }
        disconnect(e, t, n, r = 1e4) {
            return new Promise(i => {
                setTimeout(() => i(`timeout`), r), this.socket.disconnect(() => {
                    e(), i(`ok`)
                }, t, n)
            })
        }
        push(e) {
            this.socket.push(e)
        }
        log(e, t, n) {
            this.socket.log(e, t, n)
        }
        makeRef() {
            return this.socket.makeRef()
        }
        onOpen(e) {
            this.socket.onOpen(e)
        }
        onClose(e) {
            this.socket.onClose(e)
        }
        onError(e) {
            this.socket.onError(e)
        }
        onMessage(e) {
            this.socket.onMessage(e)
        }
        isConnected() {
            return this.socket.isConnected()
        }
        isConnecting() {
            return this.socket.connectionState() == ve.connecting
        }
        isDisconnecting() {
            return this.socket.connectionState() == ve.closing
        }
        connectionState() {
            return this.socket.connectionState()
        }
        endPointURL() {
            return this.socket.endPointURL()
        }
        sendHeartbeat() {
            this.socket.sendHeartbeat()
        }
        getSocket() {
            return this.socket
        }
    },
    mt = {
        HEARTBEAT_INTERVAL: 25e3,
        RECONNECT_DELAY: 10,
        HEARTBEAT_TIMEOUT_FALLBACK: 100
    },
    ht = [1e3, 2e3, 5e3, 1e4],
    gt = 1e4;

function _t() {
    let e = new Map;
    return {
        get length() {
            return e.size
        },
        clear() {
            e.clear()
        },
        getItem(t) {
            return e.has(t) ? e.get(t) : null
        },
        key(t) {
            return Array.from(e.keys())[t] ?? null
        },
        removeItem(t) {
            e.delete(t)
        },
        setItem(t, n) {
            e.set(t, String(n))
        }
    }
}

function vt() {
    try {
        if (typeof globalThis < `u` && globalThis.sessionStorage) return globalThis.sessionStorage
    } catch {}
    return _t()
}
var yt = `
  addEventListener("message", (e) => {
    if (e.data.event === "start") {
      setInterval(() => postMessage({ event: "keepAlive" }), e.data.interval);
    }
  });`,
    bt = class {
        get endPoint() {
            return this.socketAdapter.endPoint
        }
        get timeout() {
            return this.socketAdapter.timeout
        }
        get transport() {
            return this.socketAdapter.transport
        }
        get heartbeatCallback() {
            return this.socketAdapter.heartbeatCallback
        }
        get heartbeatIntervalMs() {
            return this.socketAdapter.heartbeatIntervalMs
        }
        get heartbeatTimer() {
            return this.worker ? this._workerHeartbeatTimer : this.socketAdapter.heartbeatTimer
        }
        get pendingHeartbeatRef() {
            return this.worker ? this._pendingWorkerHeartbeatRef : this.socketAdapter.pendingHeartbeatRef
        }
        get reconnectTimer() {
            return this.socketAdapter.reconnectTimer
        }
        get vsn() {
            return this.socketAdapter.vsn
        }
        get encode() {
            return this.socketAdapter.encode
        }
        get decode() {
            return this.socketAdapter.decode
        }
        get reconnectAfterMs() {
            return this.socketAdapter.reconnectAfterMs
        }
        get sendBuffer() {
            return this.socketAdapter.sendBuffer
        }
        get stateChangeCallbacks() {
            return this.socketAdapter.stateChangeCallbacks
        }
        constructor(e, t) {
            if (this.channels = [], this.accessTokenValue = null, this.accessToken = null, this.apiKey = null, this.httpEndpoint = ``, this.headers = {}, this.params = {}, this.ref = 0, this.serializer = new ye, this._manuallySetToken = !1, this._authPromise = null, this._authGeneration = 0, this._workerHeartbeatTimer = void 0, this._pendingWorkerHeartbeatRef = null, this._pendingDisconnectTimer = null, this._disconnectOnEmptyChannelsAfterMs = 0, this._resolveFetch = e => e ? (...t) => e(...t) : (...e) => fetch(...e), !t ?.params ?.apikey) throw Error(`API key is required to connect to Realtime`);
            this.apiKey = t.params.apikey;
            let n = this._initializeOptions(t);
            this.socketAdapter = new pt(e, n), this.httpEndpoint = ke(e), this.fetch = this._resolveFetch(t ?.fetch)
        }
        connect() {
            if (!(this.isConnecting() || this.isDisconnecting() || this.isConnected())) {
                this.accessToken && !this._authPromise && this._setAuthSafely(`connect`), this._setupConnectionHandlers();
                try {
                    this.socketAdapter.connect()
                } catch (e) {
                    let t = e.message;
                    throw Error(`WebSocket not available: ${t}`)
                }
                this._handleNodeJsRaceCondition()
            }
        }
        endpointURL() {
            return this.socketAdapter.endPointURL()
        }
        async disconnect(e, t) {
            return this._cancelPendingDisconnect(), this.isDisconnecting() ? `ok` : await this.socketAdapter.disconnect(() => {
                clearInterval(this._workerHeartbeatTimer), this._terminateWorker()
            }, e, t)
        }
        getChannels() {
            return this.channels
        }
        async removeChannel(e) {
            let t = await e.unsubscribe();
            return t === `ok` && e.teardown(), t
        }
        async removeAllChannels() {
            let e = this.channels.map(async e => {
                    let t = await e.unsubscribe();
                    return e.teardown(), t
                }),
                t = await Promise.all(e);
            return await this.disconnect(), t
        }
        log(e, t, n) {
            this.socketAdapter.log(e, t, n)
        }
        connectionState() {
            return this.socketAdapter.connectionState() || ve.closed
        }
        isConnected() {
            return this.socketAdapter.isConnected()
        }
        isConnecting() {
            return this.socketAdapter.isConnecting()
        }
        isDisconnecting() {
            return this.socketAdapter.isDisconnecting()
        }
        channel(e, t = {
            config: {}
        }) {
            let n = `realtime:${e}`,
                r = this.getChannels().find(e => e.topic === n);
            if (r) return r; {
                let n = new ft(`realtime:${e}`, t, this);
                return this._cancelPendingDisconnect(), this.channels.push(n), n
            }
        }
        push(e) {
            this.socketAdapter.push(e)
        }
        async setAuth(e = null) {
            let t = ++this._authGeneration,
                n = this._performAuth(e, t);
            t === this._authGeneration && (this._authPromise = n);
            try {
                await n
            } finally {
                this._authPromise === n && (this._authPromise = null)
            }
        }
        _isManualToken() {
            return this._manuallySetToken
        }
        async sendHeartbeat() {
            this.socketAdapter.sendHeartbeat()
        }
        onHeartbeat(e) {
            this.socketAdapter.heartbeatCallback = this._wrapHeartbeatCallback(e)
        }
        _makeRef() {
            return this.socketAdapter.makeRef()
        }
        _remove(e) {
            this.channels = this.channels.filter(t => t.topic !== e.topic), this.channels.length === 0 && (this.log(`transport`, `no channels remaining, scheduling disconnect`), this._schedulePendingDisconnect())
        }
        _schedulePendingDisconnect() {
            if (this._cancelPendingDisconnect(), this._disconnectOnEmptyChannelsAfterMs === 0) {
                this.log(`transport`, `disconnecting immediately - no channels`), this.disconnect();
                return
            }
            this._pendingDisconnectTimer = setTimeout(() => {
                this._pendingDisconnectTimer = null, this.channels.length === 0 && (this.log(`transport`, `deferred disconnect fired - no channels, disconnecting`), this.disconnect())
            }, this._disconnectOnEmptyChannelsAfterMs), this.log(`transport`, `deferred disconnect scheduled in ${this._disconnectOnEmptyChannelsAfterMs}ms`)
        }
        _cancelPendingDisconnect() {
            this._pendingDisconnectTimer !== null && (this.log(`transport`, `pending disconnect cancelled - channel activity detected`), clearTimeout(this._pendingDisconnectTimer), this._pendingDisconnectTimer = null)
        }
        async _performAuth(e, t) {
            let n, r = !1;
            if (e) n = e, r = !0;
            else if (this.accessToken) try {
                n = await this.accessToken()
            } catch (e) {
                this.log(`error`, `Error fetching access token from callback`, e), n = this.accessTokenValue
            } else n = this.accessTokenValue;
            t === this._authGeneration && (this.accessToken ? this._manuallySetToken = !1 : r && (this._manuallySetToken = !0), this.accessTokenValue != n && (this.accessTokenValue = n, this.channels.forEach(e => {
                let t = {
                    access_token: n,
                    version: fe
                };
                e.updateJoinPayload(t), e.joinedOnce && e.channelAdapter.isJoined() && e.channelAdapter.push(_e.access_token, {
                    access_token: n
                })
            })))
        }
        async _waitForAuthIfNeeded() {
            this._authPromise && await this._authPromise
        }
        _setAuthSafely(e = `general`) {
            this._isManualToken() || this.setAuth().catch(t => {
                this.log(`error`, `Error setting auth in ${e}`, t)
            })
        }
        _setupConnectionHandlers() {
            this.socketAdapter.onOpen(() => {
                (this._authPromise || (this.accessToken && !this.accessTokenValue ? this.setAuth() : Promise.resolve())).catch(e => {
                    this.log(`error`, `error waiting for auth on connect`, e)
                }), this.worker && !this.workerRef && this._startWorkerHeartbeat()
            }), this.socketAdapter.onClose(() => {
                this.worker && this.workerRef && this._terminateWorker()
            }), this.socketAdapter.onMessage(e => {
                e.ref && e.ref === this._pendingWorkerHeartbeatRef && (this._pendingWorkerHeartbeatRef = null)
            })
        }
        _handleNodeJsRaceCondition() {
            this.socketAdapter.isConnected() && this.socketAdapter.getSocket().onConnOpen()
        }
        _wrapHeartbeatCallback(e) {
            return (t, n) => {
                t !== `disconnected` && (t == `sent` && this._setAuthSafely(), e && e(t, n))
            }
        }
        _startWorkerHeartbeat() {
            this.workerUrl ? this.log(`worker`, `starting worker for from ${this.workerUrl}`) : this.log(`worker`, `starting default worker`);
            let e = this._workerObjectUrl(this.workerUrl);
            this.workerRef = new Worker(e), this.workerRef.onerror = e => {
                this.log(`worker`, `worker error`, e.message), this._terminateWorker(), this.disconnect()
            }, this.workerRef.onmessage = e => {
                e.data.event === `keepAlive` && this.sendHeartbeat()
            }, this.workerRef.postMessage({
                event: `start`,
                interval: this.heartbeatIntervalMs
            })
        }
        _terminateWorker() {
            this.workerRef &&= (this.log(`worker`, `terminating worker`), this.workerRef.terminate(), void 0)
        }
        _workerObjectUrl(e) {
            let t;
            if (e) t = e;
            else {
                let e = new Blob([yt], {
                    type: `application/javascript`
                });
                t = URL.createObjectURL(e)
            }
            return t
        }
        _initializeOptions(e) {
            this.worker = e ?.worker ?? !1, this.accessToken = e ?.accessToken ?? null;
            let t = {};
            t.timeout = e ?.timeout ?? ge, t.heartbeatIntervalMs = e ?.heartbeatIntervalMs ?? mt.HEARTBEAT_INTERVAL, this._disconnectOnEmptyChannelsAfterMs = e ?.disconnectOnEmptyChannelsAfterMs ?? 2 * (e ?.heartbeatIntervalMs ?? mt.HEARTBEAT_INTERVAL), t.transport = e ?.transport ?? de.getWebSocketConstructor(), t.params = e ?.params, t.logger = e ?.logger, t.heartbeatCallback = this._wrapHeartbeatCallback(e ?.heartbeatCallback), t.sessionStorage = e ?.sessionStorage ?? vt(), t.reconnectAfterMs = e ?.reconnectAfterMs ?? (e => ht[e - 1] || gt);
            let n, r, i = e ?.vsn ?? he;
            switch (i) {
                case pe:
                    n = (e, t) => t(JSON.stringify(e)), r = (e, t) => t(JSON.parse(e));
                    break;
                case me:
                    n = this.serializer.encode.bind(this.serializer), r = this.serializer.decode.bind(this.serializer);
                    break;
                default:
                    throw Error(`Unsupported serializer version: ${t.vsn}`)
            }
            if (t.vsn = i, t.encode = e ?.encode ?? n, t.decode = e ?.decode ?? r, t.beforeReconnect = this._reconnectAuth.bind(this), (e ?.logLevel || e ?.log_level) && (this.logLevel = e.logLevel || e.log_level, t.params = Object.assign(Object.assign({}, t.params), {
                    log_level: this.logLevel
                })), this.worker) {
                if (typeof window < `u` && !window.Worker) throw Error(`Web Worker is not supported`);
                this.workerUrl = e ?.workerUrl, t.autoSendHeartbeat = !this.worker
            }
            return t
        }
        async _reconnectAuth() {
            await this._waitForAuthIfNeeded(), this.isConnected() || this.connect()
        }
    },
    xt = class extends Error {
        constructor(e, t) {
            super(e), this.name = `IcebergError`, this.status = t.status, this.icebergType = t.icebergType, this.icebergCode = t.icebergCode, this.details = t.details, this.isCommitStateUnknown = t.icebergType === `CommitStateUnknownException` || [500, 502, 504].includes(t.status) && t.icebergType ?.includes(`CommitState`) === !0
        }
        isNotFound() {
            return this.status === 404
        }
        isConflict() {
            return this.status === 409
        }
        isAuthenticationTimeout() {
            return this.status === 419
        }
    };

function St(e, t, n) {
    let r = new URL(t, e);
    if (n)
        for (let [e, t] of Object.entries(n)) t !== void 0 && r.searchParams.set(e, t);
    return r.toString()
}
async function Ct(e) {
    return !e || e.type === `none` ? {} : e.type === `bearer` ? {
        Authorization: `Bearer ${e.token}`
    } : e.type === `header` ? {
        [e.name]: e.value
    } : e.type === `custom` ? await e.getHeaders() : {}
}

function wt(e) {
    let t = e.fetchImpl ?? globalThis.fetch;
    return {
        async request({
            method: n,
            path: r,
            query: i,
            body: a,
            headers: o
        }) {
            let s = St(e.baseUrl, r, i),
                c = await Ct(e.auth),
                l = await t(s, {
                    method: n,
                    headers: { ...a ? {
                            "Content-Type": `application/json`
                        } : {},
                        ...c,
                        ...o
                    },
                    body: a ? JSON.stringify(a) : void 0
                }),
                u = await l.text(),
                d = (l.headers.get(`content-type`) || ``).includes(`application/json`),
                f = d && u ? JSON.parse(u) : u;
            if (!l.ok) {
                let e = d ? f : void 0,
                    t = e ?.error;
                throw new xt(t ?.message ?? `Request failed with status ${l.status}`, {
                    status: l.status,
                    icebergType: t ?.type,
                    icebergCode: t ?.code,
                    details: e
                })
            }
            return {
                status: l.status,
                headers: l.headers,
                data: f
            }
        }
    }
}

function Tt(e) {
    return e.join(``)
}
var Et = class {
    constructor(e, t = ``) {
        this.client = e, this.prefix = t
    }
    async listNamespaces(e) {
        let t = e ? {
            parent: Tt(e.namespace)
        } : void 0;
        return (await this.client.request({
            method: `GET`,
            path: `${this.prefix}/namespaces`,
            query: t
        })).data.namespaces.map(e => ({
            namespace: e
        }))
    }
    async createNamespace(e, t) {
        let n = {
            namespace: e.namespace,
            properties: t ?.properties
        };
        return (await this.client.request({
            method: `POST`,
            path: `${this.prefix}/namespaces`,
            body: n
        })).data
    }
    async dropNamespace(e) {
        await this.client.request({
            method: `DELETE`,
            path: `${this.prefix}/namespaces/${Tt(e.namespace)}`
        })
    }
    async loadNamespaceMetadata(e) {
        return {
            properties: (await this.client.request({
                method: `GET`,
                path: `${this.prefix}/namespaces/${Tt(e.namespace)}`
            })).data.properties
        }
    }
    async namespaceExists(e) {
        try {
            return await this.client.request({
                method: `HEAD`,
                path: `${this.prefix}/namespaces/${Tt(e.namespace)}`
            }), !0
        } catch (e) {
            if (e instanceof xt && e.status === 404) return !1;
            throw e
        }
    }
    async createNamespaceIfNotExists(e, t) {
        try {
            return await this.createNamespace(e, t)
        } catch (e) {
            if (e instanceof xt && e.status === 409) return;
            throw e
        }
    }
};

function A(e) {
    return e.join(``)
}
var Dt = class {
        constructor(e, t = ``, n) {
            this.client = e, this.prefix = t, this.accessDelegation = n
        }
        async listTables(e) {
            return (await this.client.request({
                method: `GET`,
                path: `${this.prefix}/namespaces/${A(e.namespace)}/tables`
            })).data.identifiers
        }
        async createTable(e, t) {
            let n = {};
            return this.accessDelegation && (n[`X-Iceberg-Access-Delegation`] = this.accessDelegation), (await this.client.request({
                method: `POST`,
                path: `${this.prefix}/namespaces/${A(e.namespace)}/tables`,
                body: t,
                headers: n
            })).data.metadata
        }
        async updateTable(e, t) {
            let n = await this.client.request({
                method: `POST`,
                path: `${this.prefix}/namespaces/${A(e.namespace)}/tables/${e.name}`,
                body: t
            });
            return {
                "metadata-location": n.data[`metadata-location`],
                metadata: n.data.metadata
            }
        }
        async dropTable(e, t) {
            await this.client.request({
                method: `DELETE`,
                path: `${this.prefix}/namespaces/${A(e.namespace)}/tables/${e.name}`,
                query: {
                    purgeRequested: String(t ?.purge ?? !1)
                }
            })
        }
        async loadTable(e) {
            let t = {};
            return this.accessDelegation && (t[`X-Iceberg-Access-Delegation`] = this.accessDelegation), (await this.client.request({
                method: `GET`,
                path: `${this.prefix}/namespaces/${A(e.namespace)}/tables/${e.name}`,
                headers: t
            })).data.metadata
        }
        async tableExists(e) {
            let t = {};
            this.accessDelegation && (t[`X-Iceberg-Access-Delegation`] = this.accessDelegation);
            try {
                return await this.client.request({
                    method: `HEAD`,
                    path: `${this.prefix}/namespaces/${A(e.namespace)}/tables/${e.name}`,
                    headers: t
                }), !0
            } catch (e) {
                if (e instanceof xt && e.status === 404) return !1;
                throw e
            }
        }
        async createTableIfNotExists(e, t) {
            try {
                return await this.createTable(e, t)
            } catch (n) {
                if (n instanceof xt && n.status === 409) return await this.loadTable({
                    namespace: e.namespace,
                    name: t.name
                });
                throw n
            }
        }
    },
    Ot = class {
        constructor(e) {
            let t = `v1`;
            e.catalogName && (t += `/${e.catalogName}`);
            let n = e.baseUrl.endsWith(`/`) ? e.baseUrl : `${e.baseUrl}/`;
            this.client = wt({
                baseUrl: n,
                auth: e.auth,
                fetchImpl: e.fetch
            }), this.accessDelegation = e.accessDelegation ?.join(`,`), this.namespaceOps = new Et(this.client, t), this.tableOps = new Dt(this.client, t, this.accessDelegation)
        }
        async listNamespaces(e) {
            return this.namespaceOps.listNamespaces(e)
        }
        async createNamespace(e, t) {
            return this.namespaceOps.createNamespace(e, t)
        }
        async dropNamespace(e) {
            await this.namespaceOps.dropNamespace(e)
        }
        async loadNamespaceMetadata(e) {
            return this.namespaceOps.loadNamespaceMetadata(e)
        }
        async listTables(e) {
            return this.tableOps.listTables(e)
        }
        async createTable(e, t) {
            return this.tableOps.createTable(e, t)
        }
        async updateTable(e, t) {
            return this.tableOps.updateTable(e, t)
        }
        async dropTable(e, t) {
            await this.tableOps.dropTable(e, t)
        }
        async loadTable(e) {
            return this.tableOps.loadTable(e)
        }
        async namespaceExists(e) {
            return this.namespaceOps.namespaceExists(e)
        }
        async tableExists(e) {
            return this.tableOps.tableExists(e)
        }
        async createNamespaceIfNotExists(e, t) {
            return this.namespaceOps.createNamespaceIfNotExists(e, t)
        }
        async createTableIfNotExists(e, t) {
            return this.tableOps.createTableIfNotExists(e, t)
        }
    };

function kt(e) {
    "@babel/helpers - typeof";
    return kt = typeof Symbol == `function` && typeof Symbol.iterator == `symbol` ? function(e) {
        return typeof e
    } : function(e) {
        return e && typeof Symbol == `function` && e.constructor === Symbol && e !== Symbol.prototype ? `symbol` : typeof e
    }, kt(e)
}

function At(e, t) {
    if (kt(e) != `object` || !e) return e;
    var n = e[Symbol.toPrimitive];
    if (n !== void 0) {
        var r = n.call(e, t || `default`);
        if (kt(r) != `object`) return r;
        throw TypeError(`@@toPrimitive must return a primitive value.`)
    }
    return (t === `string` ? String : Number)(e)
}

function jt(e) {
    var t = At(e, `string`);
    return kt(t) == `symbol` ? t : t + ``
}

function Mt(e, t, n) {
    return (t = jt(t)) in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function Nt(e, t) {
    var n = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t && (r = r.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable
        })), n.push.apply(n, r)
    }
    return n
}

function j(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] == null ? {} : arguments[t];
        t % 2 ? Nt(Object(n), !0).forEach(function(t) {
            Mt(e, t, n[t])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : Nt(Object(n)).forEach(function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
        })
    }
    return e
}
var Pt = class extends Error {
    constructor(e, t = `storage`, n, r) {
        super(e), this.__isStorageError = !0, this.namespace = t, this.name = t === `vectors` ? `StorageVectorsError` : `StorageError`, this.status = n, this.statusCode = r
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            status: this.status,
            statusCode: this.statusCode
        }
    }
};

function Ft(e) {
    return typeof e == `object` && !!e && `__isStorageError` in e
}
var It = class extends Pt {
        constructor(e, t, n, r = `storage`, i) {
            super(e, r, t, n), this.name = r === `vectors` ? `StorageVectorsApiError` : `StorageApiError`, this.status = t, this.statusCode = n, this.code = i
        }
        toJSON() {
            return j(j({}, super.toJSON()), {}, {
                code: this.code
            })
        }
    },
    Lt = class extends Pt {
        constructor(e, t, n = `storage`) {
            super(e, n), this.name = n === `vectors` ? `StorageVectorsUnknownError` : `StorageUnknownError`, this.originalError = t
        }
    };

function Rt(e, t, n) {
    let r = j({}, e),
        i = t.toLowerCase();
    for (let e of Object.keys(r)) e.toLowerCase() === i && delete r[e];
    return r[i] = n, r
}

function zt(e) {
    let t = {};
    for (let [n, r] of Object.entries(e)) t[n.toLowerCase()] = r;
    return t
}
var Bt = e => e ? (...t) => e(...t) : (...e) => fetch(...e),
    Vt = e => {
        if (typeof e != `object` || !e) return !1;
        let t = Object.getPrototypeOf(e);
        return (t === null || t === Object.prototype || Object.getPrototypeOf(t) === null) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e)
    },
    Ht = e => {
        if (Array.isArray(e)) return e.map(e => Ht(e));
        if (typeof e == `function` || e !== Object(e)) return e;
        let t = {};
        return Object.entries(e).forEach(([e, n]) => {
            let r = e.replace(/([-_][a-z])/gi, e => e.toUpperCase().replace(/[-_]/g, ``));
            t[r] = Ht(n)
        }), t
    },
    Ut = e => !e || typeof e != `string` || e.length === 0 || e.length > 100 || e.trim() !== e || e.includes(`/`) || e.includes(`\\`) ? !1 : /^[\w!.\*'() &$@=;:+,?-]+$/.test(e),
    Wt = e => e.split(`/`).map(encodeURIComponent).join(`/`),
    Gt = e => {
        if (typeof e == `object` && e) {
            let t = e;
            if (typeof t.msg == `string`) return t.msg;
            if (typeof t.message == `string`) return t.message;
            if (typeof t.error_description == `string`) return t.error_description;
            if (typeof t.error == `string`) return t.error;
            if (typeof t.error == `object` && t.error !== null) {
                let e = t.error;
                if (typeof e.message == `string`) return e.message
            }
        }
        return JSON.stringify(e)
    },
    Kt = async (e, t, n, r) => {
        if (typeof e == `object` && e && `json` in e && typeof e.json == `function`) {
            let n = e,
                i = parseInt(String(n.status), 10);
            Number.isFinite(i) || (i = 500), n.json().then(e => {
                let n = e ?.statusCode || e ?.code || i + ``;
                t(new It(Gt(e), i, n, r, e ?.code))
            }).catch(() => {
                let e = i + ``;
                t(new It(n.statusText || `HTTP ${i} error`, i, e, r))
            })
        } else t(new Lt(Gt(e), e, r))
    },
    qt = (e, t, n, r) => {
        let i = {
            method: e,
            headers: t ?.headers || {}
        };
        if (e === `GET` || e === `HEAD` || !r) return j(j({}, i), n);
        if (Vt(r)) {
            let e = t ?.headers || {},
                n;
            for (let [t, r] of Object.entries(e)) t.toLowerCase() === `content-type` && (n = r);
            i.headers = Rt(e, `Content-Type`, n ?? `application/json`), i.body = JSON.stringify(r)
        } else i.body = r;
        return t ?.duplex && (i.duplex = t.duplex), j(j({}, i), n)
    };
async function Jt(e, t, n, r, i, a, o) {
    return new Promise((s, c) => {
        e(n, qt(t, r, i, a)).then(e => {
            if (!e.ok) throw e;
            if (r ?.noResolveJson) return e;
            if (o === `vectors`) {
                let t = e.headers.get(`content-type`);
                if (e.headers.get(`content-length`) === `0` || e.status === 204 || !t || !t.includes(`application/json`)) return {}
            }
            return e.json()
        }).then(e => s(e)).catch(e => Kt(e, c, r, o))
    })
}

function Yt(e = `storage`) {
    return {
        get: async (t, n, r, i) => Jt(t, `GET`, n, r, i, void 0, e),
        post: async (t, n, r, i, a) => Jt(t, `POST`, n, i, a, r, e),
        put: async (t, n, r, i, a) => Jt(t, `PUT`, n, i, a, r, e),
        head: async (t, n, r, i) => Jt(t, `HEAD`, n, j(j({}, r), {}, {
            noResolveJson: !0
        }), i, void 0, e),
        remove: async (t, n, r, i, a) => Jt(t, `DELETE`, n, i, a, r, e)
    }
}
var {
    get: Xt,
    post: M,
    put: Zt,
    head: Qt,
    remove: $t
} = Yt(`storage`), N = Yt(`vectors`), en = class {
    constructor(e, t = {}, n, r = `storage`) {
        this.shouldThrowOnError = !1, this.url = e, this.headers = zt(t), this.fetch = Bt(n), this.namespace = r
    }
    throwOnError() {
        return this.shouldThrowOnError = !0, this
    }
    setHeader(e, t) {
        return this.headers = Rt(this.headers, e, t), this
    }
    async handleOperation(e) {
        var t = this;
        try {
            return {
                data: await e(),
                error: null
            }
        } catch (e) {
            if (t.shouldThrowOnError) throw e;
            if (Ft(e)) return {
                data: null,
                error: e
            };
            throw e
        }
    }
}, tn = Symbol.toStringTag, nn = class {
    constructor(e, t) {
        this.downloadFn = e, this.shouldThrowOnError = t, this[tn] = `StreamDownloadBuilder`, this.promise = null
    }
    then(e, t) {
        return this.getPromise().then(e, t)
    } catch (e) {
        return this.getPromise().catch(e)
    } finally(e) {
        return this.getPromise().finally(e)
    }
    getPromise() {
        return this.promise ||= this.execute(), this.promise
    }
    async execute() {
        var e = this;
        try {
            return {
                data: (await e.downloadFn()).body,
                error: null
            }
        } catch (t) {
            if (e.shouldThrowOnError) throw t;
            if (Ft(t)) return {
                data: null,
                error: t
            };
            throw t
        }
    }
}, rn = Symbol.toStringTag, an = class {
    constructor(e, t) {
        this.downloadFn = e, this.shouldThrowOnError = t, this[rn] = `BlobDownloadBuilder`, this.promise = null
    }
    asStream() {
        return new nn(this.downloadFn, this.shouldThrowOnError)
    }
    then(e, t) {
        return this.getPromise().then(e, t)
    } catch (e) {
        return this.getPromise().catch(e)
    } finally(e) {
        return this.getPromise().finally(e)
    }
    getPromise() {
        return this.promise ||= this.execute(), this.promise
    }
    async execute() {
        var e = this;
        try {
            return {
                data: await (await e.downloadFn()).blob(),
                error: null
            }
        } catch (t) {
            if (e.shouldThrowOnError) throw t;
            if (Ft(t)) return {
                data: null,
                error: t
            };
            throw t
        }
    }
}, on = {
    limit: 100,
    offset: 0,
    sortBy: {
        column: `name`,
        order: `asc`
    }
}, sn = {
    cacheControl: `3600`,
    contentType: `text/plain;charset=UTF-8`,
    upsert: !1
}, cn = class extends en {
    constructor(e, t = {}, n, r) {
        super(e, t, r, `storage`), this.bucketId = n
    }
    async uploadOrUpdate(e, t, n, r) {
        var i = this;
        return i.handleOperation(async () => {
            let a, o = j(j({}, sn), r),
                s = j(j({}, i.headers), e === `POST` && {
                    "x-upsert": String(o.upsert)
                }),
                c = o.metadata;
            if (typeof Blob < `u` && n instanceof Blob ? (a = new FormData, a.append(`cacheControl`, o.cacheControl), c && a.append(`metadata`, i.encodeMetadata(c)), a.append(``, n)) : typeof FormData < `u` && n instanceof FormData ? (a = n, a.has(`cacheControl`) || a.append(`cacheControl`, o.cacheControl), c && !a.has(`metadata`) && a.append(`metadata`, i.encodeMetadata(c))) : (a = n, s[`cache-control`] = `max-age=${o.cacheControl}`, s[`content-type`] = o.contentType, c && (s[`x-metadata`] = i.toBase64(i.encodeMetadata(c))), (typeof ReadableStream < `u` && a instanceof ReadableStream || a && typeof a == `object` && `pipe` in a && typeof a.pipe == `function`) && !o.duplex && (o.duplex = `half`)), r ?.headers)
                for (let [e, t] of Object.entries(r.headers)) s = Rt(s, e, t);
            let l = i._removeEmptyFolders(t),
                u = i._getFinalPath(l),
                d = await (e == `PUT` ? Zt : M)(i.fetch, `${i.url}/object/${u}`, a, j({
                    headers: s
                }, o ?.duplex ? {
                    duplex: o.duplex
                } : {}));
            return {
                path: l,
                id: d.Id,
                fullPath: d.Key
            }
        })
    }
    async upload(e, t, n) {
        return this.uploadOrUpdate(`POST`, e, t, n)
    }
    async uploadToSignedUrl(e, t, n, r) {
        var i = this;
        let a = i._removeEmptyFolders(e),
            o = i._getFinalPath(a),
            s = new URL(i.url + `/object/upload/sign/${o}`);
        return s.searchParams.set(`token`, t), i.handleOperation(async () => {
            let e, t = j(j({}, sn), r),
                o = j(j({}, i.headers), {
                    "x-upsert": String(t.upsert)
                }),
                c = t.metadata;
            if (typeof Blob < `u` && n instanceof Blob ? (e = new FormData, e.append(`cacheControl`, t.cacheControl), c && e.append(`metadata`, i.encodeMetadata(c)), e.append(``, n)) : typeof FormData < `u` && n instanceof FormData ? (e = n, e.has(`cacheControl`) || e.append(`cacheControl`, t.cacheControl), c && !e.has(`metadata`) && e.append(`metadata`, i.encodeMetadata(c))) : (e = n, o[`cache-control`] = `max-age=${t.cacheControl}`, o[`content-type`] = t.contentType, c && (o[`x-metadata`] = i.toBase64(i.encodeMetadata(c))), (typeof ReadableStream < `u` && e instanceof ReadableStream || e && typeof e == `object` && `pipe` in e && typeof e.pipe == `function`) && !t.duplex && (t.duplex = `half`)), r ?.headers)
                for (let [e, t] of Object.entries(r.headers)) o = Rt(o, e, t);
            return {
                path: a,
                fullPath: (await Zt(i.fetch, s.toString(), e, j({
                    headers: o
                }, t ?.duplex ? {
                    duplex: t.duplex
                } : {}))).Key
            }
        })
    }
    async createSignedUploadUrl(e, t) {
        var n = this;
        return n.handleOperation(async () => {
            let r = n._getFinalPath(e),
                i = j({}, n.headers);
            t ?.upsert && (i[`x-upsert`] = `true`);
            let a = await M(n.fetch, `${n.url}/object/upload/sign/${r}`, {}, {
                    headers: i
                }),
                o = new URL(n.url + a.url),
                s = o.searchParams.get(`token`);
            if (!s) throw new Pt(`No token returned by API`);
            return {
                signedUrl: o.toString(),
                path: e,
                token: s
            }
        })
    }
    async update(e, t, n) {
        return this.uploadOrUpdate(`PUT`, e, t, n)
    }
    async move(e, t, n) {
        var r = this;
        return r.handleOperation(async () => await M(r.fetch, `${r.url}/object/move`, {
            bucketId: r.bucketId,
            sourceKey: e,
            destinationKey: t,
            destinationBucket: n ?.destinationBucket
        }, {
            headers: r.headers
        }))
    }
    async copy(e, t, n) {
        var r = this;
        return r.handleOperation(async () => ({
            path: (await M(r.fetch, `${r.url}/object/copy`, {
                bucketId: r.bucketId,
                sourceKey: e,
                destinationKey: t,
                destinationBucket: n ?.destinationBucket
            }, {
                headers: r.headers
            })).Key
        }))
    }
    async createSignedUrl(e, t, n) {
        var r = this;
        return r.handleOperation(async () => {
            let i = r._getFinalPath(e),
                a = typeof n ?.transform == `object` && n.transform !== null && Object.keys(n.transform).length > 0,
                o = await M(r.fetch, `${r.url}/object/sign/${i}`, j({
                    expiresIn: t
                }, a ? {
                    transform: n.transform
                } : {}), {
                    headers: r.headers
                }),
                s = new URLSearchParams;
            n ?.download && s.set(`download`, n.download === !0 ? `` : n.download), n ?.cacheNonce != null && s.set(`cacheNonce`, String(n.cacheNonce));
            let c = s.toString();
            return {
                signedUrl: encodeURI(`${r.url}${o.signedURL}${c?`&${c}`:``}`)
            }
        })
    }
    async createSignedUrls(e, t, n) {
        var r = this;
        return r.handleOperation(async () => {
            let i = await M(r.fetch, `${r.url}/object/sign/${r.bucketId}`, {
                    expiresIn: t,
                    paths: e
                }, {
                    headers: r.headers
                }),
                a = new URLSearchParams;
            n ?.download && a.set(`download`, n.download === !0 ? `` : n.download), n ?.cacheNonce != null && a.set(`cacheNonce`, String(n.cacheNonce));
            let o = a.toString();
            return i.map(e => j(j({}, e), {}, {
                signedUrl: e.signedURL ? encodeURI(`${r.url}${e.signedURL}${o?`&${o}`:``}`) : null
            }))
        })
    }
    download(e, t, n) {
        let r = typeof t ?.transform == `object` && t.transform !== null && Object.keys(t.transform).length > 0 ? `render/image/authenticated` : `object`,
            i = new URLSearchParams;
        t ?.transform && this.applyTransformOptsToQuery(i, t.transform), t ?.cacheNonce != null && i.set(`cacheNonce`, String(t.cacheNonce));
        let a = i.toString(),
            o = this._getFinalPath(e);
        return new an(() => Xt(this.fetch, `${this.url}/${r}/${o}${a?`?${a}`:``}`, {
            headers: this.headers,
            noResolveJson: !0
        }, n), this.shouldThrowOnError)
    }
    async info(e) {
        var t = this;
        let n = t._getFinalPath(e);
        return t.handleOperation(async () => Ht(await Xt(t.fetch, `${t.url}/object/info/${n}`, {
            headers: t.headers
        })))
    }
    async exists(e) {
        var t = this;
        let n = t._getFinalPath(e);
        try {
            return await Qt(t.fetch, `${t.url}/object/${n}`, {
                headers: t.headers
            }), {
                data: !0,
                error: null
            }
        } catch (e) {
            if (t.shouldThrowOnError) throw e;
            if (Ft(e)) {
                let t = e instanceof It ? e.status : e instanceof Lt ? e.originalError ?.status : void 0;
                if (t !== void 0 && [400, 404].includes(t)) return {
                    data: !1,
                    error: e
                }
            }
            throw e
        }
    }
    getPublicUrl(e, t) {
        let n = this._getFinalPath(e),
            r = new URLSearchParams;
        t ?.download && r.set(`download`, t.download === !0 ? `` : t.download), t ?.transform && this.applyTransformOptsToQuery(r, t.transform), t ?.cacheNonce != null && r.set(`cacheNonce`, String(t.cacheNonce));
        let i = r.toString(),
            a = typeof t ?.transform == `object` && t.transform !== null && Object.keys(t.transform).length > 0 ? `render/image` : `object`;
        return {
            data: {
                publicUrl: encodeURI(`${this.url}/${a}/public/${n}`) + (i ? `?${i}` : ``)
            }
        }
    }
    async remove(e) {
        var t = this;
        return t.handleOperation(async () => await $t(t.fetch, `${t.url}/object/${t.bucketId}`, {
            prefixes: e
        }, {
            headers: t.headers
        }))
    }
    async purgeCache(e, t, n) {
        var r = this;
        return r.handleOperation(async () => {
            let i = Wt(r._getFinalPath(e)),
                a = new URLSearchParams;
            t ?.transformations && a.set(`transformations`, `true`);
            let o = a.toString();
            return await $t(r.fetch, `${r.url}/cdn/${i}${o?`?${o}`:``}`, {}, {
                headers: r.headers
            }, n)
        })
    }
    async list(e, t, n) {
        var r = this;
        return r.handleOperation(async () => {
            let i = t ?.sortBy ? j(j({}, on.sortBy), t.sortBy) : on.sortBy,
                a = j(j(j({}, on), t), {}, {
                    sortBy: i,
                    prefix: e || ``
                });
            return await M(r.fetch, `${r.url}/object/list/${r.bucketId}`, a, {
                headers: r.headers
            }, n)
        })
    }
    async listV2(e, t) {
        var n = this;
        return n.handleOperation(async () => {
            let r = j({}, e);
            return await M(n.fetch, `${n.url}/object/list-v2/${n.bucketId}`, r, {
                headers: n.headers
            }, t)
        })
    }
    encodeMetadata(e) {
        return JSON.stringify(e)
    }
    toBase64(e) {
        return typeof Buffer < `u` ? Buffer.from(e).toString(`base64`) : btoa(e)
    }
    _getFinalPath(e) {
        return `${this.bucketId}/${e.replace(/^\/+/,``)}`
    }
    _removeEmptyFolders(e) {
        return e.replace(/^\/|\/$/g, ``).replace(/\/+/g, `/`)
    }
    applyTransformOptsToQuery(e, t) {
        return t.width && e.set(`width`, t.width.toString()), t.height && e.set(`height`, t.height.toString()), t.resize && e.set(`resize`, t.resize), t.format && e.set(`format`, t.format), t.quality && e.set(`quality`, t.quality.toString()), e
    }
}, ln = {
    "X-Client-Info": `storage-js/2.112.2`
}, un = class extends en {
    constructor(e, t = {}, n, r) {
        let i = new URL(e);
        r ?.useNewHostname && /supabase\.(co|in|red)$/.test(i.hostname) && !i.hostname.includes(`storage.supabase.`) && (i.hostname = i.hostname.replace(`supabase.`, `storage.supabase.`));
        let a = i.href.replace(/\/$/, ``),
            o = j(j({}, ln), t);
        super(a, o, n, `storage`)
    }
    async listBuckets(e) {
        var t = this;
        return t.handleOperation(async () => {
            let n = t.listBucketOptionsToQueryString(e);
            return await Xt(t.fetch, `${t.url}/bucket${n}`, {
                headers: t.headers
            })
        })
    }
    async getBucket(e) {
        var t = this;
        return t.handleOperation(async () => await Xt(t.fetch, `${t.url}/bucket/${e}`, {
            headers: t.headers
        }))
    }
    async createBucket(e, t = {
        public: !1
    }) {
        var n = this;
        return n.handleOperation(async () => await M(n.fetch, `${n.url}/bucket`, {
            id: e,
            name: e,
            type: t.type,
            public: t.public,
            file_size_limit: t.fileSizeLimit,
            allowed_mime_types: t.allowedMimeTypes
        }, {
            headers: n.headers
        }))
    }
    async updateBucket(e, t) {
        var n = this;
        return n.handleOperation(async () => await Zt(n.fetch, `${n.url}/bucket/${e}`, {
            id: e,
            name: e,
            public: t.public,
            file_size_limit: t.fileSizeLimit,
            allowed_mime_types: t.allowedMimeTypes
        }, {
            headers: n.headers
        }))
    }
    async emptyBucket(e) {
        var t = this;
        return t.handleOperation(async () => await M(t.fetch, `${t.url}/bucket/${e}/empty`, {}, {
            headers: t.headers
        }))
    }
    async deleteBucket(e) {
        var t = this;
        return t.handleOperation(async () => await $t(t.fetch, `${t.url}/bucket/${e}`, {}, {
            headers: t.headers
        }))
    }
    async purgeBucketCache(e, t, n) {
        var r = this;
        return r.handleOperation(async () => {
            let i = new URLSearchParams;
            t ?.transformations && i.set(`transformations`, `true`);
            let a = i.toString();
            return await $t(r.fetch, `${r.url}/cdn/${Wt(e)}${a?`?${a}`:``}`, {}, {
                headers: r.headers
            }, n)
        })
    }
    listBucketOptionsToQueryString(e) {
        let t = {};
        return e && (`limit` in e && (t.limit = String(e.limit)), `offset` in e && (t.offset = String(e.offset)), e.search && (t.search = e.search), e.sortColumn && (t.sortColumn = e.sortColumn), e.sortOrder && (t.sortOrder = e.sortOrder)), Object.keys(t).length > 0 ? `?` + new URLSearchParams(t).toString() : ``
    }
}, dn = class extends en {
    constructor(e, t = {}, n) {
        let r = e.replace(/\/$/, ``),
            i = j(j({}, ln), t);
        super(r, i, n, `storage`)
    }
    async createBucket(e) {
        var t = this;
        return t.handleOperation(async () => await M(t.fetch, `${t.url}/bucket`, {
            name: e
        }, {
            headers: t.headers
        }))
    }
    async listBuckets(e) {
        var t = this;
        return t.handleOperation(async () => {
            let n = new URLSearchParams;
            e ?.limit !== void 0 && n.set(`limit`, e.limit.toString()), e ?.offset !== void 0 && n.set(`offset`, e.offset.toString()), e ?.sortColumn && n.set(`sortColumn`, e.sortColumn), e ?.sortOrder && n.set(`sortOrder`, e.sortOrder), e ?.search && n.set(`search`, e.search);
            let r = n.toString(),
                i = r ? `${t.url}/bucket?${r}` : `${t.url}/bucket`;
            return await Xt(t.fetch, i, {
                headers: t.headers
            })
        })
    }
    async deleteBucket(e) {
        var t = this;
        return t.handleOperation(async () => await $t(t.fetch, `${t.url}/bucket/${e}`, {}, {
            headers: t.headers
        }))
    }
    from(e) {
        var t = this;
        if (!Ut(e)) throw new Pt(`Invalid bucket name: File, folder, and bucket names must follow AWS object key naming guidelines and should avoid the use of any other characters.`);
        let n = new Ot({
                baseUrl: this.url,
                catalogName: e,
                auth: {
                    type: `custom`,
                    getHeaders: async () => t.headers
                },
                fetch: this.fetch
            }),
            r = this.shouldThrowOnError;
        return new Proxy(n, {
            get(e, t) {
                let n = e[t];
                return typeof n == `function` ? async (...t) => {
                    try {
                        return {
                            data: await n.apply(e, t),
                            error: null
                        }
                    } catch (e) {
                        if (r) throw e;
                        return {
                            data: null,
                            error: e
                        }
                    }
                } : n
            }
        })
    }
}, fn = class extends en {
    constructor(e, t = {}, n) {
        let r = e.replace(/\/$/, ``),
            i = j(j({}, ln), {}, {
                "Content-Type": `application/json`
            }, t);
        super(r, i, n, `vectors`)
    }
    async createIndex(e) {
        var t = this;
        return t.handleOperation(async () => await N.post(t.fetch, `${t.url}/CreateIndex`, e, {
            headers: t.headers
        }) || {})
    }
    async getIndex(e, t) {
        var n = this;
        return n.handleOperation(async () => await N.post(n.fetch, `${n.url}/GetIndex`, {
            vectorBucketName: e,
            indexName: t
        }, {
            headers: n.headers
        }))
    }
    async listIndexes(e) {
        var t = this;
        return t.handleOperation(async () => await N.post(t.fetch, `${t.url}/ListIndexes`, e, {
            headers: t.headers
        }))
    }
    async deleteIndex(e, t) {
        var n = this;
        return n.handleOperation(async () => await N.post(n.fetch, `${n.url}/DeleteIndex`, {
            vectorBucketName: e,
            indexName: t
        }, {
            headers: n.headers
        }) || {})
    }
}, pn = class extends en {
    constructor(e, t = {}, n) {
        let r = e.replace(/\/$/, ``),
            i = j(j({}, ln), {}, {
                "Content-Type": `application/json`
            }, t);
        super(r, i, n, `vectors`)
    }
    async putVectors(e) {
        var t = this;
        if (e.vectors.length < 1 || e.vectors.length > 500) throw Error(`Vector batch size must be between 1 and 500 items`);
        return t.handleOperation(async () => await N.post(t.fetch, `${t.url}/PutVectors`, e, {
            headers: t.headers
        }) || {})
    }
    async getVectors(e) {
        var t = this;
        return t.handleOperation(async () => await N.post(t.fetch, `${t.url}/GetVectors`, e, {
            headers: t.headers
        }))
    }
    async listVectors(e) {
        var t = this;
        if (e.segmentCount !== void 0) {
            if (e.segmentCount < 1 || e.segmentCount > 16) throw Error(`segmentCount must be between 1 and 16`);
            if (e.segmentIndex !== void 0 && (e.segmentIndex < 0 || e.segmentIndex >= e.segmentCount)) throw Error(`segmentIndex must be between 0 and ${e.segmentCount-1}`)
        }
        return t.handleOperation(async () => await N.post(t.fetch, `${t.url}/ListVectors`, e, {
            headers: t.headers
        }))
    }
    async queryVectors(e) {
        var t = this;
        return t.handleOperation(async () => await N.post(t.fetch, `${t.url}/QueryVectors`, e, {
            headers: t.headers
        }))
    }
    async deleteVectors(e) {
        var t = this;
        if (e.keys.length < 1 || e.keys.length > 500) throw Error(`Keys batch size must be between 1 and 500 items`);
        return t.handleOperation(async () => await N.post(t.fetch, `${t.url}/DeleteVectors`, e, {
            headers: t.headers
        }) || {})
    }
}, mn = class extends en {
    constructor(e, t = {}, n) {
        let r = e.replace(/\/$/, ``),
            i = j(j({}, ln), {}, {
                "Content-Type": `application/json`
            }, t);
        super(r, i, n, `vectors`)
    }
    async createBucket(e) {
        var t = this;
        return t.handleOperation(async () => await N.post(t.fetch, `${t.url}/CreateVectorBucket`, {
            vectorBucketName: e
        }, {
            headers: t.headers
        }) || {})
    }
    async getBucket(e) {
        var t = this;
        return t.handleOperation(async () => await N.post(t.fetch, `${t.url}/GetVectorBucket`, {
            vectorBucketName: e
        }, {
            headers: t.headers
        }))
    }
    async listBuckets(e = {}) {
        var t = this;
        return t.handleOperation(async () => await N.post(t.fetch, `${t.url}/ListVectorBuckets`, e, {
            headers: t.headers
        }))
    }
    async deleteBucket(e) {
        var t = this;
        return t.handleOperation(async () => await N.post(t.fetch, `${t.url}/DeleteVectorBucket`, {
            vectorBucketName: e
        }, {
            headers: t.headers
        }) || {})
    }
}, hn = class extends mn {
    constructor(e, t = {}) {
        super(e, t.headers || {}, t.fetch)
    }
    from(e) {
        return new gn(this.url, this.headers, e, this.fetch)
    }
    async createBucket(e) {
        var t = () => super.createBucket,
            n = this;
        return t().call(n, e)
    }
    async getBucket(e) {
        var t = () => super.getBucket,
            n = this;
        return t().call(n, e)
    }
    async listBuckets(e = {}) {
        var t = () => super.listBuckets,
            n = this;
        return t().call(n, e)
    }
    async deleteBucket(e) {
        var t = () => super.deleteBucket,
            n = this;
        return t().call(n, e)
    }
}, gn = class extends fn {
    constructor(e, t, n, r) {
        super(e, t, r), this.vectorBucketName = n
    }
    async createIndex(e) {
        var t = () => super.createIndex,
            n = this;
        return t().call(n, j(j({}, e), {}, {
            vectorBucketName: n.vectorBucketName
        }))
    }
    async listIndexes(e = {}) {
        var t = () => super.listIndexes,
            n = this;
        return t().call(n, j(j({}, e), {}, {
            vectorBucketName: n.vectorBucketName
        }))
    }
    async getIndex(e) {
        var t = () => super.getIndex,
            n = this;
        return t().call(n, n.vectorBucketName, e)
    }
    async deleteIndex(e) {
        var t = () => super.deleteIndex,
            n = this;
        return t().call(n, n.vectorBucketName, e)
    }
    index(e) {
        return new _n(this.url, this.headers, this.vectorBucketName, e, this.fetch)
    }
}, _n = class extends pn {
    constructor(e, t, n, r, i) {
        super(e, t, i), this.vectorBucketName = n, this.indexName = r
    }
    async putVectors(e) {
        var t = () => super.putVectors,
            n = this;
        return t().call(n, j(j({}, e), {}, {
            vectorBucketName: n.vectorBucketName,
            indexName: n.indexName
        }))
    }
    async getVectors(e) {
        var t = () => super.getVectors,
            n = this;
        return t().call(n, j(j({}, e), {}, {
            vectorBucketName: n.vectorBucketName,
            indexName: n.indexName
        }))
    }
    async listVectors(e = {}) {
        var t = () => super.listVectors,
            n = this;
        return t().call(n, j(j({}, e), {}, {
            vectorBucketName: n.vectorBucketName,
            indexName: n.indexName
        }))
    }
    async queryVectors(e) {
        var t = () => super.queryVectors,
            n = this;
        return t().call(n, j(j({}, e), {}, {
            vectorBucketName: n.vectorBucketName,
            indexName: n.indexName
        }))
    }
    async deleteVectors(e) {
        var t = () => super.deleteVectors,
            n = this;
        return t().call(n, j(j({}, e), {}, {
            vectorBucketName: n.vectorBucketName,
            indexName: n.indexName
        }))
    }
}, vn = class extends un {
    constructor(e, t = {}, n, r) {
        super(e, t, n, r)
    }
    from(e) {
        return new cn(this.url, this.headers, e, this.fetch)
    }
    get vectors() {
        return new hn(this.url + `/vector`, {
            headers: this.headers,
            fetch: this.fetch
        })
    }
    get analytics() {
        return new dn(this.url + `/iceberg`, this.headers, this.fetch)
    }
}, yn = `2.112.2`, P = 3e4, bn = 3 * P, xn = 2 * P, Sn = `http://localhost:9999`, Cn = `supabase.auth.token`, wn = {
    "X-Client-Info": `gotrue-js/${yn}`
}, Tn = `X-Supabase-Api-Version`, En = {
    "2024-01-01": {
        timestamp: Date.parse(`2024-01-01T00:00:00.0Z`),
        name: `2024-01-01`
    }
}, Dn = /^([a-z0-9_-]{4})*($|[a-z0-9_-]{3}$|[a-z0-9_-]{2}$)$/i, On = `sb_flow_id`, kn = class extends Error {
    constructor(e, t, n) {
        super(e), this.__isAuthError = !0, this.name = `AuthError`, this.status = t, this.code = n
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            status: this.status,
            code: this.code
        }
    }
};

function F(e) {
    return typeof e == `object` && !!e && `__isAuthError` in e
}
var An = class extends kn {
    constructor(e, t, n) {
        super(e, t, n), this.name = `AuthApiError`, this.status = t, this.code = n
    }
};

function jn(e) {
    return F(e) && e.name === `AuthApiError`
}
var I = class extends kn {
        constructor(e, t) {
            super(e), this.name = `AuthUnknownError`, this.originalError = t
        }
    },
    L = class extends kn {
        constructor(e, t, n, r) {
            super(e, n, r), this.name = t, this.status = n
        }
    },
    R = class extends L {
        constructor() {
            super(`Auth session missing!`, `AuthSessionMissingError`, 400, void 0)
        }
    };

function Mn(e) {
    return F(e) && e.name === `AuthSessionMissingError`
}
var Nn = class extends L {
        constructor() {
            super(`Auth session or user missing`, `AuthInvalidTokenResponseError`, 500, void 0)
        }
    },
    Pn = class extends L {
        constructor(e) {
            super(e, `AuthInvalidCredentialsError`, 400, void 0)
        }
    },
    Fn = class extends L {
        constructor(e, t = null) {
            super(e, `AuthImplicitGrantRedirectError`, 500, void 0), this.details = null, this.details = t
        }
        toJSON() {
            return Object.assign(Object.assign({}, super.toJSON()), {
                details: this.details
            })
        }
    };

function In(e) {
    return F(e) && e.name === `AuthImplicitGrantRedirectError`
}
var Ln = class extends L {
        constructor(e, t = null) {
            super(e, `AuthPKCEGrantCodeExchangeError`, 500, void 0), this.details = null, this.details = t
        }
        toJSON() {
            return Object.assign(Object.assign({}, super.toJSON()), {
                details: this.details
            })
        }
    },
    Rn = class extends L {
        constructor() {
            super(`PKCE code verifier not found in storage. This can happen if the auth flow was initiated in a different browser or device, or if the storage was cleared. For SSR frameworks (Next.js, SvelteKit, etc.), use @supabase/ssr on both the server and client to store the code verifier in cookies.`, `AuthPKCECodeVerifierMissingError`, 400, `pkce_code_verifier_not_found`)
        }
    },
    zn = class extends L {
        constructor(e, t) {
            super(e, `AuthRetryableFetchError`, t, void 0)
        }
    };

function Bn(e) {
    return F(e) && e.name === `AuthRetryableFetchError`
}
var Vn = class extends L {
    constructor(e = `Refresh result discarded: session state changed mid-flight (e.g., concurrent signOut)`) {
        super(e, `AuthRefreshDiscardedError`, 409, void 0)
    }
};

function Hn(e) {
    return F(e) && e.name === `AuthRefreshDiscardedError`
}
var Un = class extends L {
        constructor(e, t, n) {
            super(e, `AuthWeakPasswordError`, t, `weak_password`), this.reasons = n
        }
        toJSON() {
            return Object.assign(Object.assign({}, super.toJSON()), {
                reasons: this.reasons
            })
        }
    },
    Wn = class extends L {
        constructor(e) {
            super(e, `AuthInvalidJwtError`, 400, `invalid_jwt`)
        }
    },
    Gn = `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_`.split(``),
    Kn = ` 	
\r=`.split(``),
    qn = (() => {
        let e = Array(128);
        for (let t = 0; t < e.length; t += 1) e[t] = -1;
        for (let t = 0; t < Kn.length; t += 1) e[Kn[t].charCodeAt(0)] = -2;
        for (let t = 0; t < Gn.length; t += 1) e[Gn[t].charCodeAt(0)] = t;
        return e
    })();

function Jn(e, t, n) {
    if (e !== null)
        for (t.queue = t.queue << 8 | e, t.queuedBits += 8; t.queuedBits >= 6;) n(Gn[t.queue >> t.queuedBits - 6 & 63]), t.queuedBits -= 6;
    else if (t.queuedBits > 0)
        for (t.queue <<= 6 - t.queuedBits, t.queuedBits = 6; t.queuedBits >= 6;) n(Gn[t.queue >> t.queuedBits - 6 & 63]), t.queuedBits -= 6
}

function Yn(e, t, n) {
    let r = qn[e];
    if (r > -1)
        for (t.queue = t.queue << 6 | r, t.queuedBits += 6; t.queuedBits >= 8;) n(t.queue >> t.queuedBits - 8 & 255), t.queuedBits -= 8;
    else if (r === -2) return;
    else throw Error(`Invalid Base64-URL character "${String.fromCharCode(e)}"`)
}

function Xn(e) {
    let t = [],
        n = e => {
            t.push(String.fromCodePoint(e))
        },
        r = {
            utf8seq: 0,
            codepoint: 0
        },
        i = {
            queue: 0,
            queuedBits: 0
        },
        a = e => {
            $n(e, r, n)
        };
    for (let t = 0; t < e.length; t += 1) Yn(e.charCodeAt(t), i, a);
    return t.join(``)
}

function Zn(e, t) {
    if (e <= 127) {
        t(e);
        return
    }
    if (e <= 2047) {
        t(192 | e >> 6), t(128 | e & 63);
        return
    }
    if (e <= 65535) {
        t(224 | e >> 12), t(128 | e >> 6 & 63), t(128 | e & 63);
        return
    }
    if (e <= 1114111) {
        t(240 | e >> 18), t(128 | e >> 12 & 63), t(128 | e >> 6 & 63), t(128 | e & 63);
        return
    }
    throw Error(`Unrecognized Unicode codepoint: ${e.toString(16)}`)
}

function Qn(e, t) {
    for (let n = 0; n < e.length; n += 1) {
        let r = e.charCodeAt(n);
        if (r > 55295 && r <= 56319) {
            let t = (r - 55296) * 1024 & 65535;
            r = (e.charCodeAt(n + 1) - 56320 & 65535 | t) + 65536, n += 1
        }
        Zn(r, t)
    }
}

function $n(e, t, n) {
    if (t.utf8seq === 0) {
        if (e <= 127) {
            n(e);
            return
        }
        for (let n = 1; n < 6; n += 1)
            if (!(e >> 7 - n & 1)) {
                t.utf8seq = n;
                break
            }
        if (t.utf8seq === 2) t.codepoint = e & 31;
        else if (t.utf8seq === 3) t.codepoint = e & 15;
        else if (t.utf8seq === 4) t.codepoint = e & 7;
        else throw Error(`Invalid UTF-8 sequence`);
        --t.utf8seq
    } else if (t.utf8seq > 0) {
        if (e <= 127) throw Error(`Invalid UTF-8 sequence`);
        t.codepoint = t.codepoint << 6 | e & 63, --t.utf8seq, t.utf8seq === 0 && n(t.codepoint)
    }
}

function er(e) {
    let t = [],
        n = {
            queue: 0,
            queuedBits: 0
        },
        r = e => {
            t.push(e)
        };
    for (let t = 0; t < e.length; t += 1) Yn(e.charCodeAt(t), n, r);
    return new Uint8Array(t)
}

function tr(e) {
    let t = [];
    return Qn(e, e => t.push(e)), new Uint8Array(t)
}

function z(e) {
    let t = [],
        n = {
            queue: 0,
            queuedBits: 0
        },
        r = e => {
            t.push(e)
        };
    return e.forEach(e => Jn(e, n, r)), Jn(null, n, r), t.join(``)
}

function nr(e) {
    return Math.round(Date.now() / 1e3) + e
}

function rr() {
    return Symbol(`auth-callback`)
}
var B = () => typeof window < `u` && typeof document < `u`,
    V = {
        tested: !1,
        writable: !1
    },
    ir = () => {
        if (!B()) return !1;
        try {
            if (typeof globalThis.localStorage != `object`) return !1
        } catch {
            return !1
        }
        if (V.tested) return V.writable;
        let e = `lswt-${Math.random()}${Math.random()}`;
        try {
            globalThis.localStorage.setItem(e, e), globalThis.localStorage.removeItem(e), V.tested = !0, V.writable = !0
        } catch {
            V.tested = !0, V.writable = !1
        }
        return V.writable
    };

function ar(e) {
    let t = {},
        n = new URL(e);
    if (n.hash && n.hash[0] === `#`) try {
        new URLSearchParams(n.hash.substring(1)).forEach((e, n) => {
            t[n] = e
        })
    } catch {}
    return n.searchParams.forEach((e, n) => {
        t[n] = e
    }), t
}
var or = e => e ? (...t) => e(...t) : (...e) => fetch(...e),
    sr = e => typeof e == `object` && !!e && `status` in e && `ok` in e && `json` in e && typeof e.json == `function`,
    H = async (e, t, n) => {
        await e.setItem(t, JSON.stringify(n))
    },
    U = async (e, t) => {
        let n = await e.getItem(t);
        if (!n) return null;
        try {
            return JSON.parse(n)
        } catch {
            return null
        }
    },
    W = async (e, t) => {
        await e.removeItem(t)
    },
    cr = class e {
        constructor() {
            this.promise = new e.promiseConstructor((e, t) => {
                this.resolve = e, this.reject = t
            })
        }
    };
cr.promiseConstructor = Promise;

function lr(e) {
    let t = e.split(`.`);
    if (t.length !== 3) throw new Wn(`Invalid JWT structure`);
    for (let e = 0; e < t.length; e++)
        if (!Dn.test(t[e])) throw new Wn(`JWT not in base64url format`);
    return {
        header: JSON.parse(Xn(t[0])),
        payload: JSON.parse(Xn(t[1])),
        signature: er(t[2]),
        raw: {
            header: t[0],
            payload: t[1]
        }
    }
}
async function ur(e) {
    return await new Promise(t => {
        setTimeout(() => t(null), e)
    })
}

function dr(e, t) {
    return new Promise((n, r) => {
        (async () => {
            for (let i = 0; i < 1 / 0; i++) try {
                let r = await e(i);
                if (!t(i, null, r)) {
                    n(r);
                    return
                }
            } catch (e) {
                if (!t(i, e)) {
                    r(e);
                    return
                }
            }
        })()
    })
}

function fr(e) {
    return (`0` + e.toString(16)).substr(-2)
}

function pr() {
    let e = new Uint32Array(56);
    if (typeof crypto > `u`) {
        let e = ``;
        for (let t = 0; t < 56; t++) e += `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~`.charAt(Math.floor(Math.random() * 66));
        return e
    }
    return crypto.getRandomValues(e), Array.from(e, fr).join(``)
}
async function mr(e) {
    let t = new TextEncoder().encode(e),
        n = await crypto.subtle.digest(`SHA-256`, t),
        r = new Uint8Array(n);
    return Array.from(r).map(e => String.fromCharCode(e)).join(``)
}
async function hr(e) {
    if (!(typeof crypto < `u` && crypto.subtle !== void 0 && typeof TextEncoder < `u`)) return console.warn(`WebCrypto API is not supported. Code challenge method will default to use plain instead of sha256.`), e;
    let t = await mr(e);
    return btoa(t).replace(/\+/g, `-`).replace(/\//g, `_`).replace(/=+$/, ``)
}
var gr = /^[a-zA-Z0-9_-]{8,64}$/;

function _r(e) {
    return typeof e == `string` && gr.test(e) ? e : null
}

function vr() {
    if (typeof crypto < `u` && typeof crypto.getRandomValues == `function`) {
        let e = new Uint8Array(16);
        return crypto.getRandomValues(e), Array.from(e, fr).join(``)
    }
    let e = ``;
    for (let t = 0; t < 32; t++) e += Math.floor(Math.random() * 16).toString(16);
    return e
}
var yr = (e, t) => `${e}-flow-${t}-code-verifier`,
    br = e => `${e}-flows-code-verifier`;
async function xr(e, t) {
    let n = await U(e, br(t));
    return Array.isArray(n) ? n.filter(e => _r(e) !== null) : []
}
async function Sr(e, t, n, r, i) {
    await H(e, yr(t, n), r);
    let a = (await xr(e, t)).filter(e => e !== n);
    for (a.push(n); a.length > 5;) {
        let n = a.shift();
        await W(e, yr(t, n)), i ?.(n)
    }
    await H(e, br(t), a), await H(e, `${t}-code-verifier`, r)
}
async function Cr(e, t, n) {
    if (n) {
        let r = await U(e, yr(t, n));
        return {
            verifier: typeof r == `string` ? r : null,
            flowId: n
        }
    }
    let r = await U(e, `${t}-code-verifier`);
    return {
        verifier: typeof r == `string` ? r : null,
        flowId: null
    }
}
async function G(e, t, n) {
    let r = `${t}-code-verifier`;
    if (!n) {
        await W(e, r);
        return
    }
    let i = yr(t, n),
        a = await U(e, i);
    await W(e, i);
    let o = await xr(e, t),
        s = o.filter(e => e !== n);
    s.length !== o.length && (s.length > 0 ? await H(e, br(t), s) : await W(e, br(t))), a != null && a === await U(e, r) && await W(e, r)
}
async function wr(e, t) {
    let n = await xr(e, t);
    for (let r of n) await W(e, yr(t, r));
    await W(e, br(t)), await W(e, `${t}-code-verifier`)
}

function Tr(e, t) {
    let n = e.indexOf(`#`),
        r = n === -1 ? e : e.slice(0, n),
        i = n === -1 ? `` : e.slice(n),
        a = r.indexOf(`?`);
    if (a !== -1) {
        let e = r.slice(0, a),
            t = r.slice(a + 1).split(`&`).filter(e => e !== `` && e !== `sb_flow_id` && !e.startsWith(`sb_flow_id=`));
        r = t.length > 0 ? `${e}?${t.join(`&`)}` : e
    }
    let o = r.includes(`?`) ? `&` : `?`;
    return `${r}${o}${On}=${encodeURIComponent(t)}${i}`
}
async function Er(e, t, n = !1, r) {
    let i = pr(),
        a = i;
    n && (a += `/recovery`);
    let o = vr();
    await Sr(e, t, o, a, r);
    let s = await hr(i);
    return [s, i === s ? `plain` : `s256`, o]
}
var Dr = /^2[0-9]{3}-(0[1-9]|1[0-2])-(0[1-9]|1[0-9]|2[0-9]|3[0-1])$/i;

function Or(e) {
    let t = e.headers.get(Tn);
    if (!t || !t.match(Dr)) return null;
    try {
        return new Date(`${t}T00:00:00.0Z`)
    } catch {
        return null
    }
}

function kr(e) {
    if (!e) throw Error(`Missing exp claim`);
    if (e <= Math.floor(Date.now() / 1e3)) throw Error(`JWT has expired`)
}

function Ar(e) {
    switch (e) {
        case `RS256`:
            return {
                name: `RSASSA-PKCS1-v1_5`,
                hash: {
                    name: `SHA-256`
                }
            };
        case `ES256`:
            return {
                name: `ECDSA`,
                namedCurve: `P-256`,
                hash: {
                    name: `SHA-256`
                }
            };
        default:
            throw Error(`Invalid alg claim`)
    }
}
var jr = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function K(e) {
    if (!jr.test(e)) throw Error(`@supabase/auth-js: Expected parameter to be UUID but is not`)
}

function q(e) {
    if (!e.passkey) throw Error("@supabase/auth-js: the passkey API is experimental and disabled by default. Enable it by passing `auth: { experimental: { passkey: true } }` to createClient (or to the GoTrueClient constructor).")
}

function Mr() {
    return new Proxy({}, {
        get: (e, t) => {
            if (t === `__isUserNotAvailableProxy`) return !0;
            if (typeof t == `symbol`) {
                let e = t.toString();
                if (e === `Symbol(Symbol.toPrimitive)` || e === `Symbol(Symbol.toStringTag)` || e === `Symbol(util.inspect.custom)`) return
            }
            throw Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Accessing the "${t}" property of the session object is not supported. Please use getUser() instead.`)
        },
        set: (e, t) => {
            throw Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Setting the "${t}" property of the session object is not supported. Please use getUser() to fetch a user object you can manipulate.`)
        },
        deleteProperty: (e, t) => {
            throw Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Deleting the "${t}" property of the session object is not supported. Please use getUser() to fetch a user object you can manipulate.`)
        }
    })
}

function Nr(e, t) {
    return new Proxy(e, {
        get: (e, n, r) => {
            if (n === `__isInsecureUserWarningProxy`) return !0;
            if (typeof n == `symbol`) {
                let t = n.toString();
                if (t === `Symbol(Symbol.toPrimitive)` || t === `Symbol(Symbol.toStringTag)` || t === `Symbol(util.inspect.custom)` || t === `Symbol(nodejs.util.inspect.custom)`) return Reflect.get(e, n, r)
            }
            return !t.value && typeof n == `string` && (console.warn(`Using the user object as returned from supabase.auth.getSession() or from some supabase.auth.onAuthStateChange() events could be insecure! This value comes directly from the storage medium (usually cookies on the server) and may not be authentic. Use supabase.auth.getUser() instead which authenticates the data by contacting the Supabase Auth server.`), t.value = !0), Reflect.get(e, n, r)
        }
    })
}

function Pr(e) {
    return JSON.parse(JSON.stringify(e))
}
var J = e => {
        if (typeof e == `object` && e) {
            let t = e;
            if (typeof t.msg == `string`) return t.msg;
            if (typeof t.message == `string`) return t.message;
            if (typeof t.error_description == `string`) return t.error_description;
            if (typeof t.error == `string`) return t.error
        }
        return JSON.stringify(e)
    },
    Fr = [500, 501, 502, 503, 504, 520, 521, 522, 523, 524, 525, 526, 527, 528, 529, 530];
async function Ir(e) {
    if (!sr(e)) throw new zn(J(e), 0);
    let t;
    try {
        t = await e.json()
    } catch (t) {
        throw Fr.includes(e.status) ? new zn(e.statusText || `HTTP ${e.status}`, e.status) : new I(J(t), t)
    }
    if (Fr.includes(e.status)) throw new zn(J(t), e.status);
    let n, r = Or(e);
    if (r && r.getTime() >= En[`2024-01-01`].timestamp && typeof t == `object` && t && typeof t.code == `string` ? n = t.code : typeof t == `object` && t && typeof t.error_code == `string` && (n = t.error_code), !n) {
        if (typeof t == `object` && t && typeof t.weak_password == `object` && t.weak_password && Array.isArray(t.weak_password.reasons) && t.weak_password.reasons.length && t.weak_password.reasons.reduce((e, t) => e && typeof t == `string`, !0)) throw new Un(J(t), e.status, t.weak_password.reasons)
    } else if (n === `weak_password`) throw new Un(J(t), e.status, t.weak_password ?.reasons || []);
    else if (n === `session_not_found`) throw new R;
    throw new An(J(t), e.status || 500, n)
}
var Lr = (e, t, n, r) => {
    let i = {
        method: e,
        headers: t ?.headers || {}
    };
    return e === `GET` ? i : (i.headers = Object.assign({
        "Content-Type": `application/json;charset=UTF-8`
    }, t ?.headers), i.body = JSON.stringify(r), Object.assign(Object.assign({}, i), n))
};
async function Y(e, t, n, r) {
    let i = Object.assign({}, r ?.headers);
    i[`X-Supabase-Api-Version`] || (i[Tn] = En[`2024-01-01`].name), r ?.jwt && (i.Authorization = `Bearer ${r.jwt}`);
    let a = r ?.query ?? {};
    r ?.redirectTo && (a.redirect_to = r.redirectTo);
    let o = await Rr(e, t, n + (Object.keys(a).length ? `?` + new URLSearchParams(a).toString() : ``), {
        headers: i,
        noResolveJson: r ?.noResolveJson
    }, {}, r ?.body);
    return r ?.xform ? r ?.xform(o) : {
        data: Object.assign({}, o),
        error: null
    }
}
async function Rr(e, t, n, r, i, a) {
    let o = Lr(t, r, i, a),
        s;
    try {
        s = await e(n, Object.assign({}, o))
    } catch (e) {
        throw new zn(J(e), 0)
    }
    if (s.ok || await Ir(s), r ?.noResolveJson) return s;
    try {
        return await s.json()
    } catch (e) {
        await Ir(e)
    }
}

function X(e) {
    let t = null;
    Ur(e) && (t = Object.assign({}, e), e.expires_at || (t.expires_at = nr(e.expires_in)));
    let n = e.user ?? (typeof e ?.id == `string` ? e : null);
    return {
        data: {
            session: t,
            user: n
        },
        error: null
    }
}

function zr(e) {
    let t = X(e);
    return !t.error && e.weak_password && typeof e.weak_password == `object` && Array.isArray(e.weak_password.reasons) && e.weak_password.reasons.length && e.weak_password.message && typeof e.weak_password.message == `string` && e.weak_password.reasons.reduce((e, t) => e && typeof t == `string`, !0) && (t.data.weak_password = e.weak_password), t
}

function Z(e) {
    return {
        data: {
            user: e.user ?? e
        },
        error: null
    }
}

function Br(e) {
    return {
        data: e,
        error: null
    }
}

function Vr(e) {
    let {
        action_link: t,
        email_otp: n,
        hashed_token: i,
        redirect_to: a,
        verification_type: o
    } = e, s = r(e, [`action_link`, `email_otp`, `hashed_token`, `redirect_to`, `verification_type`]);
    return {
        data: {
            properties: {
                action_link: t,
                email_otp: n,
                hashed_token: i,
                redirect_to: a,
                verification_type: o
            },
            user: Object.assign({}, s)
        },
        error: null
    }
}

function Hr(e) {
    return e
}

function Ur(e) {
    return !!e.access_token && !!e.refresh_token && !!e.expires_in
}
var Wr = [`global`, `local`, `others`],
    Gr = class {
        constructor({
            url: e = ``,
            headers: t = {},
            fetch: n,
            experimental: r
        }) {
            this.url = e, this.headers = t, this.fetch = or(n), this.experimental = r ?? {}, this.mfa = {
                listFactors: this._listFactors.bind(this),
                deleteFactor: this._deleteFactor.bind(this)
            }, this.oauth = {
                listClients: this._listOAuthClients.bind(this),
                createClient: this._createOAuthClient.bind(this),
                getClient: this._getOAuthClient.bind(this),
                updateClient: this._updateOAuthClient.bind(this),
                deleteClient: this._deleteOAuthClient.bind(this),
                regenerateClientSecret: this._regenerateOAuthClientSecret.bind(this)
            }, this.customProviders = {
                listProviders: this._listCustomProviders.bind(this),
                createProvider: this._createCustomProvider.bind(this),
                getProvider: this._getCustomProvider.bind(this),
                updateProvider: this._updateCustomProvider.bind(this),
                deleteProvider: this._deleteCustomProvider.bind(this)
            }, this.passkey = {
                listPasskeys: this._adminListPasskeys.bind(this),
                deletePasskey: this._adminDeletePasskey.bind(this)
            }
        }
        async signOut(e, t = Wr[0]) {
            if (Wr.indexOf(t) < 0) throw Error(`@supabase/auth-js: Parameter scope must be one of ${Wr.join(`, `)}`);
            try {
                return await Y(this.fetch, `POST`, `${this.url}/logout?scope=${t}`, {
                    headers: this.headers,
                    jwt: e,
                    noResolveJson: !0
                }), {
                    data: null,
                    error: null
                }
            } catch (e) {
                if (F(e)) return {
                    data: null,
                    error: e
                };
                throw e
            }
        }
        async inviteUserByEmail(e, t = {}) {
            try {
                return await Y(this.fetch, `POST`, `${this.url}/invite`, {
                    body: {
                        email: e,
                        data: t.data
                    },
                    headers: this.headers,
                    redirectTo: t.redirectTo,
                    xform: Z
                })
            } catch (e) {
                if (F(e)) return {
                    data: {
                        user: null
                    },
                    error: e
                };
                throw e
            }
        }
        async generateLink(e) {
            try {
                let {
                    options: t
                } = e, n = r(e, [`options`]), i = Object.assign(Object.assign({}, n), t);
                return `newEmail` in n && (i.new_email = n ?.newEmail, delete i.newEmail), await Y(this.fetch, `POST`, `${this.url}/admin/generate_link`, {
                    body: i,
                    headers: this.headers,
                    xform: Vr,
                    redirectTo: t ?.redirectTo
                })
            } catch (e) {
                if (F(e)) return {
                    data: {
                        properties: null,
                        user: null
                    },
                    error: e
                };
                throw e
            }
        }
        async createUser(e) {
            try {
                return await Y(this.fetch, `POST`, `${this.url}/admin/users`, {
                    body: e,
                    headers: this.headers,
                    xform: Z
                })
            } catch (e) {
                if (F(e)) return {
                    data: {
                        user: null
                    },
                    error: e
                };
                throw e
            }
        }
        async listUsers(e) {
            try {
                let t = {
                        nextPage: null,
                        lastPage: 0,
                        total: 0
                    },
                    n = await Y(this.fetch, `GET`, `${this.url}/admin/users`, {
                        headers: this.headers,
                        noResolveJson: !0,
                        query: {
                            page: (e ?.page) ?.toString() ?? ``,
                            per_page: (e ?.perPage) ?.toString() ?? ``
                        },
                        xform: Hr
                    });
                if (n.error) throw n.error;
                let r = await n.json(),
                    i = n.headers.get(`x-total-count`) ?? 0,
                    a = n.headers.get(`link`) ?.split(`,`) ?? [];
                return a.length > 0 && (a.forEach(e => {
                    let n = parseInt(e.split(`;`)[0].split(`=`)[1].substring(0, 1)),
                        r = JSON.parse(e.split(`;`)[1].split(`=`)[1]);
                    t[`${r}Page`] = n
                }), t.total = parseInt(i)), {
                    data: Object.assign(Object.assign({}, r), t),
                    error: null
                }
            } catch (e) {
                if (F(e)) return {
                    data: {
                        users: []
                    },
                    error: e
                };
                throw e
            }
        }
        async getUserById(e) {
            K(e);
            try {
                return await Y(this.fetch, `GET`, `${this.url}/admin/users/${e}`, {
                    headers: this.headers,
                    xform: Z
                })
            } catch (e) {
                if (F(e)) return {
                    data: {
                        user: null
                    },
                    error: e
                };
                throw e
            }
        }
        async updateUserById(e, t) {
            K(e);
            try {
                return await Y(this.fetch, `PUT`, `${this.url}/admin/users/${e}`, {
                    body: t,
                    headers: this.headers,
                    xform: Z
                })
            } catch (e) {
                if (F(e)) return {
                    data: {
                        user: null
                    },
                    error: e
                };
                throw e
            }
        }
        async deleteUser(e, t = !1) {
            K(e);
            try {
                return await Y(this.fetch, `DELETE`, `${this.url}/admin/users/${e}`, {
                    headers: this.headers,
                    body: {
                        should_soft_delete: t
                    },
                    xform: Z
                })
            } catch (e) {
                if (F(e)) return {
                    data: {
                        user: null
                    },
                    error: e
                };
                throw e
            }
        }
        async _listFactors(e) {
            K(e.userId);
            try {
                let {
                    data: t,
                    error: n
                } = await Y(this.fetch, `GET`, `${this.url}/admin/users/${e.userId}/factors`, {
                    headers: this.headers,
                    xform: e => ({
                        data: {
                            factors: e
                        },
                        error: null
                    })
                });
                return {
                    data: t,
                    error: n
                }
            } catch (e) {
                if (F(e)) return {
                    data: null,
                    error: e
                };
                throw e
            }
        }
        async _deleteFactor(e) {
            K(e.userId), K(e.id);
            try {
                return {
                    data: await Y(this.fetch, `DELETE`, `${this.url}/admin/users/${e.userId}/factors/${e.id}`, {
                        headers: this.headers
                    }),
                    error: null
                }
            } catch (e) {
                if (F(e)) return {
                    data: null,
                    error: e
                };
                throw e
            }
        }
        async _listOAuthClients(e) {
            try {
                let t = {
                        nextPage: null,
                        lastPage: 0,
                        total: 0
                    },
                    n = await Y(this.fetch, `GET`, `${this.url}/admin/oauth/clients`, {
                        headers: this.headers,
                        noResolveJson: !0,
                        query: {
                            page: (e ?.page) ?.toString() ?? ``,
                            per_page: (e ?.perPage) ?.toString() ?? ``
                        },
                        xform: Hr
                    });
                if (n.error) throw n.error;
                let r = await n.json(),
                    i = n.headers.get(`x-total-count`) ?? 0,
                    a = n.headers.get(`link`) ?.split(`,`) ?? [];
                return a.length > 0 && (a.forEach(e => {
                    let n = parseInt(e.split(`;`)[0].split(`=`)[1].substring(0, 1)),
                        r = JSON.parse(e.split(`;`)[1].split(`=`)[1]);
                    t[`${r}Page`] = n
                }), t.total = parseInt(i)), {
                    data: Object.assign(Object.assign({}, r), t),
                    error: null
                }
            } catch (e) {
                if (F(e)) return {
                    data: {
                        clients: []
                    },
                    error: e
                };
                throw e
            }
        }
        async _createOAuthClient(e) {
            try {
                return await Y(this.fetch, `POST`, `${this.url}/admin/oauth/clients`, {
                    body: e,
                    headers: this.headers,
                    xform: e => ({
                        data: e,
                        error: null
                    })
                })
            } catch (e) {
                if (F(e)) return {
                    data: null,
                    error: e
                };
                throw e
            }
        }
        async _getOAuthClient(e) {
            try {
                return await Y(this.fetch, `GET`, `${this.url}/admin/oauth/clients/${e}`, {
                    headers: this.headers,
                    xform: e => ({
                        data: e,
                        error: null
                    })
                })
            } catch (e) {
                if (F(e)) return {
                    data: null,
                    error: e
                };
                throw e
            }
        }
        async _updateOAuthClient(e, t) {
            try {
                return await Y(this.fetch, `PUT`, `${this.url}/admin/oauth/clients/${e}`, {
                    body: t,
                    headers: this.headers,
                    xform: e => ({
                        data: e,
                        error: null
                    })
                })
            } catch (e) {
                if (F(e)) return {
                    data: null,
                    error: e
                };
                throw e
            }
        }
        async _deleteOAuthClient(e) {
            try {
                return await Y(this.fetch, `DELETE`, `${this.url}/admin/oauth/clients/${e}`, {
                    headers: this.headers,
                    noResolveJson: !0
                }), {
                    data: null,
                    error: null
                }
            } catch (e) {
                if (F(e)) return {
                    data: null,
                    error: e
                };
                throw e
            }
        }
        async _regenerateOAuthClientSecret(e) {
            try {
                return await Y(this.fetch, `POST`, `${this.url}/admin/oauth/clients/${e}/regenerate_secret`, {
                    headers: this.headers,
                    xform: e => ({
                        data: e,
                        error: null
                    })
                })
            } catch (e) {
                if (F(e)) return {
                    data: null,
                    error: e
                };
                throw e
            }
        }
        async _listCustomProviders(e) {
            try {
                let t = {};
                return e ?.type && (t.type = e.type), await Y(this.fetch, `GET`, `${this.url}/admin/custom-providers`, {
                    headers: this.headers,
                    query: t,
                    xform: e => ({
                        data: {
                            providers: e ?.providers ?? []
                        },
                        error: null
                    })
                })
            } catch (e) {
                if (F(e)) return {
                    data: {
                        providers: []
                    },
                    error: e
                };
                throw e
            }
        }
        async _createCustomProvider(e) {
            try {
                return await Y(this.fetch, `POST`, `${this.url}/admin/custom-providers`, {
                    body: e,
                    headers: this.headers,
                    xform: e => ({
                        data: e,
                        error: null
                    })
                })
            } catch (e) {
                if (F(e)) return {
                    data: null,
                    error: e
                };
                throw e
            }
        }
        async _getCustomProvider(e) {
            try {
                return await Y(this.fetch, `GET`, `${this.url}/admin/custom-providers/${e}`, {
                    headers: this.headers,
                    xform: e => ({
                        data: e,
                        error: null
                    })
                })
            } catch (e) {
                if (F(e)) return {
                    data: null,
                    error: e
                };
                throw e
            }
        }
        async _updateCustomProvider(e, t) {
            try {
                return await Y(this.fetch, `PUT`, `${this.url}/admin/custom-providers/${e}`, {
                    body: t,
                    headers: this.headers,
                    xform: e => ({
                        data: e,
                        error: null
                    })
                })
            } catch (e) {
                if (F(e)) return {
                    data: null,
                    error: e
                };
                throw e
            }
        }
        async _deleteCustomProvider(e) {
            try {
                return await Y(this.fetch, `DELETE`, `${this.url}/admin/custom-providers/${e}`, {
                    headers: this.headers,
                    noResolveJson: !0
                }), {
                    data: null,
                    error: null
                }
            } catch (e) {
                if (F(e)) return {
                    data: null,
                    error: e
                };
                throw e
            }
        }
        async _adminListPasskeys(e) {
            q(this.experimental), K(e.userId);
            try {
                return await Y(this.fetch, `GET`, `${this.url}/admin/users/${e.userId}/passkeys`, {
                    headers: this.headers,
                    xform: e => ({
                        data: e,
                        error: null
                    })
                })
            } catch (e) {
                if (F(e)) return {
                    data: null,
                    error: e
                };
                throw e
            }
        }
        async _adminDeletePasskey(e) {
            q(this.experimental), K(e.userId), K(e.passkeyId);
            try {
                return await Y(this.fetch, `DELETE`, `${this.url}/admin/users/${e.userId}/passkeys/${e.passkeyId}`, {
                    headers: this.headers,
                    noResolveJson: !0
                }), {
                    data: null,
                    error: null
                }
            } catch (e) {
                if (F(e)) return {
                    data: null,
                    error: e
                };
                throw e
            }
        }
    };

function Kr(e = {}) {
    return {
        getItem: t => e[t] || null,
        setItem: (t, n) => {
            e[t] = n
        },
        removeItem: t => {
            delete e[t]
        }
    }
}
globalThis && ir() && globalThis.localStorage && globalThis.localStorage.getItem(`supabase.gotrue-js.locks.debug`);
var qr = class extends Error {
    constructor(e) {
        super(e), this.isAcquireTimeout = !0
    }
};

function Jr() {
    if (typeof globalThis != `object`) try {
        Object.defineProperty(Object.prototype, "__magic__", {
            get: function() {
                return this
            },
            configurable: !0
        }), __magic__.globalThis = __magic__, delete Object.prototype.__magic__
    } catch {
        typeof self < `u` && (self.globalThis = self)
    }
}

function Yr(e) {
    if (!/^0x[a-fA-F0-9]{40}$/.test(e)) throw Error(`@supabase/auth-js: Address "${e}" is invalid.`);
    return e.toLowerCase()
}

function Xr(e) {
    return parseInt(e, 16)
}

function Zr(e) {
    let t = new TextEncoder().encode(e);
    return `0x` + Array.from(t, e => e.toString(16).padStart(2, `0`)).join(``)
}

function Qr(e) {
    let {
        chainId: t,
        domain: n,
        expirationTime: r,
        issuedAt: i = new Date,
        nonce: a,
        notBefore: o,
        requestId: s,
        resources: c,
        scheme: l,
        uri: u,
        version: d
    } = e;
    if (!Number.isInteger(t)) throw Error(`@supabase/auth-js: Invalid SIWE message field "chainId". Chain ID must be a EIP-155 chain ID. Provided value: ${t}`);
    if (!n) throw Error(`@supabase/auth-js: Invalid SIWE message field "domain". Domain must be provided.`);
    if (a && a.length < 8) throw Error(`@supabase/auth-js: Invalid SIWE message field "nonce". Nonce must be at least 8 characters. Provided value: ${a}`);
    if (!u) throw Error(`@supabase/auth-js: Invalid SIWE message field "uri". URI must be provided.`);
    if (d !== `1`) throw Error(`@supabase/auth-js: Invalid SIWE message field "version". Version must be '1'. Provided value: ${d}`);
    if (e.statement ?.includes(`
`)) throw Error(`@supabase/auth-js: Invalid SIWE message field "statement". Statement must not include '\\n'. Provided value: ${e.statement}`);
    let f = Yr(e.address),
        p = `${l?`${l}://${n}`:n} wants you to sign in with your Ethereum account:\n${f}\n\n${e.statement?`${e.statement}\n`:``}`,
        m = `URI: ${u}\nVersion: ${d}\nChain ID: ${t}${a?`\nNonce: ${a}`:``}\nIssued At: ${i.toISOString()}`;
    if (r && (m += `\nExpiration Time: ${r.toISOString()}`), o && (m += `\nNot Before: ${o.toISOString()}`), s && (m += `\nRequest ID: ${s}`), c) {
        let e = `
Resources:`;
        for (let t of c) {
            if (!t || typeof t != `string`) throw Error(`@supabase/auth-js: Invalid SIWE message field "resources". Every resource must be a valid string. Provided value: ${t}`);
            e += `\n- ${t}`
        }
        m += e
    }
    return `${p}\n${m}`
}
var Q = class extends Error {
        constructor({
            message: e,
            code: t,
            cause: n,
            name: r
        }) {
            super(e, {
                cause: n
            }), this.__isWebAuthnError = !0, this.name = r ?? (n instanceof Error ? n.name : void 0) ?? `Unknown Error`, this.code = t
        }
        toJSON() {
            return {
                name: this.name,
                message: this.message,
                code: this.code
            }
        }
    },
    $r = class extends Q {
        constructor(e, t) {
            super({
                code: `ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY`,
                cause: t,
                message: e
            }), this.name = `WebAuthnUnknownError`, this.originalError = t
        }
    };

function ei({
    error: e,
    options: t
}) {
    let {
        publicKey: n
    } = t;
    if (!n) throw Error(`options was missing required publicKey property`);
    if (e.name === `AbortError`) {
        if (t.signal instanceof AbortSignal) return new Q({
            message: `Registration ceremony was sent an abort signal`,
            code: `ERROR_CEREMONY_ABORTED`,
            cause: e
        })
    } else if (e.name === `ConstraintError`) {
        if (n.authenticatorSelection ?.requireResidentKey === !0) return new Q({
            message: `Discoverable credentials were required but no available authenticator supported it`,
            code: `ERROR_AUTHENTICATOR_MISSING_DISCOVERABLE_CREDENTIAL_SUPPORT`,
            cause: e
        });
        if (t.mediation === `conditional` && n.authenticatorSelection ?.userVerification === `required`) return new Q({
            message: `User verification was required during automatic registration but it could not be performed`,
            code: `ERROR_AUTO_REGISTER_USER_VERIFICATION_FAILURE`,
            cause: e
        });
        if (n.authenticatorSelection ?.userVerification === `required`) return new Q({
            message: `User verification was required but no available authenticator supported it`,
            code: `ERROR_AUTHENTICATOR_MISSING_USER_VERIFICATION_SUPPORT`,
            cause: e
        })
    } else if (e.name === `InvalidStateError`) return new Q({
        message: `The authenticator was previously registered`,
        code: `ERROR_AUTHENTICATOR_PREVIOUSLY_REGISTERED`,
        cause: e
    });
    else if (e.name === `NotAllowedError`) return new Q({
        message: e.message,
        code: `ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY`,
        cause: e
    });
    else if (e.name === `NotSupportedError`) return n.pubKeyCredParams.filter(e => e.type === `public-key`).length === 0 ? new Q({
        message: `No entry in pubKeyCredParams was of type "public-key"`,
        code: `ERROR_MALFORMED_PUBKEYCREDPARAMS`,
        cause: e
    }) : new Q({
        message: `No available authenticator supported any of the specified pubKeyCredParams algorithms`,
        code: `ERROR_AUTHENTICATOR_NO_SUPPORTED_PUBKEYCREDPARAMS_ALG`,
        cause: e
    });
    else if (e.name === `SecurityError`) {
        let t = window.location.hostname;
        if (!si(t)) return new Q({
            message: `${window.location.hostname} is an invalid domain`,
            code: `ERROR_INVALID_DOMAIN`,
            cause: e
        });
        if (n.rp.id !== t) return new Q({
            message: `The RP ID "${n.rp.id}" is invalid for this domain`,
            code: `ERROR_INVALID_RP_ID`,
            cause: e
        })
    } else if (e.name === `TypeError`) {
        if (n.user.id.byteLength < 1 || n.user.id.byteLength > 64) return new Q({
            message: `User ID was not between 1 and 64 characters`,
            code: `ERROR_INVALID_USER_ID_LENGTH`,
            cause: e
        })
    } else if (e.name === `UnknownError`) return new Q({
        message: `The authenticator was unable to process the specified options, or could not create a new credential`,
        code: `ERROR_AUTHENTICATOR_GENERAL_ERROR`,
        cause: e
    });
    return new Q({
        message: `a Non-Webauthn related error has occurred`,
        code: `ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY`,
        cause: e
    })
}

function ti({
    error: e,
    options: t
}) {
    let {
        publicKey: n
    } = t;
    if (!n) throw Error(`options was missing required publicKey property`);
    if (e.name === `AbortError`) {
        if (t.signal instanceof AbortSignal) return new Q({
            message: `Authentication ceremony was sent an abort signal`,
            code: `ERROR_CEREMONY_ABORTED`,
            cause: e
        })
    } else if (e.name === `NotAllowedError`) return new Q({
        message: e.message,
        code: `ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY`,
        cause: e
    });
    else if (e.name === `SecurityError`) {
        let t = window.location.hostname;
        if (!si(t)) return new Q({
            message: `${window.location.hostname} is an invalid domain`,
            code: `ERROR_INVALID_DOMAIN`,
            cause: e
        });
        if (n.rpId !== t) return new Q({
            message: `The RP ID "${n.rpId}" is invalid for this domain`,
            code: `ERROR_INVALID_RP_ID`,
            cause: e
        })
    } else if (e.name === `UnknownError`) return new Q({
        message: `The authenticator was unable to process the specified options, or could not create a new assertion signature`,
        code: `ERROR_AUTHENTICATOR_GENERAL_ERROR`,
        cause: e
    });
    return new Q({
        message: `a Non-Webauthn related error has occurred`,
        code: `ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY`,
        cause: e
    })
}
var ni = new class {
    createNewAbortSignal() {
        if (this.controller) {
            let e = Error(`Cancelling existing WebAuthn API call for new one`);
            e.name = `AbortError`, this.controller.abort(e)
        }
        let e = new AbortController;
        return this.controller = e, e.signal
    }
    cancelCeremony() {
        if (this.controller) {
            let e = Error(`Manually cancelling existing WebAuthn API call`);
            e.name = `AbortError`, this.controller.abort(e), this.controller = void 0
        }
    }
};

function ri(e) {
    if (!e) throw Error(`Credential creation options are required`);
    if (typeof PublicKeyCredential < `u` && `parseCreationOptionsFromJSON` in PublicKeyCredential && typeof PublicKeyCredential.parseCreationOptionsFromJSON == `function`) return PublicKeyCredential.parseCreationOptionsFromJSON(e);
    let {
        challenge: t,
        user: n,
        excludeCredentials: i
    } = e, a = r(e, [`challenge`, `user`, `excludeCredentials`]), o = er(t).buffer, s = Object.assign(Object.assign({}, n), {
        id: er(n.id).buffer
    }), c = Object.assign(Object.assign({}, a), {
        challenge: o,
        user: s
    });
    if (i && i.length > 0) {
        c.excludeCredentials = Array(i.length);
        for (let e = 0; e < i.length; e++) {
            let t = i[e];
            c.excludeCredentials[e] = Object.assign(Object.assign({}, t), {
                id: er(t.id).buffer,
                type: t.type || `public-key`,
                transports: t.transports
            })
        }
    }
    return c
}

function ii(e) {
    if (!e) throw Error(`Credential request options are required`);
    if (typeof PublicKeyCredential < `u` && `parseRequestOptionsFromJSON` in PublicKeyCredential && typeof PublicKeyCredential.parseRequestOptionsFromJSON == `function`) return PublicKeyCredential.parseRequestOptionsFromJSON(e);
    let {
        challenge: t,
        allowCredentials: n
    } = e, i = r(e, [`challenge`, `allowCredentials`]), a = er(t).buffer, o = Object.assign(Object.assign({}, i), {
        challenge: a
    });
    if (n && n.length > 0) {
        o.allowCredentials = Array(n.length);
        for (let e = 0; e < n.length; e++) {
            let t = n[e];
            o.allowCredentials[e] = Object.assign(Object.assign({}, t), {
                id: er(t.id).buffer,
                type: t.type || `public-key`,
                transports: t.transports
            })
        }
    }
    return o
}

function ai(e) {
    if (`toJSON` in e && typeof e.toJSON == `function`) return e.toJSON();
    let t = e;
    return {
        id: e.id,
        rawId: e.id,
        response: {
            attestationObject: z(new Uint8Array(e.response.attestationObject)),
            clientDataJSON: z(new Uint8Array(e.response.clientDataJSON))
        },
        type: `public-key`,
        clientExtensionResults: e.getClientExtensionResults(),
        authenticatorAttachment: t.authenticatorAttachment ?? void 0
    }
}

function oi(e) {
    if (`toJSON` in e && typeof e.toJSON == `function`) return e.toJSON();
    let t = e,
        n = e.getClientExtensionResults(),
        r = e.response;
    return {
        id: e.id,
        rawId: e.id,
        response: {
            authenticatorData: z(new Uint8Array(r.authenticatorData)),
            clientDataJSON: z(new Uint8Array(r.clientDataJSON)),
            signature: z(new Uint8Array(r.signature)),
            userHandle: r.userHandle ? z(new Uint8Array(r.userHandle)) : void 0
        },
        type: `public-key`,
        clientExtensionResults: n,
        authenticatorAttachment: t.authenticatorAttachment ?? void 0
    }
}

function si(e) {
    return e === `localhost` || /^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i.test(e)
}

function ci() {
    return !!(B() && `PublicKeyCredential` in window && window.PublicKeyCredential && `credentials` in navigator && typeof(navigator == null ? void 0 : navigator.credentials) ?.create == `function` && typeof(navigator == null ? void 0 : navigator.credentials) ?.get == `function`)
}
async function li(e) {
    try {
        let t = await navigator.credentials.create(e);
        return t ? t instanceof PublicKeyCredential ? {
            data: t,
            error: null
        } : {
            data: null,
            error: new $r(`Browser returned unexpected credential type`, t)
        } : {
            data: null,
            error: new $r(`Empty credential response`, t)
        }
    } catch (t) {
        return {
            data: null,
            error: ei({
                error: t,
                options: e
            })
        }
    }
}
async function ui(e) {
    try {
        let t = await navigator.credentials.get(e);
        return t ? t instanceof PublicKeyCredential ? {
            data: t,
            error: null
        } : {
            data: null,
            error: new $r(`Browser returned unexpected credential type`, t)
        } : {
            data: null,
            error: new $r(`Empty credential response`, t)
        }
    } catch (t) {
        return {
            data: null,
            error: ti({
                error: t,
                options: e
            })
        }
    }
}
var di = {
        hints: [`security-key`],
        authenticatorSelection: {
            authenticatorAttachment: `cross-platform`,
            requireResidentKey: !1,
            userVerification: `preferred`,
            residentKey: `discouraged`
        },
        attestation: `direct`
    },
    fi = {
        userVerification: `preferred`,
        hints: [`security-key`],
        attestation: `direct`
    };

function pi(...e) {
    let t = e => typeof e == `object` && !!e && !Array.isArray(e),
        n = e => e instanceof ArrayBuffer || ArrayBuffer.isView(e),
        r = {};
    for (let i of e)
        if (i)
            for (let e in i) {
                let a = i[e];
                if (a !== void 0) {
                    if (Array.isArray(a)) r[e] = a;
                    else if (n(a)) r[e] = a;
                    else if (t(a)) {
                        let n = r[e];
                        r[e] = t(n) ? pi(n, a) : pi(a)
                    } else r[e] = a
                }
            }
    return r
}

function mi(e, t) {
    return pi(di, e, t || {})
}

function hi(e, t) {
    return pi(fi, e, t || {})
}
var gi = class {
    constructor(e) {
        this.client = e, this.enroll = this._enroll.bind(this), this.challenge = this._challenge.bind(this), this.verify = this._verify.bind(this), this.authenticate = this._authenticate.bind(this), this.register = this._register.bind(this)
    }
    async _enroll(e) {
        return this.client.mfa.enroll(Object.assign(Object.assign({}, e), {
            factorType: `webauthn`
        }))
    }
    async _challenge({
        factorId: e,
        webauthn: t,
        friendlyName: n,
        signal: r
    }, i) {
        try {
            let {
                data: a,
                error: o
            } = await this.client.mfa.challenge({
                factorId: e,
                webauthn: t
            });
            if (!a) return {
                data: null,
                error: o
            };
            let s = r ?? ni.createNewAbortSignal();
            if (a.webauthn.type === `create`) {
                let {
                    user: e
                } = a.webauthn.credential_options.publicKey;
                if (!e.name) {
                    let t = n;
                    if (t) e.name = `${e.id}:${t}`;
                    else {
                        let t = (await this.client.getUser()).data.user,
                            n = t ?.user_metadata ?.name || t ?.email || t ?.id || `User`;
                        e.name = `${e.id}:${n}`
                    }
                }
                e.displayName ||= e.name
            }
            switch (a.webauthn.type) {
                case `create`:
                    {
                        let {
                            data: t,
                            error: n
                        } = await li({
                            publicKey: mi(a.webauthn.credential_options.publicKey, i ?.create),
                            signal: s
                        });
                        return t ? {
                            data: {
                                factorId: e,
                                challengeId: a.id,
                                webauthn: {
                                    type: a.webauthn.type,
                                    credential_response: t
                                }
                            },
                            error: null
                        } : {
                            data: null,
                            error: n
                        }
                    }
                case `request`:
                    {
                        let t = hi(a.webauthn.credential_options.publicKey, i ?.request),
                            {
                                data: n,
                                error: r
                            } = await ui(Object.assign(Object.assign({}, a.webauthn.credential_options), {
                                publicKey: t,
                                signal: s
                            }));
                        return n ? {
                            data: {
                                factorId: e,
                                challengeId: a.id,
                                webauthn: {
                                    type: a.webauthn.type,
                                    credential_response: n
                                }
                            },
                            error: null
                        } : {
                            data: null,
                            error: r
                        }
                    }
            }
        } catch (e) {
            return F(e) ? {
                data: null,
                error: e
            } : {
                data: null,
                error: new I(`Unexpected error in challenge`, e)
            }
        }
    }
    async _verify({
        challengeId: e,
        factorId: t,
        webauthn: n
    }) {
        return this.client.mfa.verify({
            factorId: t,
            challengeId: e,
            webauthn: n
        })
    }
    async _authenticate({
        factorId: e,
        webauthn: {
            rpId: t = typeof window < `u` ? window.location.hostname : void 0,
            rpOrigins: n = typeof window < `u` ? [window.location.origin] : void 0,
            signal: r
        } = {}
    }, i) {
        if (!t) return {
            data: null,
            error: new kn(`rpId is required for WebAuthn authentication`)
        };
        try {
            if (!ci()) return {
                data: null,
                error: new I(`Browser does not support WebAuthn`, null)
            };
            let {
                data: a,
                error: o
            } = await this.challenge({
                factorId: e,
                webauthn: {
                    rpId: t,
                    rpOrigins: n
                },
                signal: r
            }, {
                request: i
            });
            if (!a) return {
                data: null,
                error: o
            };
            let {
                webauthn: s
            } = a;
            return this._verify({
                factorId: e,
                challengeId: a.challengeId,
                webauthn: {
                    type: s.type,
                    rpId: t,
                    rpOrigins: n,
                    credential_response: s.credential_response
                }
            })
        } catch (e) {
            return F(e) ? {
                data: null,
                error: e
            } : {
                data: null,
                error: new I(`Unexpected error in authenticate`, e)
            }
        }
    }
    async _register({
        friendlyName: e,
        webauthn: {
            rpId: t = typeof window < `u` ? window.location.hostname : void 0,
            rpOrigins: n = typeof window < `u` ? [window.location.origin] : void 0,
            signal: r
        } = {}
    }, i) {
        if (!t) return {
            data: null,
            error: new kn(`rpId is required for WebAuthn registration`)
        };
        try {
            if (!ci()) return {
                data: null,
                error: new I(`Browser does not support WebAuthn`, null)
            };
            let {
                data: a,
                error: o
            } = await this._enroll({
                friendlyName: e
            });
            if (!a) return await this.client.mfa.listFactors().then(t => t.data ?.all.find(t => t.factor_type === `webauthn` && t.friendly_name === e && t.status !== `unverified`)).then(e => e ? this.client.mfa.unenroll({
                factorId: e ?.id
            }) : void 0), {
                data: null,
                error: o
            };
            let {
                data: s,
                error: c
            } = await this._challenge({
                factorId: a.id,
                friendlyName: a.friendly_name,
                webauthn: {
                    rpId: t,
                    rpOrigins: n
                },
                signal: r
            }, {
                create: i
            });
            return s ? this._verify({
                factorId: a.id,
                challengeId: s.challengeId,
                webauthn: {
                    rpId: t,
                    rpOrigins: n,
                    type: s.webauthn.type,
                    credential_response: s.webauthn.credential_response
                }
            }) : {
                data: null,
                error: c
            }
        } catch (e) {
            return F(e) ? {
                data: null,
                error: e
            } : {
                data: null,
                error: new I(`Unexpected error in register`, e)
            }
        }
    }
};
Jr();
var _i = {
        url: Sn,
        storageKey: Cn,
        autoRefreshToken: !0,
        persistSession: !0,
        detectSessionInUrl: !0,
        headers: wn,
        flowType: `implicit`,
        debug: !1,
        hasCustomAuthorizationHeader: !1,
        throwOnError: !1,
        lockAcquireTimeout: 5e3,
        skipAutoInitialize: !1,
        experimental: {}
    },
    vi = {},
    yi = class e {
        get jwks() {
            return vi[this.storageKey] ?.jwks ?? {
                keys: []
            }
        }
        set jwks(e) {
            vi[this.storageKey] = Object.assign(Object.assign({}, vi[this.storageKey]), {
                jwks: e
            })
        }
        get jwks_cached_at() {
            return vi[this.storageKey] ?.cachedAt ?? -(2 ** 53 - 1)
        }
        set jwks_cached_at(e) {
            vi[this.storageKey] = Object.assign(Object.assign({}, vi[this.storageKey]), {
                cachedAt: e
            })
        }
        constructor(t) {
            var n;
            this.userStorage = null, this.memoryStorage = null, this.stateChangeEmitters = new Map, this.autoRefreshTicker = null, this.autoRefreshTickTimeout = null, this.visibilityChangedCallback = null, this.refreshingDeferred = null, this.lastRefreshFailure = null, this._sessionRemovalEpoch = 0, this.initializePromise = null, this._pendingInitNotifications = null, this.detectSessionInUrl = !0, this.hasCustomAuthorizationHeader = !1, this.suppressGetSessionWarning = !1, this.lock = null, this.lockAcquired = !1, this.pendingInLock = [], this.broadcastChannel = null, this.logger = console.log;
            let r = Object.assign(Object.assign({}, _i), t);
            if (this.storageKey = r.storageKey, this.instanceID = e.nextInstanceID[this.storageKey] ?? 0, e.nextInstanceID[this.storageKey] = this.instanceID + 1, this.logDebugMessages = !!r.debug, typeof r.debug == `function` && (this.logger = r.debug), this.instanceID > 0 && B()) {
                let e = `${this._logPrefix()} Multiple GoTrueClient instances detected in the same browser context. It is not an error, but this should be avoided as it may produce undefined behavior when used concurrently under the same storage key.`;
                console.warn(e), this.logDebugMessages && console.trace(e)
            }
            if (this.persistSession = r.persistSession, this.autoRefreshToken = r.autoRefreshToken, this.experimental = r.experimental ?? {}, this.admin = new Gr({
                    url: r.url,
                    headers: r.headers,
                    fetch: r.fetch,
                    experimental: this.experimental
                }), this.url = r.url, this.headers = r.headers, this.fetch = or(r.fetch), this.detectSessionInUrl = r.detectSessionInUrl, this.flowType = r.flowType, this.hasCustomAuthorizationHeader = r.hasCustomAuthorizationHeader, this.throwOnError = r.throwOnError, this.lockAcquireTimeout = r.lockAcquireTimeout, r.lock != null && (this.lock = r.lock), this.jwks || (this.jwks = {
                    keys: []
                }, this.jwks_cached_at = -(2 ** 53 - 1)), this.mfa = {
                    verify: this._verify.bind(this),
                    enroll: this._enroll.bind(this),
                    unenroll: this._unenroll.bind(this),
                    challenge: this._challenge.bind(this),
                    listFactors: this._listFactors.bind(this),
                    challengeAndVerify: this._challengeAndVerify.bind(this),
                    getAuthenticatorAssuranceLevel: this._getAuthenticatorAssuranceLevel.bind(this),
                    webauthn: new gi(this)
                }, this.oauth = {
                    getAuthorizationDetails: this._getAuthorizationDetails.bind(this),
                    approveAuthorization: this._approveAuthorization.bind(this),
                    denyAuthorization: this._denyAuthorization.bind(this),
                    listGrants: this._listOAuthGrants.bind(this),
                    revokeGrant: this._revokeOAuthGrant.bind(this)
                }, this.passkey = {
                    startRegistration: this._startPasskeyRegistration.bind(this),
                    verifyRegistration: this._verifyPasskeyRegistration.bind(this),
                    startAuthentication: this._startPasskeyAuthentication.bind(this),
                    verifyAuthentication: this._verifyPasskeyAuthentication.bind(this),
                    list: this._listPasskeys.bind(this),
                    update: this._updatePasskey.bind(this),
                    delete: this._deletePasskey.bind(this)
                }, this.persistSession ? (r.storage ? this.storage = r.storage : ir() ? this.storage = globalThis.localStorage : (this.memoryStorage = {}, this.storage = Kr(this.memoryStorage)), r.userStorage && (this.userStorage = r.userStorage)) : (this.memoryStorage = {}, this.storage = Kr(this.memoryStorage)), B() && globalThis.BroadcastChannel && this.persistSession && this.storageKey) {
                try {
                    this.broadcastChannel = new globalThis.BroadcastChannel(this.storageKey)
                } catch (e) {
                    console.error(`Failed to create a new BroadcastChannel, multi-tab state changes will not be available`, e)
                }(n = this.broadcastChannel) == null || n.addEventListener(`message`, async e => {
                    this._debug(`received broadcast notification from other tab or client`, e), (e.data.event === `TOKEN_REFRESHED` || e.data.event === `SIGNED_IN`) && (this.lastRefreshFailure = null);
                    try {
                        await this._notifyAllSubscribers(e.data.event, e.data.session, !1)
                    } catch (e) {
                        this._debug(`#broadcastChannel`, `error`, e)
                    }
                })
            }
            r.skipAutoInitialize || this.initialize().catch(e => {
                this._debug(`#initialize()`, `error`, e)
            })
        }
        isThrowOnErrorEnabled() {
            return this.throwOnError
        }
        _returnResult(e) {
            if (this.throwOnError && e && e.error) throw e.error;
            return e
        }
        _logPrefix() {
            return `GoTrueClient@${this.storageKey}:${this.instanceID} (${yn}) ${new Date().toISOString()}`
        }
        _debug(...e) {
            return this.logDebugMessages && this.logger(this._logPrefix(), ...e), this
        }
        async initialize() {
            if (this.initializePromise) return await this.initializePromise;
            this._pendingInitNotifications = [], this.initializePromise = (async () => this.lock == null ? await this._initialize() : await this._acquireLock(this.lockAcquireTimeout, async () => await this._initialize()))();
            let e = await this.initializePromise,
                t = this._pendingInitNotifications ?? [];
            this._pendingInitNotifications = null;
            for (let e of t) await this._notifyAllSubscribers(e.event, e.session, e.broadcast);
            return e
        }
        async _initialize() {
            try {
                let e = {},
                    t = `none`;
                if (B() && (e = ar(window.location.href), this._isImplicitGrantCallback(e) ? t = `implicit` : await this._isPKCECallback(e) && (t = `pkce`)), B() && this.detectSessionInUrl && t !== `none`) {
                    let {
                        data: n,
                        error: r
                    } = await this._getSessionFromURL(e, t);
                    if (r) {
                        if (this._debug(`#_initialize()`, `error detecting session from URL`, r), In(r)) {
                            let e = r.details ?.code;
                            if (e === `identity_already_exists` || e === `identity_not_found` || e === `single_identity_not_deletable`) return {
                                error: r
                            }
                        }
                        return {
                            error: r
                        }
                    }
                    let {
                        session: i,
                        redirectType: a
                    } = n;
                    return this._debug(`#_initialize()`, `detected session in URL`, i, `redirect type`, a), await this._saveSession(i), setTimeout(async () => {
                        a === `recovery` ? await this._notifyAllSubscribers(`PASSWORD_RECOVERY`, i) : await this._notifyAllSubscribers(`SIGNED_IN`, i)
                    }, 0), {
                        error: null
                    }
                }
                return await this._recoverAndRefresh(), {
                    error: null
                }
            } catch (e) {
                return F(e) ? this._returnResult({
                    error: e
                }) : this._returnResult({
                    error: new I(`Unexpected error during initialization`, e)
                })
            } finally {
                await this._handleVisibilityChange(), this._debug(`#_initialize()`, `end`)
            }
        }
        async signInAnonymously(e) {
            try {
                let {
                    data: t,
                    error: n
                } = await Y(this.fetch, `POST`, `${this.url}/signup`, {
                    headers: this.headers,
                    body: {
                        data: e ?.options ?.data ?? {},
                        gotrue_meta_security: {
                            captcha_token: e ?.options ?.captchaToken
                        }
                    },
                    xform: X
                });
                if (n || !t) return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: n
                });
                let r = t.session,
                    i = t.user;
                return t.session && (await this._saveSession(t.session), await this._notifyAllSubscribers(`SIGNED_IN`, r)), this._returnResult({
                    data: {
                        user: i,
                        session: r
                    },
                    error: null
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: e
                });
                throw e
            }
        }
        async signUp(e) {
            let t = null;
            try {
                let n;
                if (`email` in e) {
                    let {
                        email: r,
                        password: i,
                        options: a
                    } = e, o = null, s = null;
                    this.flowType === `pkce` && ([o, s, t] = await this._getCodeChallengeAndMethod()), n = await Y(this.fetch, `POST`, `${this.url}/signup`, {
                        headers: this.headers,
                        redirectTo: this._maybeAppendFlowIdToRedirect(a ?.emailRedirectTo, t),
                        body: {
                            email: r,
                            password: i,
                            data: a ?.data ?? {},
                            gotrue_meta_security: {
                                captcha_token: a ?.captchaToken
                            },
                            code_challenge: o,
                            code_challenge_method: s
                        },
                        xform: X
                    })
                } else if (`phone` in e) {
                    let {
                        phone: t,
                        password: r,
                        options: i
                    } = e;
                    n = await Y(this.fetch, `POST`, `${this.url}/signup`, {
                        headers: this.headers,
                        body: {
                            phone: t,
                            password: r,
                            data: i ?.data ?? {},
                            channel: i ?.channel ?? `sms`,
                            gotrue_meta_security: {
                                captcha_token: i ?.captchaToken
                            }
                        },
                        xform: X
                    })
                } else throw new Pn(`You must provide either an email or phone number and a password`);
                let {
                    data: r,
                    error: i
                } = n;
                if (i || !r) return await G(this.storage, this.storageKey, t), this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: i
                });
                let a = r.session,
                    o = r.user;
                return r.session && (await this._saveSession(r.session), await this._notifyAllSubscribers(`SIGNED_IN`, a)), this._returnResult({
                    data: {
                        user: o,
                        session: a
                    },
                    error: null
                })
            } catch (e) {
                if (await G(this.storage, this.storageKey, t), F(e)) return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: e
                });
                throw e
            }
        }
        async signInWithPassword(e) {
            try {
                let t;
                if (`email` in e) {
                    let {
                        email: n,
                        password: r,
                        options: i
                    } = e;
                    t = await Y(this.fetch, `POST`, `${this.url}/token?grant_type=password`, {
                        headers: this.headers,
                        body: {
                            email: n,
                            password: r,
                            gotrue_meta_security: {
                                captcha_token: i ?.captchaToken
                            }
                        },
                        xform: zr
                    })
                } else if (`phone` in e) {
                    let {
                        phone: n,
                        password: r,
                        options: i
                    } = e;
                    t = await Y(this.fetch, `POST`, `${this.url}/token?grant_type=password`, {
                        headers: this.headers,
                        body: {
                            phone: n,
                            password: r,
                            gotrue_meta_security: {
                                captcha_token: i ?.captchaToken
                            }
                        },
                        xform: zr
                    })
                } else throw new Pn(`You must provide either an email or phone number and a password`);
                let {
                    data: n,
                    error: r
                } = t;
                if (r) return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: r
                });
                if (!n || !n.session || !n.user) {
                    let e = new Nn;
                    return this._returnResult({
                        data: {
                            user: null,
                            session: null
                        },
                        error: e
                    })
                }
                return n.session && (await this._saveSession(n.session), await this._notifyAllSubscribers(`SIGNED_IN`, n.session)), this._returnResult({
                    data: Object.assign({
                        user: n.user,
                        session: n.session
                    }, n.weak_password ? {
                        weakPassword: n.weak_password
                    } : null),
                    error: r
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: e
                });
                throw e
            }
        }
        async signInWithOAuth(e) {
            return await this._handleProviderSignIn(e.provider, {
                redirectTo: e.options ?.redirectTo,
                scopes: e.options ?.scopes,
                queryParams: e.options ?.queryParams,
                skipBrowserRedirect: e.options ?.skipBrowserRedirect
            })
        }
        async exchangeCodeForSession(e, t) {
            return await this.initializePromise, this.lock == null ? this._exchangeCodeForSession(e, t) : this._acquireLock(this.lockAcquireTimeout, async () => this._exchangeCodeForSession(e, t))
        }
        async signInWithWeb3(e) {
            let {
                chain: t
            } = e;
            switch (t) {
                case `ethereum`:
                    return await this.signInWithEthereum(e);
                case `solana`:
                    return await this.signInWithSolana(e);
                default:
                    throw Error(`@supabase/auth-js: Unsupported chain "${t}"`)
            }
        }
        async signInWithEthereum(e) {
            let t, n;
            if (`message` in e) t = e.message, n = e.signature;
            else {
                let {
                    chain: r,
                    wallet: i,
                    statement: a,
                    options: o
                } = e, s;
                if (!B()) {
                    if (typeof i != `object` || !o ?.url) throw Error(`@supabase/auth-js: Both wallet and url must be specified in non-browser environments.`);
                    s = i
                } else if (typeof i == `object`) s = i;
                else {
                    let e = window;
                    if (`ethereum` in e && typeof e.ethereum == `object` && `request` in e.ethereum && typeof e.ethereum.request == `function`) s = e.ethereum;
                    else throw Error(`@supabase/auth-js: No compatible Ethereum wallet interface on the window object (window.ethereum) detected. Make sure the user already has a wallet installed and connected for this app. Prefer passing the wallet interface object directly to signInWithWeb3({ chain: 'ethereum', wallet: resolvedUserWallet }) instead.`)
                }
                let c = new URL(o ?.url ?? window.location.href),
                    l = await s.request({
                        method: `eth_requestAccounts`
                    }).then(e => e).catch(() => {
                        throw Error(`@supabase/auth-js: Wallet method eth_requestAccounts is missing or invalid`)
                    });
                if (!l || l.length === 0) throw Error(`@supabase/auth-js: No accounts available. Please ensure the wallet is connected.`);
                let u = Yr(l[0]),
                    d = o ?.signInWithEthereum ?.chainId;
                d ||= Xr(await s.request({
                    method: `eth_chainId`
                })), t = Qr({
                    domain: c.host,
                    address: u,
                    statement: a,
                    uri: c.href,
                    version: `1`,
                    chainId: d,
                    nonce: o ?.signInWithEthereum ?.nonce,
                    issuedAt: o ?.signInWithEthereum ?.issuedAt ?? new Date,
                    expirationTime: o ?.signInWithEthereum ?.expirationTime,
                    notBefore: o ?.signInWithEthereum ?.notBefore,
                    requestId: o ?.signInWithEthereum ?.requestId,
                    resources: o ?.signInWithEthereum ?.resources
                }), n = await s.request({
                    method: `personal_sign`,
                    params: [Zr(t), u]
                })
            }
            try {
                let {
                    data: r,
                    error: i
                } = await Y(this.fetch, `POST`, `${this.url}/token?grant_type=web3`, {
                    headers: this.headers,
                    body: Object.assign({
                        chain: `ethereum`,
                        message: t,
                        signature: n
                    }, e.options ?.captchaToken ? {
                        gotrue_meta_security: {
                            captcha_token: e.options ?.captchaToken
                        }
                    } : null),
                    xform: X
                });
                if (i) throw i;
                if (!r || !r.session || !r.user) {
                    let e = new Nn;
                    return this._returnResult({
                        data: {
                            user: null,
                            session: null
                        },
                        error: e
                    })
                }
                return r.session && (await this._saveSession(r.session), await this._notifyAllSubscribers(`SIGNED_IN`, r.session)), this._returnResult({
                    data: Object.assign({}, r),
                    error: i
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: e
                });
                throw e
            }
        }
        async signInWithSolana(e) {
            let t, n;
            if (`message` in e) t = e.message, n = e.signature;
            else {
                let {
                    chain: r,
                    wallet: i,
                    statement: a,
                    options: o
                } = e, s;
                if (!B()) {
                    if (typeof i != `object` || !o ?.url) throw Error(`@supabase/auth-js: Both wallet and url must be specified in non-browser environments.`);
                    s = i
                } else if (typeof i == `object`) s = i;
                else {
                    let e = window;
                    if (`solana` in e && typeof e.solana == `object` && (`signIn` in e.solana && typeof e.solana.signIn == `function` || `signMessage` in e.solana && typeof e.solana.signMessage == `function`)) s = e.solana;
                    else throw Error(`@supabase/auth-js: No compatible Solana wallet interface on the window object (window.solana) detected. Make sure the user already has a wallet installed and connected for this app. Prefer passing the wallet interface object directly to signInWithWeb3({ chain: 'solana', wallet: resolvedUserWallet }) instead.`)
                }
                let c = new URL(o ?.url ?? window.location.href);
                if (`signIn` in s && s.signIn) {
                    let e = await s.signIn(Object.assign(Object.assign(Object.assign({
                            issuedAt: new Date().toISOString()
                        }, o ?.signInWithSolana), {
                            version: `1`,
                            domain: c.host,
                            uri: c.href
                        }), a ? {
                            statement: a
                        } : null)),
                        r;
                    if (Array.isArray(e) && e[0] && typeof e[0] == `object`) r = e[0];
                    else if (e && typeof e == `object` && `signedMessage` in e && `signature` in e) r = e;
                    else throw Error(`@supabase/auth-js: Wallet method signIn() returned unrecognized value`);
                    if (`signedMessage` in r && `signature` in r && (typeof r.signedMessage == `string` || r.signedMessage instanceof Uint8Array) && r.signature instanceof Uint8Array) t = typeof r.signedMessage == `string` ? r.signedMessage : new TextDecoder().decode(r.signedMessage), n = r.signature;
                    else throw Error(`@supabase/auth-js: Wallet method signIn() API returned object without signedMessage and signature fields`)
                } else {
                    if (!(`signMessage` in s) || typeof s.signMessage != `function` || !(`publicKey` in s) || typeof s != `object` || !s.publicKey || !(`toBase58` in s.publicKey) || typeof s.publicKey.toBase58 != `function`) throw Error(`@supabase/auth-js: Wallet does not have a compatible signMessage() and publicKey.toBase58() API`);
                    t = [`${c.host} wants you to sign in with your Solana account:`, s.publicKey.toBase58(), ...a ? [``, a, ``] : [``], `Version: 1`, `URI: ${c.href}`, `Issued At: ${o?.signInWithSolana?.issuedAt??new Date().toISOString()}`, ...o ?.signInWithSolana ?.notBefore ? [`Not Before: ${o.signInWithSolana.notBefore}`] : [], ...o ?.signInWithSolana ?.expirationTime ? [`Expiration Time: ${o.signInWithSolana.expirationTime}`] : [], ...o ?.signInWithSolana ?.chainId ? [`Chain ID: ${o.signInWithSolana.chainId}`] : [], ...o ?.signInWithSolana ?.nonce ? [`Nonce: ${o.signInWithSolana.nonce}`] : [], ...o ?.signInWithSolana ?.requestId ? [`Request ID: ${o.signInWithSolana.requestId}`] : [], ...o ?.signInWithSolana ?.resources ?.length ? [`Resources`, ...o.signInWithSolana.resources.map(e => `- ${e}`)] : []].join(`
`);
                    let e = await s.signMessage(new TextEncoder().encode(t), `utf8`);
                    if (!e || !(e instanceof Uint8Array)) throw Error(`@supabase/auth-js: Wallet signMessage() API returned an recognized value`);
                    n = e
                }
            }
            try {
                let {
                    data: r,
                    error: i
                } = await Y(this.fetch, `POST`, `${this.url}/token?grant_type=web3`, {
                    headers: this.headers,
                    body: Object.assign({
                        chain: `solana`,
                        message: t,
                        signature: z(n)
                    }, e.options ?.captchaToken ? {
                        gotrue_meta_security: {
                            captcha_token: e.options ?.captchaToken
                        }
                    } : null),
                    xform: X
                });
                if (i) throw i;
                if (!r || !r.session || !r.user) {
                    let e = new Nn;
                    return this._returnResult({
                        data: {
                            user: null,
                            session: null
                        },
                        error: e
                    })
                }
                return r.session && (await this._saveSession(r.session), await this._notifyAllSubscribers(`SIGNED_IN`, r.session)), this._returnResult({
                    data: Object.assign({}, r),
                    error: i
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: e
                });
                throw e
            }
        }
        async _exchangeCodeForSession(e, t) {
            let n = t ?.flowId != null,
                r = n ? _r(t ?.flowId) : B() ? _r(ar(window.location.href)[On]) : null;
            n && !r && this._debug(`#_exchangeCodeForSession()`, `provided flowId is not a valid flow id`, t ?.flowId);
            let {
                verifier: i,
                flowId: a
            } = n && !r ? {
                verifier: null,
                flowId: null
            } : await Cr(this.storage, this.storageKey, r), [o, s] = (i ?? ``).split(`/`);
            try {
                if (!o && this.flowType === `pkce`) throw new Rn;
                let {
                    data: t,
                    error: n
                } = await Y(this.fetch, `POST`, `${this.url}/token?grant_type=pkce`, {
                    headers: this.headers,
                    body: {
                        auth_code: e,
                        code_verifier: o
                    },
                    xform: X
                });
                if (await G(this.storage, this.storageKey, a), n) throw n;
                if (!t || !t.session || !t.user) {
                    let e = new Nn;
                    return this._returnResult({
                        data: {
                            user: null,
                            session: null,
                            redirectType: null
                        },
                        error: e
                    })
                }
                return t.session && (await this._saveSession(t.session), await this._notifyAllSubscribers(s === `recovery` ? `PASSWORD_RECOVERY` : `SIGNED_IN`, t.session)), this._returnResult({
                    data: Object.assign(Object.assign({}, t), {
                        redirectType: s ?? null
                    }),
                    error: n
                })
            } catch (e) {
                if (await G(this.storage, this.storageKey, a), F(e)) return this._returnResult({
                    data: {
                        user: null,
                        session: null,
                        redirectType: null
                    },
                    error: e
                });
                throw e
            }
        }
        async signInWithIdToken(e) {
            try {
                let {
                    options: t,
                    provider: n,
                    token: r,
                    access_token: i,
                    nonce: a
                } = e, {
                    data: o,
                    error: s
                } = await Y(this.fetch, `POST`, `${this.url}/token?grant_type=id_token`, {
                    headers: this.headers,
                    body: {
                        provider: n,
                        id_token: r,
                        access_token: i,
                        nonce: a,
                        gotrue_meta_security: {
                            captcha_token: t ?.captchaToken
                        }
                    },
                    xform: X
                });
                if (s) return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: s
                });
                if (!o || !o.session || !o.user) {
                    let e = new Nn;
                    return this._returnResult({
                        data: {
                            user: null,
                            session: null
                        },
                        error: e
                    })
                }
                return o.session && (await this._saveSession(o.session), await this._notifyAllSubscribers(`SIGNED_IN`, o.session)), this._returnResult({
                    data: o,
                    error: s
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: e
                });
                throw e
            }
        }
        async signInWithOtp(e) {
            let t = null;
            try {
                if (`email` in e) {
                    let {
                        email: n,
                        options: r
                    } = e, i = null, a = null;
                    this.flowType === `pkce` && ([i, a, t] = await this._getCodeChallengeAndMethod());
                    let {
                        error: o
                    } = await Y(this.fetch, `POST`, `${this.url}/otp`, {
                        headers: this.headers,
                        body: {
                            email: n,
                            data: r ?.data ?? {},
                            create_user: r ?.shouldCreateUser ?? !0,
                            gotrue_meta_security: {
                                captcha_token: r ?.captchaToken
                            },
                            code_challenge: i,
                            code_challenge_method: a
                        },
                        redirectTo: this._maybeAppendFlowIdToRedirect(r ?.emailRedirectTo, t)
                    });
                    return this._returnResult({
                        data: {
                            user: null,
                            session: null
                        },
                        error: o
                    })
                }
                if (`phone` in e) {
                    let {
                        phone: t,
                        options: n
                    } = e, {
                        data: r,
                        error: i
                    } = await Y(this.fetch, `POST`, `${this.url}/otp`, {
                        headers: this.headers,
                        body: {
                            phone: t,
                            data: n ?.data ?? {},
                            create_user: n ?.shouldCreateUser ?? !0,
                            gotrue_meta_security: {
                                captcha_token: n ?.captchaToken
                            },
                            channel: n ?.channel ?? `sms`
                        }
                    });
                    return this._returnResult({
                        data: {
                            user: null,
                            session: null,
                            messageId: r ?.message_id
                        },
                        error: i
                    })
                }
                throw new Pn(`You must provide either an email or phone number.`)
            } catch (e) {
                if (await G(this.storage, this.storageKey, t), F(e)) return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: e
                });
                throw e
            }
        }
        async verifyOtp(e) {
            try {
                let t, n;
                `options` in e && (t = e.options ?.redirectTo, n = e.options ?.captchaToken);
                let {
                    data: r,
                    error: i
                } = await Y(this.fetch, `POST`, `${this.url}/verify`, {
                    headers: this.headers,
                    body: Object.assign(Object.assign({}, e), {
                        gotrue_meta_security: {
                            captcha_token: n
                        }
                    }),
                    redirectTo: t,
                    xform: X
                });
                if (i) throw i;
                if (!r) throw Error(`An error occurred on token verification.`);
                let a = r.session,
                    o = r.user;
                return a ?.access_token && (await this._saveSession(a), await this._notifyAllSubscribers(e.type == `recovery` ? `PASSWORD_RECOVERY` : `SIGNED_IN`, a)), this._returnResult({
                    data: {
                        user: o,
                        session: a
                    },
                    error: null
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: e
                });
                throw e
            }
        }
        async signInWithSSO(e) {
            let t = null;
            try {
                let n = null,
                    r = null;
                this.flowType === `pkce` && ([n, r, t] = await this._getCodeChallengeAndMethod());
                let i = await Y(this.fetch, `POST`, `${this.url}/sso`, {
                    body: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, `providerId` in e ? {
                        provider_id: e.providerId
                    } : null), `domain` in e ? {
                        domain: e.domain
                    } : null), {
                        redirect_to: this._maybeAppendFlowIdToRedirect(e.options ?.redirectTo, t)
                    }), e ?.options ?.captchaToken ? {
                        gotrue_meta_security: {
                            captcha_token: e.options.captchaToken
                        }
                    } : null), {
                        skip_http_redirect: !0,
                        code_challenge: n,
                        code_challenge_method: r
                    }),
                    headers: this.headers,
                    xform: Br
                });
                return i.data ?.url && B() && !e.options ?.skipBrowserRedirect && window.location.assign(i.data.url), this._returnResult(i)
            } catch (e) {
                if (await G(this.storage, this.storageKey, t), F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async reauthenticate() {
            return await this.initializePromise, this.lock == null ? await this._reauthenticate() : await this._acquireLock(this.lockAcquireTimeout, async () => await this._reauthenticate())
        }
        async _reauthenticate() {
            try {
                return await this._useSession(async e => {
                    let {
                        data: {
                            session: t
                        },
                        error: n
                    } = e;
                    if (n) throw n;
                    if (!t) throw new R;
                    let {
                        error: r
                    } = await Y(this.fetch, `GET`, `${this.url}/reauthenticate`, {
                        headers: this.headers,
                        jwt: t.access_token
                    });
                    return this._returnResult({
                        data: {
                            user: null,
                            session: null
                        },
                        error: r
                    })
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: e
                });
                throw e
            }
        }
        async resend(e) {
            let t = null;
            try {
                let n = `${this.url}/resend`;
                if (`email` in e) {
                    let {
                        email: r,
                        type: i,
                        options: a
                    } = e, o = null, s = null;
                    this.flowType === `pkce` && ([o, s, t] = await this._getCodeChallengeAndMethod());
                    let {
                        error: c
                    } = await Y(this.fetch, `POST`, n, {
                        headers: this.headers,
                        body: {
                            email: r,
                            type: i,
                            gotrue_meta_security: {
                                captcha_token: a ?.captchaToken
                            },
                            code_challenge: o,
                            code_challenge_method: s
                        },
                        redirectTo: this._maybeAppendFlowIdToRedirect(a ?.emailRedirectTo, t)
                    });
                    return c && await G(this.storage, this.storageKey, t), this._returnResult({
                        data: {
                            user: null,
                            session: null
                        },
                        error: c
                    })
                }
                if (`phone` in e) {
                    let {
                        phone: t,
                        type: r,
                        options: i
                    } = e, {
                        data: a,
                        error: o
                    } = await Y(this.fetch, `POST`, n, {
                        headers: this.headers,
                        body: {
                            phone: t,
                            type: r,
                            gotrue_meta_security: {
                                captcha_token: i ?.captchaToken
                            }
                        }
                    });
                    return this._returnResult({
                        data: {
                            user: null,
                            session: null,
                            messageId: a ?.message_id
                        },
                        error: o
                    })
                }
                throw new Pn(`You must provide either an email or phone number and a type`)
            } catch (e) {
                if (await G(this.storage, this.storageKey, t), F(e)) return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: e
                });
                throw e
            }
        }
        async getSession() {
            return await this.initializePromise, this.lock == null ? await this._useSession(async e => e) : await this._acquireLock(this.lockAcquireTimeout, async () => this._useSession(async e => e))
        }
        async _acquireLock(e, t) {
            this._debug(`#_acquireLock`, `begin`, e);
            try {
                if (this.lockAcquired) {
                    let e = this.pendingInLock.length ? this.pendingInLock[this.pendingInLock.length - 1] : Promise.resolve(),
                        n = (async () => (await e, await t()))();
                    return this.pendingInLock.push((async () => {
                        try {
                            await n
                        } catch {}
                    })()), n
                }
                return await this.lock(`lock:${this.storageKey}`, e, async () => {
                    this._debug(`#_acquireLock`, `lock acquired for storage key`, this.storageKey);
                    try {
                        this.lockAcquired = !0;
                        let e = t();
                        for (this.pendingInLock.push((async () => {
                                try {
                                    await e
                                } catch {}
                            })()), await e; this.pendingInLock.length;) {
                            let e = [...this.pendingInLock];
                            await Promise.all(e), this.pendingInLock.splice(0, e.length)
                        }
                        return await e
                    } finally {
                        this._debug(`#_acquireLock`, `lock released for storage key`, this.storageKey), this.lockAcquired = !1
                    }
                })
            } finally {
                this._debug(`#_acquireLock`, `end`)
            }
        }
        async _useSession(e) {
            this._debug(`#_useSession`, `begin`);
            try {
                return await e(await this.__loadSession())
            } finally {
                this._debug(`#_useSession`, `end`)
            }
        }
        async __loadSession() {
            this._debug(`#__loadSession()`, `begin`), this.lock != null && !this.lockAcquired && this._debug(`#__loadSession()`, `used outside of an acquired lock!`, Error().stack);
            try {
                let e = null,
                    t = await U(this.storage, this.storageKey);
                if (this._debug(`#getSession()`, `session from storage`, t), t !== null && (this._isValidSession(t) ? e = t : (this._debug(`#getSession()`, `session from storage is not valid`), await this._removeSession())), !e) return {
                    data: {
                        session: null
                    },
                    error: null
                };
                let n = e.expires_at ? e.expires_at * 1e3 - Date.now() < bn : !1;
                if (this._debug(`#__loadSession()`, `session has${n?``:` not`} expired`, `expires_at`, e.expires_at), !n) {
                    if (this.userStorage) {
                        let t = await U(this.userStorage, this.storageKey + `-user`);
                        t ?.user ? e.user = t.user : e.user = Mr()
                    }
                    if (this.storage.isServer && e.user && !e.user.__isUserNotAvailableProxy) {
                        let t = {
                            value: this.suppressGetSessionWarning
                        };
                        e.user = Nr(e.user, t), t.value && (this.suppressGetSessionWarning = !0)
                    }
                    return {
                        data: {
                            session: e
                        },
                        error: null
                    }
                }
                let {
                    data: r,
                    error: i
                } = await this._callRefreshToken(e.refresh_token);
                if (i) {
                    if (e.expires_at && e.expires_at * 1e3 > Date.now()) {
                        let t = await U(this.storage, this.storageKey);
                        if (t && t.refresh_token === e.refresh_token) return this._returnResult({
                            data: {
                                session: e
                            },
                            error: null
                        })
                    }
                    return this._returnResult({
                        data: {
                            session: null
                        },
                        error: i
                    })
                }
                return this._returnResult({
                    data: {
                        session: r
                    },
                    error: null
                })
            } finally {
                this._debug(`#__loadSession()`, `end`)
            }
        }
        async getUser(e) {
            if (e) return await this._getUser(e);
            await this.initializePromise;
            let t;
            return t = this.lock == null ? await this._getUser() : await this._acquireLock(this.lockAcquireTimeout, async () => await this._getUser()), t.data.user && (this.suppressGetSessionWarning = !0), t
        }
        async _getUser(e) {
            try {
                return e ? await Y(this.fetch, `GET`, `${this.url}/user`, {
                    headers: this.headers,
                    jwt: e,
                    xform: Z
                }) : await this._useSession(async e => {
                    let {
                        data: t,
                        error: n
                    } = e;
                    if (n) throw n;
                    return !t.session ?.access_token && !this.hasCustomAuthorizationHeader ? {
                        data: {
                            user: null
                        },
                        error: new R
                    } : await Y(this.fetch, `GET`, `${this.url}/user`, {
                        headers: this.headers,
                        jwt: t.session ?.access_token ?? void 0,
                        xform: Z
                    })
                })
            } catch (e) {
                if (F(e)) return Mn(e) && await this._removeSession(), this._returnResult({
                    data: {
                        user: null
                    },
                    error: e
                });
                throw e
            }
        }
        async updateUser(e, t = {}) {
            return await this.initializePromise, this.lock == null ? await this._updateUser(e, t) : await this._acquireLock(this.lockAcquireTimeout, async () => await this._updateUser(e, t))
        }
        async _updateUser(e, t = {}) {
            let n = null;
            try {
                return await this._useSession(async r => {
                    let {
                        data: i,
                        error: a
                    } = r;
                    if (a) throw a;
                    if (!i.session) throw new R;
                    let o = i.session,
                        s = null,
                        c = null;
                    this.flowType === `pkce` && e.email != null && ([s, c, n] = await this._getCodeChallengeAndMethod());
                    let {
                        data: l,
                        error: u
                    } = await Y(this.fetch, `PUT`, `${this.url}/user`, {
                        headers: this.headers,
                        redirectTo: this._maybeAppendFlowIdToRedirect(t ?.emailRedirectTo, n),
                        body: Object.assign(Object.assign({}, e), {
                            code_challenge: s,
                            code_challenge_method: c
                        }),
                        jwt: o.access_token,
                        xform: Z
                    });
                    if (u) throw u;
                    return o.user = l.user, await this._saveSession(o), await this._notifyAllSubscribers(`USER_UPDATED`, o), this._returnResult({
                        data: {
                            user: o.user
                        },
                        error: null
                    })
                })
            } catch (e) {
                if (await G(this.storage, this.storageKey, n), F(e)) return this._returnResult({
                    data: {
                        user: null
                    },
                    error: e
                });
                throw e
            }
        }
        async setSession(e) {
            return await this.initializePromise, this.lock == null ? await this._setSession(e) : await this._acquireLock(this.lockAcquireTimeout, async () => await this._setSession(e))
        }
        async _setSession(e) {
            try {
                if (!e.access_token || !e.refresh_token) throw new R;
                let t = Date.now() / 1e3,
                    n = t,
                    r = !0,
                    i = null,
                    {
                        payload: a
                    } = lr(e.access_token);
                if (a.exp && (n = a.exp, r = n <= t), r) {
                    let {
                        data: t,
                        error: n
                    } = await this._callRefreshToken(e.refresh_token);
                    if (n) return this._returnResult({
                        data: {
                            user: null,
                            session: null
                        },
                        error: n
                    });
                    if (!t) return {
                        data: {
                            user: null,
                            session: null
                        },
                        error: null
                    };
                    i = t
                } else {
                    let {
                        data: r,
                        error: a
                    } = await this._getUser(e.access_token);
                    if (a) return this._returnResult({
                        data: {
                            user: null,
                            session: null
                        },
                        error: a
                    });
                    i = {
                        access_token: e.access_token,
                        refresh_token: e.refresh_token,
                        user: r.user,
                        token_type: `bearer`,
                        expires_in: n - t,
                        expires_at: n
                    }, await this._saveSession(i), await this._notifyAllSubscribers(`SIGNED_IN`, i)
                }
                return this._returnResult({
                    data: {
                        user: i.user,
                        session: i
                    },
                    error: null
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: {
                        session: null,
                        user: null
                    },
                    error: e
                });
                throw e
            }
        }
        async refreshSession(e) {
            return await this.initializePromise, this.lock == null ? await this._refreshSession(e) : await this._acquireLock(this.lockAcquireTimeout, async () => await this._refreshSession(e))
        }
        async _refreshSession(e) {
            try {
                return await this._useSession(async t => {
                    if (!e) {
                        let {
                            data: n,
                            error: r
                        } = t;
                        if (r) throw r;
                        e = n.session ?? void 0
                    }
                    if (!e ?.refresh_token) throw new R;
                    let {
                        data: n,
                        error: r
                    } = await this._callRefreshToken(e.refresh_token);
                    return r ? this._returnResult({
                        data: {
                            user: null,
                            session: null
                        },
                        error: r
                    }) : n ? this._returnResult({
                        data: {
                            user: n.user,
                            session: n
                        },
                        error: null
                    }) : this._returnResult({
                        data: {
                            user: null,
                            session: null
                        },
                        error: null
                    })
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: {
                        user: null,
                        session: null
                    },
                    error: e
                });
                throw e
            }
        }
        async _getSessionFromURL(e, t) {
            try {
                if (!B()) throw new Fn(`No browser detected.`);
                if (e.error || e.error_description || e.error_code) throw new Fn(e.error_description || `Error in URL with unspecified error_description`, {
                    error: e.error || `unspecified_error`,
                    code: e.error_code || `unspecified_code`
                });
                switch (t) {
                    case `implicit`:
                        if (this.flowType === `pkce`) throw new Ln(`Not a valid PKCE flow url.`);
                        break;
                    case `pkce`:
                        if (this.flowType === `implicit`) throw new Fn(`Not a valid implicit grant flow url.`)
                }
                if (t === `pkce`) {
                    if (this._debug(`#_initialize()`, `begin`, `is PKCE flow`, !0), !e.code) throw new Ln(`No code detected.`);
                    let {
                        data: t,
                        error: n
                    } = await this._exchangeCodeForSession(e.code, {
                        flowId: e[On]
                    });
                    if (n) throw n;
                    let r = new URL(window.location.href);
                    return r.searchParams.delete(`code`), r.searchParams.delete(On), window.history.replaceState(window.history.state, ``, r.toString()), {
                        data: {
                            session: t.session,
                            redirectType: t.redirectType ?? null
                        },
                        error: null
                    }
                }
                let {
                    provider_token: n,
                    provider_refresh_token: r,
                    access_token: i,
                    refresh_token: a,
                    expires_in: o,
                    expires_at: s,
                    token_type: c
                } = e;
                if (!i || !o || !a || !c) throw new Fn(`No session defined in URL`);
                let l = Math.round(Date.now() / 1e3),
                    u = parseInt(o),
                    d = l + u;
                s && (d = parseInt(s));
                let f = d - l;
                f * 1e3 <= 3e4 && console.warn(`@supabase/gotrue-js: Session as retrieved from URL expires in ${f}s, should have been closer to ${u}s`);
                let p = d - u;
                l - p >= 120 ? console.warn(`@supabase/gotrue-js: Session as retrieved from URL was issued over 120s ago, URL could be stale`, p, d, l) : l - p < 0 && console.warn(`@supabase/gotrue-js: Session as retrieved from URL was issued in the future? Check the device clock for skew`, p, d, l);
                let {
                    data: m,
                    error: h
                } = await this._getUser(i);
                if (h) throw h;
                let g = {
                    provider_token: n,
                    provider_refresh_token: r,
                    access_token: i,
                    expires_in: u,
                    expires_at: d,
                    refresh_token: a,
                    token_type: c,
                    user: m.user
                };
                return window.location.hash = ``, this._debug(`#_getSessionFromURL()`, `clearing window.location.hash`), this._returnResult({
                    data: {
                        session: g,
                        redirectType: e.type
                    },
                    error: null
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: {
                        session: null,
                        redirectType: null
                    },
                    error: e
                });
                throw e
            }
        }
        _isImplicitGrantCallback(e) {
            return typeof this.detectSessionInUrl == `function` ? this.detectSessionInUrl(new URL(window.location.href), e) : !!(e.access_token || e.error || e.error_description || e.error_code)
        }
        async _isPKCECallback(e) {
            if (!e.code) return !1;
            let t = _r(e[On]);
            return t && await U(this.storage, yr(this.storageKey, t)) ? !0 : !!await U(this.storage, `${this.storageKey}-code-verifier`)
        }
        async signOut(e = {
            scope: `global`
        }) {
            return await this.initializePromise, this.lock == null ? await this._signOut(e) : await this._acquireLock(this.lockAcquireTimeout, async () => await this._signOut(e))
        }
        async _signOut({
            scope: e
        } = {
            scope: `global`
        }) {
            return await this._useSession(async t => {
                let n = async () => {
                        await this._removeSession()
                    },
                    {
                        data: r,
                        error: i
                    } = t;
                if (i && !Mn(i)) return this._returnResult({
                    error: i
                });
                let a = r.session ?.access_token;
                if (a) {
                    let {
                        error: t
                    } = await this.admin.signOut(a, e);
                    if (t && !(jn(t) && (t.status === 404 || t.status === 401 || t.status === 403) || Mn(t))) return e !== `others` && await n(), this._returnResult({
                        error: t
                    })
                }
                return e !== `others` && await n(), this._returnResult({
                    error: null
                })
            })
        }
        onAuthStateChange(e) {
            let t = rr(),
                n = {
                    id: t,
                    callback: e,
                    unsubscribe: () => {
                        this._debug(`#unsubscribe()`, `state change callback with id removed`, t), this.stateChangeEmitters.delete(t)
                    }
                };
            return this._debug(`#onAuthStateChange()`, `registered callback with id`, t), this.stateChangeEmitters.set(t, n), (async () => {
                await this.initializePromise, this.lock == null ? await this._emitInitialSession(t) : await this._acquireLock(this.lockAcquireTimeout, async () => {
                    this._emitInitialSession(t)
                })
            })(), {
                data: {
                    subscription: n
                }
            }
        }
        async _emitInitialSession(e) {
            return await this._useSession(async t => {
                try {
                    let {
                        data: {
                            session: n
                        },
                        error: r
                    } = t;
                    if (r) throw r;
                    await this.stateChangeEmitters.get(e) ?.callback(`INITIAL_SESSION`, n), this._debug(`INITIAL_SESSION`, `callback id`, e, `session`, n)
                } catch (t) {
                    await this.stateChangeEmitters.get(e) ?.callback(`INITIAL_SESSION`, null), this._debug(`INITIAL_SESSION`, `callback id`, e, `error`, t), Mn(t) || Bn(t) || jn(t) && (t.code === `refresh_token_not_found` || t.code === `refresh_token_already_used` || t.code === `session_expired`) ? console.warn(t) : console.error(t)
                }
            })
        }
        async resetPasswordForEmail(e, t = {}) {
            let n = null,
                r = null,
                i = null;
            this.flowType === `pkce` && ([n, r, i] = await this._getCodeChallengeAndMethod(!0));
            try {
                return await Y(this.fetch, `POST`, `${this.url}/recover`, {
                    body: {
                        email: e,
                        code_challenge: n,
                        code_challenge_method: r,
                        gotrue_meta_security: {
                            captcha_token: t.captchaToken
                        }
                    },
                    headers: this.headers,
                    redirectTo: this._maybeAppendFlowIdToRedirect(t.redirectTo, i)
                })
            } catch (e) {
                if (await G(this.storage, this.storageKey, i), F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async getUserIdentities() {
            try {
                let {
                    data: e,
                    error: t
                } = await this.getUser();
                if (t) throw t;
                return this._returnResult({
                    data: {
                        identities: e.user.identities ?? []
                    },
                    error: null
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async linkIdentity(e) {
            return `token` in e ? this.linkIdentityIdToken(e) : this.linkIdentityOAuth(e)
        }
        async linkIdentityOAuth(e) {
            let t = null;
            try {
                let {
                    data: n,
                    error: r
                } = await this._useSession(async n => {
                    let {
                        data: r,
                        error: i
                    } = n;
                    if (i) throw i;
                    let {
                        url: a,
                        flowId: o
                    } = await this._getUrlForProvider(`${this.url}/user/identities/authorize`, e.provider, {
                        redirectTo: e.options ?.redirectTo,
                        scopes: e.options ?.scopes,
                        queryParams: e.options ?.queryParams,
                        skipBrowserRedirect: !0
                    });
                    return t = o, await Y(this.fetch, `GET`, a, {
                        headers: this.headers,
                        jwt: r.session ?.access_token ?? void 0
                    })
                });
                if (r) throw r;
                return B() && !e.options ?.skipBrowserRedirect && window.location.assign(n ?.url), this._returnResult({
                    data: {
                        provider: e.provider,
                        url: n ?.url,
                        flowId: t
                    },
                    error: null
                })
            } catch (n) {
                if (F(n)) return this._returnResult({
                    data: {
                        provider: e.provider,
                        url: null,
                        flowId: t
                    },
                    error: n
                });
                throw n
            }
        }
        async linkIdentityIdToken(e) {
            return await this._useSession(async t => {
                try {
                    let {
                        error: n,
                        data: {
                            session: r
                        }
                    } = t;
                    if (n) throw n;
                    let {
                        options: i,
                        provider: a,
                        token: o,
                        access_token: s,
                        nonce: c
                    } = e, {
                        data: l,
                        error: u
                    } = await Y(this.fetch, `POST`, `${this.url}/token?grant_type=id_token`, {
                        headers: this.headers,
                        jwt: r ?.access_token ?? void 0,
                        body: {
                            provider: a,
                            id_token: o,
                            access_token: s,
                            nonce: c,
                            link_identity: !0,
                            gotrue_meta_security: {
                                captcha_token: i ?.captchaToken
                            }
                        },
                        xform: X
                    });
                    return u ? this._returnResult({
                        data: {
                            user: null,
                            session: null
                        },
                        error: u
                    }) : !l || !l.session || !l.user ? this._returnResult({
                        data: {
                            user: null,
                            session: null
                        },
                        error: new Nn
                    }) : (l.session && (await this._saveSession(l.session), await this._notifyAllSubscribers(`USER_UPDATED`, l.session)), this._returnResult({
                        data: l,
                        error: u
                    }))
                } catch (e) {
                    if (await G(this.storage, this.storageKey, null), F(e)) return this._returnResult({
                        data: {
                            user: null,
                            session: null
                        },
                        error: e
                    });
                    throw e
                }
            })
        }
        async unlinkIdentity(e) {
            try {
                return await this._useSession(async t => {
                    let {
                        data: n,
                        error: r
                    } = t;
                    if (r) throw r;
                    return await Y(this.fetch, `DELETE`, `${this.url}/user/identities/${e.identity_id}`, {
                        headers: this.headers,
                        jwt: n.session ?.access_token ?? void 0
                    })
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async _refreshAccessToken(e) {
            let t = `#_refreshAccessToken()`;
            this._debug(t, `begin`);
            try {
                let n = Date.now();
                return await dr(async n => (n > 0 && await ur(200 * 2 ** (n - 1)), this._debug(t, `refreshing attempt`, n), await Y(this.fetch, `POST`, `${this.url}/token?grant_type=refresh_token`, {
                    body: {
                        refresh_token: e
                    },
                    headers: this.headers,
                    xform: X
                })), (e, t) => {
                    let r = 200 * 2 ** e;
                    return t && Bn(t) && Date.now() + r - n < 3e4
                })
            } catch (e) {
                if (this._debug(t, `error`, e), F(e)) return this._returnResult({
                    data: {
                        session: null,
                        user: null
                    },
                    error: e
                });
                throw e
            } finally {
                this._debug(t, `end`)
            }
        }
        _isValidSession(e) {
            return typeof e == `object` && !!e && `access_token` in e && `refresh_token` in e && `expires_at` in e
        }
        async _handleProviderSignIn(e, t) {
            let {
                url: n,
                flowId: r
            } = await this._getUrlForProvider(`${this.url}/authorize`, e, {
                redirectTo: t.redirectTo,
                scopes: t.scopes,
                queryParams: t.queryParams
            });
            return this._debug(`#_handleProviderSignIn()`, `provider`, e, `options`, t, `url`, n), B() && !t.skipBrowserRedirect && window.location.assign(n), {
                data: {
                    provider: e,
                    url: n,
                    flowId: r
                },
                error: null
            }
        }
        async _recoverAndRefresh() {
            let e = `#_recoverAndRefresh()`;
            this._debug(e, `begin`);
            try {
                let t = await U(this.storage, this.storageKey);
                if (t && this.userStorage) {
                    let e = await U(this.userStorage, this.storageKey + `-user`);
                    !this.storage.isServer && Object.is(this.storage, this.userStorage) && !e && (e = {
                        user: t.user
                    }, await H(this.userStorage, this.storageKey + `-user`, e)), t.user = e ?.user ?? Mr()
                } else if (t && !t.user && !t.user) {
                    let e = await U(this.storage, this.storageKey + `-user`);
                    e && e ?.user ? (t.user = e.user, await W(this.storage, this.storageKey + `-user`), await H(this.storage, this.storageKey, t)) : t.user = Mr()
                }
                if (this._debug(e, `session from storage`, t), !this._isValidSession(t)) {
                    this._debug(e, `session is not valid`), t !== null && await this._removeSession();
                    return
                }
                let n = (t.expires_at ?? 1 / 0) * 1e3 - Date.now() < bn;
                if (this._debug(e, `session has${n?``:` not`} expired with margin of ${bn}s`), n) {
                    if (this.autoRefreshToken && t.refresh_token) {
                        let {
                            error: n
                        } = await this._callRefreshToken(t.refresh_token);
                        n && (Hn(n) ? this._debug(e, `refresh discarded by commit guard`, n) : this._debug(e, `refresh failed`, n))
                    }
                } else if (t.user && t.user.__isUserNotAvailableProxy === !0) try {
                    let {
                        data: n,
                        error: r
                    } = await this._getUser(t.access_token);
                    !r && n ?.user ? (t.user = n.user, await this._saveSession(t), await this._notifyAllSubscribers(`SIGNED_IN`, t)) : this._debug(e, `could not get user data, skipping SIGNED_IN notification`)
                } catch (t) {
                    console.error(`Error getting user data:`, t), this._debug(e, `error getting user data, skipping SIGNED_IN notification`, t)
                } else await this._notifyAllSubscribers(`SIGNED_IN`, t)
            } catch (t) {
                this._debug(e, `error`, t), Bn(t) ? console.warn(t) : console.error(t);
                return
            } finally {
                this._debug(e, `end`)
            }
        }
        async _callRefreshToken(e) {
            var t, n;
            if (!e) throw new R;
            if (this.refreshingDeferred) return this.refreshingDeferred.promise;
            if (this.lastRefreshFailure && this.lastRefreshFailure.refreshToken === e && Date.now() < this.lastRefreshFailure.expiresAt) return this._debug(`#_callRefreshToken()`, `returning cached failure (cooldown active)`), this.lastRefreshFailure.result;
            let r = `#_callRefreshToken()`;
            this._debug(r, `begin`);
            try {
                this.refreshingDeferred = new cr;
                let t = await U(this.storage, this.storageKey),
                    {
                        data: n,
                        error: i
                    } = await this._refreshAccessToken(e);
                if (i) throw i;
                if (!n.session) throw new R;
                let a = await U(this.storage, this.storageKey);
                if (t !== null && (a === null || a.refresh_token !== t.refresh_token)) {
                    this._debug(r, `commit guard: storage changed since refresh started, discarding rotated tokens`, {
                        startedWith: `present`,
                        nowHolds: a ? `replaced` : `cleared`
                    });
                    let e = {
                        data: null,
                        error: new Vn
                    };
                    return this.refreshingDeferred.resolve(e), e
                }
                let o = this._sessionRemovalEpoch;
                if (await this._saveSession(n.session), this._sessionRemovalEpoch !== o) {
                    this._debug(r, `commit guard (post-save): _removeSession ran during _saveSession, undoing write`), await W(this.storage, this.storageKey), this.userStorage && await W(this.userStorage, this.storageKey + `-user`);
                    let e = {
                        data: null,
                        error: new Vn
                    };
                    return this.refreshingDeferred.resolve(e), e
                }
                await this._notifyAllSubscribers(`TOKEN_REFRESHED`, n.session);
                let s = {
                    data: n.session,
                    error: null
                };
                return this.lastRefreshFailure = null, this.refreshingDeferred.resolve(s), s
            } catch (i) {
                if (this._debug(r, `error`, i), F(i)) {
                    let n = {
                        data: null,
                        error: i
                    };
                    if (!Bn(i)) {
                        let e = await U(this.storage, this.storageKey);
                        e ?.expires_at && e.expires_at * 1e3 > Date.now() ? this._debug(r, `proactive refresh failed, access token still valid — preserving session`) : await this._removeSession()
                    }
                    return this.lastRefreshFailure = {
                        refreshToken: e,
                        result: n,
                        expiresAt: Date.now() + xn
                    }, (t = this.refreshingDeferred) == null || t.resolve(n), n
                }
                throw (n = this.refreshingDeferred) == null || n.reject(i), i
            } finally {
                this.refreshingDeferred = null, this._debug(r, `end`)
            }
        }
        async _notifyAllSubscribers(e, t, n = !0) {
            if (this._pendingInitNotifications !== null && n) {
                this._pendingInitNotifications.push({
                    event: e,
                    session: t,
                    broadcast: n
                });
                return
            }
            let r = `#_notifyAllSubscribers(${e})`;
            this._debug(r, `begin`, t, `broadcast = ${n}`);
            try {
                this.broadcastChannel && n && this.broadcastChannel.postMessage({
                    event: e,
                    session: t
                });
                let r = [],
                    i = Array.from(this.stateChangeEmitters.values()).map(async n => {
                        try {
                            await n.callback(e, t)
                        } catch (e) {
                            r.push(e)
                        }
                    });
                if (await Promise.all(i), r.length > 0) {
                    for (let e = 0; e < r.length; e += 1) console.error(r[e]);
                    throw r[0]
                }
            } finally {
                this._debug(r, `end`)
            }
        }
        async _saveSession(e) {
            this._debug(`#_saveSession()`, e), this.suppressGetSessionWarning = !0;
            let t = Object.assign({}, e),
                n = t.user && t.user.__isUserNotAvailableProxy === !0;
            if (this.userStorage) {
                !n && t.user && await H(this.userStorage, this.storageKey + `-user`, {
                    user: t.user
                });
                let e = Object.assign({}, t);
                delete e.user;
                let r = Pr(e);
                await H(this.storage, this.storageKey, r)
            } else {
                let e = Pr(t);
                await H(this.storage, this.storageKey, e)
            }
        }
        async _removeSession() {
            this._sessionRemovalEpoch += 1, this._debug(`#_removeSession()`), this.lastRefreshFailure = null, this.suppressGetSessionWarning = !1, await W(this.storage, this.storageKey), await wr(this.storage, this.storageKey), await W(this.storage, this.storageKey + `-user`), this.userStorage && await W(this.userStorage, this.storageKey + `-user`), await this._notifyAllSubscribers(`SIGNED_OUT`, null)
        }
        _removeVisibilityChangedCallback() {
            this._debug(`#_removeVisibilityChangedCallback()`);
            let e = this.visibilityChangedCallback;
            this.visibilityChangedCallback = null;
            try {
                e && B() && window != null && window.removeEventListener && window.removeEventListener(`visibilitychange`, e)
            } catch (e) {
                console.error(`removing visibilitychange callback failed`, e)
            }
        }
        async _startAutoRefresh() {
            await this._stopAutoRefresh(), this._debug(`#_startAutoRefresh()`);
            let e = setInterval(() => this._autoRefreshTokenTick(), P);
            this.autoRefreshTicker = e, e && typeof e == `object` && typeof e.unref == `function` ? e.unref() : typeof Deno < `u` && typeof Deno.unrefTimer == `function` && Deno.unrefTimer(e);
            let t = setTimeout(async () => {
                await this.initializePromise, await this._autoRefreshTokenTick()
            }, 0);
            this.autoRefreshTickTimeout = t, t && typeof t == `object` && typeof t.unref == `function` ? t.unref() : typeof Deno < `u` && typeof Deno.unrefTimer == `function` && Deno.unrefTimer(t)
        }
        async _stopAutoRefresh() {
            this._debug(`#_stopAutoRefresh()`);
            let e = this.autoRefreshTicker;
            this.autoRefreshTicker = null, e && clearInterval(e);
            let t = this.autoRefreshTickTimeout;
            this.autoRefreshTickTimeout = null, t && clearTimeout(t)
        }
        async startAutoRefresh() {
            this._removeVisibilityChangedCallback(), await this._startAutoRefresh()
        }
        async stopAutoRefresh() {
            this._removeVisibilityChangedCallback(), await this._stopAutoRefresh()
        }
        async dispose() {
            var e;
            this._removeVisibilityChangedCallback(), await this._stopAutoRefresh(), (e = this.broadcastChannel) == null || e.close(), this.broadcastChannel = null, this.stateChangeEmitters.clear()
        }
        async _autoRefreshTokenTick() {
            if (this._debug(`#_autoRefreshTokenTick()`, `begin`), this.lock != null) {
                try {
                    await this._acquireLock(0, async () => {
                        try {
                            let e = Date.now();
                            try {
                                return await this._useSession(async t => {
                                    let {
                                        data: {
                                            session: n
                                        }
                                    } = t;
                                    if (!n || !n.refresh_token || !n.expires_at) {
                                        this._debug(`#_autoRefreshTokenTick()`, `no session`);
                                        return
                                    }
                                    let r = Math.floor((n.expires_at * 1e3 - e) / P);
                                    this._debug(`#_autoRefreshTokenTick()`, `access token expires in ${r} ticks, a tick lasts ${P}ms, refresh threshold is 3 ticks`), r <= 3 && await this._callRefreshToken(n.refresh_token)
                                })
                            } catch (e) {
                                console.error(`Auto refresh tick failed with error. This is likely a transient error.`, e)
                            }
                        } finally {
                            this._debug(`#_autoRefreshTokenTick()`, `end`)
                        }
                    })
                } catch (e) {
                    if (e instanceof qr) this._debug(`auto refresh token tick lock not available`);
                    else throw e
                }
                return
            }
            if (this.refreshingDeferred !== null) {
                this._debug(`#_autoRefreshTokenTick()`, `refresh already in flight, skipping`);
                return
            }
            try {
                let e = Date.now();
                try {
                    await this._useSession(async t => {
                        let {
                            data: {
                                session: n
                            }
                        } = t;
                        if (!n || !n.refresh_token || !n.expires_at) {
                            this._debug(`#_autoRefreshTokenTick()`, `no session`);
                            return
                        }
                        let r = Math.floor((n.expires_at * 1e3 - e) / P);
                        this._debug(`#_autoRefreshTokenTick()`, `access token expires in ${r} ticks, a tick lasts ${P}ms, refresh threshold is 3 ticks`), r <= 3 && await this._callRefreshToken(n.refresh_token)
                    })
                } catch (e) {
                    console.error(`Auto refresh tick failed with error. This is likely a transient error.`, e)
                }
            } finally {
                this._debug(`#_autoRefreshTokenTick()`, `end`)
            }
        }
        async _handleVisibilityChange() {
            if (this._debug(`#_handleVisibilityChange()`), !B() || !(window != null && window.addEventListener)) return this.autoRefreshToken && this.startAutoRefresh(), !1;
            try {
                this.visibilityChangedCallback = async () => {
                    try {
                        await this._onVisibilityChanged(!1)
                    } catch (e) {
                        this._debug(`#visibilityChangedCallback`, `error`, e)
                    }
                }, window == null || window.addEventListener(`visibilitychange`, this.visibilityChangedCallback), await this._onVisibilityChanged(!0)
            } catch (e) {
                console.error(`_handleVisibilityChange`, e)
            }
        }
        async _onVisibilityChanged(e) {
            let t = `#_onVisibilityChanged(${e})`;
            if (this._debug(t, `visibilityState`, document.visibilityState), document.visibilityState === `visible`) {
                if (this.autoRefreshToken && this._startAutoRefresh(), !e) {
                    if (await this.initializePromise, this.lock != null) await this._acquireLock(this.lockAcquireTimeout, async () => {
                        if (document.visibilityState !== `visible`) {
                            this._debug(t, `acquired the lock to recover the session, but the browser visibilityState is no longer visible, aborting`);
                            return
                        }
                        await this._recoverAndRefresh()
                    });
                    else {
                        if (document.visibilityState !== `visible`) {
                            this._debug(t, `visibilityState is no longer visible, skipping recovery`);
                            return
                        }
                        await this._recoverAndRefresh()
                    }
                }
            } else document.visibilityState === `hidden` && this.autoRefreshToken && this._stopAutoRefresh()
        }
        async _getUrlForProvider(e, t, n) {
            let r = n ?.redirectTo,
                i = null,
                a = null,
                o = null;
            this.flowType === `pkce` && ([i, a, o] = await this._getCodeChallengeAndMethod(), r = this._maybeAppendFlowIdToRedirect(r, o));
            let s = [`provider=${encodeURIComponent(t)}`];
            if (r && s.push(`redirect_to=${encodeURIComponent(r)}`), n ?.scopes && s.push(`scopes=${encodeURIComponent(n.scopes)}`), i != null && a != null) {
                let e = new URLSearchParams({
                    code_challenge: `${encodeURIComponent(i)}`,
                    code_challenge_method: `${encodeURIComponent(a)}`
                });
                s.push(e.toString())
            }
            if (n ?.queryParams) {
                let e = new URLSearchParams(n.queryParams);
                s.push(e.toString())
            }
            return n ?.skipBrowserRedirect && s.push(`skip_http_redirect=${n.skipBrowserRedirect}`), {
                url: `${e}?${s.join(`&`)}`,
                flowId: o
            }
        }
        _maybeAppendFlowIdToRedirect(e, t) {
            return !e || !t || !this.experimental.appendPkceFlowIdToRedirects ? e ?? void 0 : Tr(e, t)
        }
        async _getCodeChallengeAndMethod(e = !1) {
            return Er(this.storage, this.storageKey, e, e => this._debug(`#_getCodeChallengeAndMethod()`, `evicted oldest pending PKCE verifier slot`, e))
        }
        async _unenroll(e) {
            try {
                return await this._useSession(async t => {
                    let {
                        data: n,
                        error: r
                    } = t;
                    return r ? this._returnResult({
                        data: null,
                        error: r
                    }) : await Y(this.fetch, `DELETE`, `${this.url}/factors/${e.factorId}`, {
                        headers: this.headers,
                        jwt: n ?.session ?.access_token
                    })
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async _enroll(e) {
            try {
                return await this._useSession(async t => {
                    let {
                        data: n,
                        error: r
                    } = t;
                    if (r) return this._returnResult({
                        data: null,
                        error: r
                    });
                    let i = Object.assign({
                            friendly_name: e.friendlyName,
                            factor_type: e.factorType
                        }, e.factorType === `phone` ? {
                            phone: e.phone
                        } : e.factorType === `totp` ? {
                            issuer: e.issuer
                        } : {}),
                        {
                            data: a,
                            error: o
                        } = await Y(this.fetch, `POST`, `${this.url}/factors`, {
                            body: i,
                            headers: this.headers,
                            jwt: n ?.session ?.access_token
                        });
                    return o ? this._returnResult({
                        data: null,
                        error: o
                    }) : (e.factorType === `totp` && a.type === `totp` && a ?.totp ?.qr_code && (a.totp.qr_code = `data:image/svg+xml;utf-8,${a.totp.qr_code}`), this._returnResult({
                        data: a,
                        error: null
                    }))
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async _verify(e) {
            let t = async () => {
                try {
                    return await this._useSession(async t => {
                        let {
                            data: n,
                            error: r
                        } = t;
                        if (r) return this._returnResult({
                            data: null,
                            error: r
                        });
                        let i = Object.assign({
                                challenge_id: e.challengeId
                            }, `webauthn` in e ? {
                                webauthn: Object.assign(Object.assign({}, e.webauthn), {
                                    credential_response: e.webauthn.type === `create` ? ai(e.webauthn.credential_response) : oi(e.webauthn.credential_response)
                                })
                            } : {
                                code: e.code
                            }),
                            {
                                data: a,
                                error: o
                            } = await Y(this.fetch, `POST`, `${this.url}/factors/${e.factorId}/verify`, {
                                body: i,
                                headers: this.headers,
                                jwt: n ?.session ?.access_token
                            });
                        return o ? this._returnResult({
                            data: null,
                            error: o
                        }) : (await this._saveSession(Object.assign({
                            expires_at: Math.round(Date.now() / 1e3) + a.expires_in
                        }, a)), await this._notifyAllSubscribers(`MFA_CHALLENGE_VERIFIED`, a), this._returnResult({
                            data: a,
                            error: o
                        }))
                    })
                } catch (e) {
                    if (F(e)) return this._returnResult({
                        data: null,
                        error: e
                    });
                    throw e
                }
            };
            return this.lock == null ? t() : this._acquireLock(this.lockAcquireTimeout, t)
        }
        async _challenge(e) {
            let t = async () => {
                try {
                    return await this._useSession(async t => {
                        let {
                            data: n,
                            error: r
                        } = t;
                        if (r) return this._returnResult({
                            data: null,
                            error: r
                        });
                        let i = await Y(this.fetch, `POST`, `${this.url}/factors/${e.factorId}/challenge`, {
                            body: e,
                            headers: this.headers,
                            jwt: n ?.session ?.access_token
                        });
                        if (i.error) return i;
                        let {
                            data: a
                        } = i;
                        if (a.type !== `webauthn`) return {
                            data: a,
                            error: null
                        };
                        switch (a.webauthn.type) {
                            case `create`:
                                return {
                                    data: Object.assign(Object.assign({}, a), {
                                        webauthn: Object.assign(Object.assign({}, a.webauthn), {
                                            credential_options: Object.assign(Object.assign({}, a.webauthn.credential_options), {
                                                publicKey: ri(a.webauthn.credential_options.publicKey)
                                            })
                                        })
                                    }),
                                    error: null
                                };
                            case `request`:
                                return {
                                    data: Object.assign(Object.assign({}, a), {
                                        webauthn: Object.assign(Object.assign({}, a.webauthn), {
                                            credential_options: Object.assign(Object.assign({}, a.webauthn.credential_options), {
                                                publicKey: ii(a.webauthn.credential_options.publicKey)
                                            })
                                        })
                                    }),
                                    error: null
                                }
                        }
                    })
                } catch (e) {
                    if (F(e)) return this._returnResult({
                        data: null,
                        error: e
                    });
                    throw e
                }
            };
            return this.lock == null ? t() : this._acquireLock(this.lockAcquireTimeout, t)
        }
        async _challengeAndVerify(e) {
            let {
                data: t,
                error: n
            } = await this._challenge({
                factorId: e.factorId
            });
            return n ? this._returnResult({
                data: null,
                error: n
            }) : await this._verify({
                factorId: e.factorId,
                challengeId: t.id,
                code: e.code
            })
        }
        async _listFactors() {
            let {
                data: {
                    user: e
                },
                error: t
            } = await this.getUser();
            if (t) return {
                data: null,
                error: t
            };
            let n = {
                all: [],
                phone: [],
                totp: [],
                webauthn: []
            };
            for (let t of e ?.factors ?? []) n.all.push(t), t.status === `verified` && n[t.factor_type].push(t);
            return {
                data: n,
                error: null
            }
        }
        async _getAuthenticatorAssuranceLevel(e) {
            if (e) try {
                let {
                    payload: t
                } = lr(e), n = null;
                t.aal && (n = t.aal);
                let r = n,
                    {
                        data: {
                            user: i
                        },
                        error: a
                    } = await this.getUser(e);
                if (a) return this._returnResult({
                    data: null,
                    error: a
                });
                ((i ?.factors) ?.filter(e => e.status === `verified`) ?? []).length > 0 && (r = `aal2`);
                let o = t.amr || [];
                return {
                    data: {
                        currentLevel: n,
                        nextLevel: r,
                        currentAuthenticationMethods: o
                    },
                    error: null
                }
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
            let {
                data: {
                    session: t
                },
                error: n
            } = await this.getSession();
            if (n) return this._returnResult({
                data: null,
                error: n
            });
            if (!t) return {
                data: {
                    currentLevel: null,
                    nextLevel: null,
                    currentAuthenticationMethods: []
                },
                error: null
            };
            let {
                payload: r
            } = lr(t.access_token), i = null;
            r.aal && (i = r.aal);
            let a = i;
            (t.user.factors ?.filter(e => e.status === `verified`) ?? []).length > 0 && (a = `aal2`);
            let o = r.amr || [];
            return {
                data: {
                    currentLevel: i,
                    nextLevel: a,
                    currentAuthenticationMethods: o
                },
                error: null
            }
        }
        async _getAuthorizationDetails(e) {
            try {
                return await this._useSession(async t => {
                    let {
                        data: {
                            session: n
                        },
                        error: r
                    } = t;
                    return r ? this._returnResult({
                        data: null,
                        error: r
                    }) : n ? await Y(this.fetch, `GET`, `${this.url}/oauth/authorizations/${e}`, {
                        headers: this.headers,
                        jwt: n.access_token,
                        xform: e => ({
                            data: e,
                            error: null
                        })
                    }) : this._returnResult({
                        data: null,
                        error: new R
                    })
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async _approveAuthorization(e, t) {
            try {
                return await this._useSession(async n => {
                    let {
                        data: {
                            session: r
                        },
                        error: i
                    } = n;
                    if (i) return this._returnResult({
                        data: null,
                        error: i
                    });
                    if (!r) return this._returnResult({
                        data: null,
                        error: new R
                    });
                    let a = await Y(this.fetch, `POST`, `${this.url}/oauth/authorizations/${e}/consent`, {
                        headers: this.headers,
                        jwt: r.access_token,
                        body: {
                            action: `approve`
                        },
                        xform: e => ({
                            data: e,
                            error: null
                        })
                    });
                    return a.data && a.data.redirect_url && B() && !t ?.skipBrowserRedirect && window.location.assign(a.data.redirect_url), a
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async _denyAuthorization(e, t) {
            try {
                return await this._useSession(async n => {
                    let {
                        data: {
                            session: r
                        },
                        error: i
                    } = n;
                    if (i) return this._returnResult({
                        data: null,
                        error: i
                    });
                    if (!r) return this._returnResult({
                        data: null,
                        error: new R
                    });
                    let a = await Y(this.fetch, `POST`, `${this.url}/oauth/authorizations/${e}/consent`, {
                        headers: this.headers,
                        jwt: r.access_token,
                        body: {
                            action: `deny`
                        },
                        xform: e => ({
                            data: e,
                            error: null
                        })
                    });
                    return a.data && a.data.redirect_url && B() && !t ?.skipBrowserRedirect && window.location.assign(a.data.redirect_url), a
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async _listOAuthGrants() {
            try {
                return await this._useSession(async e => {
                    let {
                        data: {
                            session: t
                        },
                        error: n
                    } = e;
                    return n ? this._returnResult({
                        data: null,
                        error: n
                    }) : t ? await Y(this.fetch, `GET`, `${this.url}/user/oauth/grants`, {
                        headers: this.headers,
                        jwt: t.access_token,
                        xform: e => ({
                            data: e,
                            error: null
                        })
                    }) : this._returnResult({
                        data: null,
                        error: new R
                    })
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async _revokeOAuthGrant(e) {
            try {
                return await this._useSession(async t => {
                    let {
                        data: {
                            session: n
                        },
                        error: r
                    } = t;
                    return r ? this._returnResult({
                        data: null,
                        error: r
                    }) : n ? (await Y(this.fetch, `DELETE`, `${this.url}/user/oauth/grants`, {
                        headers: this.headers,
                        jwt: n.access_token,
                        query: {
                            client_id: e.clientId
                        },
                        noResolveJson: !0
                    }), {
                        data: {},
                        error: null
                    }) : this._returnResult({
                        data: null,
                        error: new R
                    })
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async fetchJwk(e, t = {
            keys: []
        }) {
            let n = t.keys.find(t => t.kid === e);
            if (n) return n;
            let r = Date.now();
            if (n = this.jwks.keys.find(t => t.kid === e), n && this.jwks_cached_at + 6e5 > r) return n;
            let {
                data: i,
                error: a
            } = await Y(this.fetch, `GET`, `${this.url}/.well-known/jwks.json`, {
                headers: this.headers
            });
            if (a) throw a;
            return !i.keys || i.keys.length === 0 || (this.jwks = i, this.jwks_cached_at = r, n = i.keys.find(t => t.kid === e), !n) ? null : n
        }
        async getClaims(e, t = {}) {
            try {
                let n = e;
                if (!n) {
                    let {
                        data: e,
                        error: t
                    } = await this.getSession();
                    if (t || !e.session) return this._returnResult({
                        data: null,
                        error: t
                    });
                    n = e.session.access_token
                }
                let {
                    header: r,
                    payload: i,
                    signature: a,
                    raw: {
                        header: o,
                        payload: s
                    }
                } = lr(n);
                if (!t ?.allowExpired) try {
                    kr(i.exp)
                } catch (e) {
                    throw new Wn(e instanceof Error ? e.message : `JWT validation failed`)
                }
                let c = !r.alg || r.alg.startsWith(`HS`) || !r.kid || !(`crypto` in globalThis && `subtle` in globalThis.crypto) ? null : await this.fetchJwk(r.kid, t ?.keys ? {
                    keys: t.keys
                } : t ?.jwks);
                if (!c) {
                    let {
                        error: e
                    } = await this.getUser(n);
                    if (e) throw e;
                    return {
                        data: {
                            claims: i,
                            header: r,
                            signature: a
                        },
                        error: null
                    }
                }
                let l = Ar(r.alg),
                    u = await crypto.subtle.importKey(`jwk`, c, l, !0, [`verify`]);
                if (!await crypto.subtle.verify(l, u, a, tr(`${o}.${s}`))) throw new Wn(`Invalid JWT signature`);
                return {
                    data: {
                        claims: i,
                        header: r,
                        signature: a
                    },
                    error: null
                }
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async signInWithPasskey(e) {
            q(this.experimental);
            try {
                if (!ci()) return this._returnResult({
                    data: null,
                    error: new I(`Browser does not support WebAuthn`, null)
                });
                let {
                    data: t,
                    error: n
                } = await this._startPasskeyAuthentication({
                    options: {
                        captchaToken: e ?.options ?.captchaToken
                    }
                });
                if (n || !t) return this._returnResult({
                    data: null,
                    error: n
                });
                let {
                    data: r,
                    error: i
                } = await ui({
                    publicKey: ii(t.options),
                    signal: e ?.options ?.signal ?? ni.createNewAbortSignal()
                });
                if (i || !r) return this._returnResult({
                    data: null,
                    error: i ?? new I(`WebAuthn ceremony failed`, null)
                });
                let a = oi(r);
                return this._verifyPasskeyAuthentication({
                    challengeId: t.challenge_id,
                    credential: a
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async registerPasskey(e) {
            q(this.experimental);
            try {
                if (!ci()) return this._returnResult({
                    data: null,
                    error: new I(`Browser does not support WebAuthn`, null)
                });
                let {
                    data: t,
                    error: n
                } = await this._startPasskeyRegistration();
                if (n || !t) return this._returnResult({
                    data: null,
                    error: n
                });
                let {
                    data: r,
                    error: i
                } = await li({
                    publicKey: ri(t.options),
                    signal: e ?.options ?.signal ?? ni.createNewAbortSignal()
                });
                if (i || !r) return this._returnResult({
                    data: null,
                    error: i ?? new I(`WebAuthn ceremony failed`, null)
                });
                let a = ai(r);
                return this._verifyPasskeyRegistration({
                    challengeId: t.challenge_id,
                    credential: a
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async _startPasskeyRegistration() {
            q(this.experimental);
            try {
                return await this._useSession(async e => {
                    let {
                        data: {
                            session: t
                        },
                        error: n
                    } = e;
                    if (n) return this._returnResult({
                        data: null,
                        error: n
                    });
                    if (!t) return this._returnResult({
                        data: null,
                        error: new R
                    });
                    let {
                        data: r,
                        error: i
                    } = await Y(this.fetch, `POST`, `${this.url}/passkeys/registration/options`, {
                        headers: this.headers,
                        jwt: t.access_token,
                        body: {}
                    });
                    return i ? this._returnResult({
                        data: null,
                        error: i
                    }) : this._returnResult({
                        data: r,
                        error: null
                    })
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async _verifyPasskeyRegistration(e) {
            q(this.experimental);
            try {
                return await this._useSession(async t => {
                    let {
                        data: {
                            session: n
                        },
                        error: r
                    } = t;
                    if (r) return this._returnResult({
                        data: null,
                        error: r
                    });
                    if (!n) return this._returnResult({
                        data: null,
                        error: new R
                    });
                    let {
                        data: i,
                        error: a
                    } = await Y(this.fetch, `POST`, `${this.url}/passkeys/registration/verify`, {
                        headers: this.headers,
                        jwt: n.access_token,
                        body: {
                            challenge_id: e.challengeId,
                            credential: e.credential
                        }
                    });
                    return a ? this._returnResult({
                        data: null,
                        error: a
                    }) : this._returnResult({
                        data: i,
                        error: null
                    })
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async _startPasskeyAuthentication(e) {
            q(this.experimental);
            try {
                let {
                    data: t,
                    error: n
                } = await Y(this.fetch, `POST`, `${this.url}/passkeys/authentication/options`, {
                    headers: this.headers,
                    body: {
                        gotrue_meta_security: {
                            captcha_token: e ?.options ?.captchaToken
                        }
                    }
                });
                return n ? this._returnResult({
                    data: null,
                    error: n
                }) : this._returnResult({
                    data: t,
                    error: null
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async _verifyPasskeyAuthentication(e) {
            q(this.experimental);
            try {
                let {
                    data: t,
                    error: n
                } = await Y(this.fetch, `POST`, `${this.url}/passkeys/authentication/verify`, {
                    headers: this.headers,
                    body: {
                        challenge_id: e.challengeId,
                        credential: e.credential
                    },
                    xform: X
                });
                return n ? this._returnResult({
                    data: null,
                    error: n
                }) : (t.session && (await this._saveSession(t.session), await this._notifyAllSubscribers(`SIGNED_IN`, t.session)), this._returnResult({
                    data: t,
                    error: null
                }))
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async _listPasskeys() {
            q(this.experimental);
            try {
                return await this._useSession(async e => {
                    let {
                        data: {
                            session: t
                        },
                        error: n
                    } = e;
                    if (n) return this._returnResult({
                        data: null,
                        error: n
                    });
                    if (!t) return this._returnResult({
                        data: null,
                        error: new R
                    });
                    let {
                        data: r,
                        error: i
                    } = await Y(this.fetch, `GET`, `${this.url}/passkeys`, {
                        headers: this.headers,
                        jwt: t.access_token,
                        xform: e => ({
                            data: e,
                            error: null
                        })
                    });
                    return i ? this._returnResult({
                        data: null,
                        error: i
                    }) : this._returnResult({
                        data: r,
                        error: null
                    })
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async _updatePasskey(e) {
            q(this.experimental);
            try {
                return await this._useSession(async t => {
                    let {
                        data: {
                            session: n
                        },
                        error: r
                    } = t;
                    if (r) return this._returnResult({
                        data: null,
                        error: r
                    });
                    if (!n) return this._returnResult({
                        data: null,
                        error: new R
                    });
                    let {
                        data: i,
                        error: a
                    } = await Y(this.fetch, `PATCH`, `${this.url}/passkeys/${e.passkeyId}`, {
                        headers: this.headers,
                        jwt: n.access_token,
                        body: {
                            friendly_name: e.friendlyName
                        }
                    });
                    return a ? this._returnResult({
                        data: null,
                        error: a
                    }) : this._returnResult({
                        data: i,
                        error: null
                    })
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
        async _deletePasskey(e) {
            q(this.experimental);
            try {
                return await this._useSession(async t => {
                    let {
                        data: {
                            session: n
                        },
                        error: r
                    } = t;
                    if (r) return this._returnResult({
                        data: null,
                        error: r
                    });
                    if (!n) return this._returnResult({
                        data: null,
                        error: new R
                    });
                    let {
                        error: i
                    } = await Y(this.fetch, `DELETE`, `${this.url}/passkeys/${e.passkeyId}`, {
                        headers: this.headers,
                        jwt: n.access_token,
                        noResolveJson: !0
                    });
                    return i ? this._returnResult({
                        data: null,
                        error: i
                    }) : this._returnResult({
                        data: null,
                        error: null
                    })
                })
            } catch (e) {
                if (F(e)) return this._returnResult({
                    data: null,
                    error: e
                });
                throw e
            }
        }
    };
yi.nextInstanceID = {};
var bi = yi,
    xi = `2.112.2`,
    Si = ``,
    Ci;
if (typeof Deno < `u`) Si = `deno`, Ci = Deno.version ?.deno;
else if (typeof document < `u`) Si = `web`;
else if (typeof navigator < `u` && navigator.product === `ReactNative`) Si = `react-native`;
else {
    var wi;
    Si = `node`;
    let e = globalThis.process;
    Ci = e == null || (wi = e.version) == null ? void 0 : wi.replace(/^v/, ``)
}
var Ti = [`runtime=${Si}`];
Ci && Ti.push(`runtime-version=${Ci}`);
var Ei = {
        headers: {
            "X-Client-Info": `supabase-js/${xi}; ${Ti.join(`; `)}`
        }
    },
    Di = {
        schema: `public`
    },
    Oi = {
        autoRefreshToken: !0,
        persistSession: !0,
        detectSessionInUrl: !0,
        flowType: `implicit`
    },
    ki = {},
    Ai = {
        enabled: !1,
        respectSamplingDecision: !0
    };

function ji(e) {
    if (!e || typeof e != `string`) return null;
    let t = e.split(`-`);
    if (t.length !== 4) return null;
    let [n, r, i, a] = t;
    if (n.length !== 2 || r.length !== 32 || i.length !== 16 || a.length !== 2) return null;
    let o = /^[0-9a-f]+$/i;
    return !o.test(n) || !o.test(r) || !o.test(i) || !o.test(a) || r === `00000000000000000000000000000000` || i === `0000000000000000` ? null : {
        version: n,
        traceId: r,
        parentId: i,
        traceFlags: a,
        isSampled: (parseInt(a, 16) & 1) == 1
    }
}

function Mi(e, t) {
    if (!e || !t || t.length === 0) return !1;
    let n;
    if (e instanceof URL) n = e;
    else try {
        n = new URL(e)
    } catch {
        return !1
    }
    for (let e of t) try {
        if (typeof e == `string`) {
            if (Ni(n.hostname, e)) return !0
        } else if (e instanceof RegExp) {
            if (e.test(n.hostname)) return !0
        } else if (typeof e == `function` && e(n)) return !0
    } catch {
        continue
    }
    return !1
}

function Ni(e, t) {
    if (t === e) return !0;
    if (t.startsWith(`*.`)) {
        let n = t.slice(2);
        if (e.endsWith(n) && (e === n || e.endsWith(`.` + n))) return !0
    }
    return !1
}

function Pi(e) {
    let t = [];
    try {
        let n = new URL(e);
        t.push(n.hostname)
    } catch {}
    return t.push(`*.supabase.co`, `*.supabase.in`), t.push(`localhost`, `127.0.0.1`, `[::1]`), t
}

function Fi(e) {
    "@babel/helpers - typeof";
    return Fi = typeof Symbol == `function` && typeof Symbol.iterator == `symbol` ? function(e) {
        return typeof e
    } : function(e) {
        return e && typeof Symbol == `function` && e.constructor === Symbol && e !== Symbol.prototype ? `symbol` : typeof e
    }, Fi(e)
}

function Ii(e, t) {
    if (Fi(e) != `object` || !e) return e;
    var n = e[Symbol.toPrimitive];
    if (n !== void 0) {
        var r = n.call(e, t || `default`);
        if (Fi(r) != `object`) return r;
        throw TypeError(`@@toPrimitive must return a primitive value.`)
    }
    return (t === `string` ? String : Number)(e)
}

function Li(e) {
    var t = Ii(e, `string`);
    return Fi(t) == `symbol` ? t : t + ``
}

function Ri(e, t, n) {
    return (t = Li(t)) in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function zi(e, t) {
    var n = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t && (r = r.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable
        })), n.push.apply(n, r)
    }
    return n
}

function $(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] == null ? {} : arguments[t];
        t % 2 ? zi(Object(n), !0).forEach(function(t) {
            Ri(e, t, n[t])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : zi(Object(n)).forEach(function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
        })
    }
    return e
}
var Bi = e => e ? (...t) => e(...t) : (...e) => fetch(...e),
    Vi = () => Headers,
    Hi = e => e.startsWith(`sb_publishable_`) || e.startsWith(`sb_secret_`),
    Ui = `sb_temp_`,
    Wi = new Set,
    Gi = e => {
        if (!e.startsWith(`sb_`) || Hi(e) || e.startsWith(Ui)) return;
        let t = e.match(/^sb_[a-zA-Z0-9]+_/) ?.[0] ?? `unknown`;
        Wi.has(t) || (Wi.add(t), console.warn(`@supabase/supabase-js: Unrecognized Supabase API key format. The client will proceed and send this key as-is; if you see authentication errors you may need to upgrade @supabase/supabase-js to a version that recognizes this key type.`))
    },
    Ki = (e, t, n, r, i, a) => {
        let o = Bi(r),
            s = Vi(),
            c = i ?.enabled === !0,
            l = i ?.respectSamplingDecision !== !1,
            u = c ? Pi(t) : null,
            d = !(a ?.omitApiKeyAsBearer && Hi(e));
        return async (t, r) => {
            let i = await n(),
                a = new s(r ?.headers);
            if (a.has(`apikey`) || a.set(`apikey`, e), !a.has(`Authorization`)) {
                let t = i ?? (d ? e : null);
                t && a.set(`Authorization`, `Bearer ${t}`)
            }
            if (u) {
                let e = Ji(t, u, l);
                e && (e.traceparent && !a.has(`traceparent`) && a.set(`traceparent`, e.traceparent), e.tracestate && !a.has(`tracestate`) && a.set(`tracestate`, e.tracestate), e.baggage && !a.has(`baggage`) && a.set(`baggage`, e.baggage))
            }
            return o(t, $($({}, r), {}, {
                headers: a
            }))
        }
    },
    qi = !1;

function Ji(e, n, r) {
    let i = t();
    if (!i) return qi || (qi = !0, console.warn("@supabase/supabase-js: tracePropagation is enabled but the tracing runtime is not loaded, so trace headers will not be attached. Add `import '@supabase/supabase-js/tracing'` at your application entry point (requires the OpenTelemetry API package to be installed). The CDN/UMD build does not support trace propagation.")), null;
    if (!Mi(typeof e == `string` || e instanceof URL ? e : e.url, n)) return null;
    let a = i();
    if (!a || !a.traceparent) return null;
    if (r) {
        let e = ji(a.traceparent);
        if (e && !e.isSampled) return null
    }
    return a
}

function Yi(e) {
    return typeof e == `boolean` ? {
        enabled: e
    } : e
}

function Xi(e) {
    return e.endsWith(`/`) ? e : e + `/`
}

function Zi(e, t) {
    let {
        db: n,
        auth: r,
        realtime: i,
        global: a
    } = e, {
        db: o,
        auth: s,
        realtime: c,
        global: l
    } = t, u = Yi(e.tracePropagation), d = Yi(t.tracePropagation), f = {
        db: $($({}, o), n),
        auth: $($({}, s), r),
        realtime: $($({}, c), i),
        storage: {},
        global: $($($({}, l), a), {}, {
            headers: $($({}, l ?.headers ?? {}), a ?.headers ?? {})
        }),
        tracePropagation: {
            enabled: u ?.enabled ?? d ?.enabled ?? !1,
            respectSamplingDecision: u ?.respectSamplingDecision ?? d ?.respectSamplingDecision ?? !0
        },
        accessToken: async () => ``
    };
    return e.accessToken ? f.accessToken = e.accessToken : delete f.accessToken, f
}

function Qi(e) {
    let t = e ?.trim();
    if (!t) throw Error(`supabaseUrl is required.`);
    if (!t.match(/^https?:\/\//i)) throw Error(`Invalid supabaseUrl: Must be a valid HTTP or HTTPS URL.`);
    try {
        return new URL(Xi(t))
    } catch {
        throw Error(`Invalid supabaseUrl: Provided URL is malformed.`)
    }
}
var $i = class extends bi {
        constructor(e) {
            super(e)
        }
    },
    ea = class {
        constructor(e, t, n) {
            this.supabaseUrl = e, this.supabaseKey = t;
            let r = Qi(e);
            if (!t) throw Error(`supabaseKey is required.`);
            Gi(t), this.realtimeUrl = new URL(`realtime/v1`, r), this.realtimeUrl.protocol = this.realtimeUrl.protocol.replace(`http`, `ws`), this.authUrl = new URL(`auth/v1`, r), this.storageUrl = new URL(`storage/v1`, r), this.functionsUrl = new URL(`functions/v1`, r);
            let i = `sb-${r.hostname.split(`.`)[0]}-auth-token`,
                a = {
                    db: Di,
                    realtime: ki,
                    auth: $($({}, Oi), {}, {
                        storageKey: i
                    }),
                    global: Ei,
                    tracePropagation: Ai
                },
                o = Zi(n ?? {}, a);
            this.settings = o, this.storageKey = o.auth.storageKey ?? ``, this.headers = o.global.headers ?? {}, o.accessToken ? (this.accessToken = o.accessToken, this.auth = new Proxy({}, {
                get: (e, t) => {
                    throw Error(`@supabase/supabase-js: Supabase Client is configured with the accessToken option, accessing supabase.auth.${String(t)} is not possible`)
                }
            })) : this.auth = this._initSupabaseAuthClient(o.auth ?? {}, this.headers, o.global.fetch), this.fetch = Ki(t, e, this._getSessionToken.bind(this), o.global.fetch, o.tracePropagation), this.functionsFetch = Ki(t, e, this._getSessionToken.bind(this), o.global.fetch, o.tracePropagation, {
                omitApiKeyAsBearer: !0
            }), this.realtime = this._initRealtimeClient($({
                headers: this.headers,
                accessToken: this._getAccessToken.bind(this),
                fetch: this.fetch
            }, o.realtime)), this.accessToken && Promise.resolve(this.accessToken()).then(e => this.realtime.setAuth(e)).catch(e => console.warn(`Failed to set initial Realtime auth token:`, e)), this.rest = new ue(new URL(`rest/v1`, r).href, {
                headers: this.headers,
                schema: o.db.schema,
                fetch: this.fetch,
                timeout: o.db.timeout,
                urlLengthLimit: o.db.urlLengthLimit,
                retry: o.db.retry
            }), this.storage = new vn(this.storageUrl.href, this.headers, this.fetch, n ?.storage), o.accessToken || this._listenForAuthEvents()
        }
        get functions() {
            return new f(this.functionsUrl.href, {
                headers: this.headers,
                customFetch: this.functionsFetch
            })
        }
        from(e) {
            return this.rest.from(e)
        }
        schema(e) {
            return this.rest.schema(e)
        }
        rpc(e, t = {}, n = {
            head: !1,
            get: !1,
            count: void 0
        }) {
            return this.rest.rpc(e, t, n)
        }
        channel(e, t = {
            config: {}
        }) {
            return this.realtime.channel(e, t)
        }
        getChannels() {
            return this.realtime.getChannels()
        }
        removeChannel(e) {
            return this.realtime.removeChannel(e)
        }
        removeAllChannels() {
            return this.realtime.removeAllChannels()
        }
        async _getSessionToken() {
            var e = this;
            if (e.accessToken) return await e.accessToken();
            let {
                data: t
            } = await e.auth.getSession();
            return t.session ?.access_token ?? null
        }
        async _getAccessToken() {
            var e = this;
            return await e._getSessionToken() ?? e.supabaseKey
        }
        _initSupabaseAuthClient({
            autoRefreshToken: e,
            persistSession: t,
            detectSessionInUrl: n,
            storage: r,
            userStorage: i,
            storageKey: a,
            flowType: o,
            lock: s,
            debug: c,
            throwOnError: l,
            experimental: u,
            lockAcquireTimeout: d,
            skipAutoInitialize: f
        }, p, m) {
            let h = {
                Authorization: `Bearer ${this.supabaseKey}`,
                apikey: `${this.supabaseKey}`
            };
            return new $i({
                url: this.authUrl.href,
                headers: $($({}, h), p),
                storageKey: a,
                autoRefreshToken: e,
                persistSession: t,
                detectSessionInUrl: n,
                storage: r,
                userStorage: i,
                flowType: o,
                lock: s,
                debug: c,
                throwOnError: l,
                experimental: u,
                fetch: m,
                lockAcquireTimeout: d,
                skipAutoInitialize: f,
                hasCustomAuthorizationHeader: Object.keys(this.headers).some(e => e.toLowerCase() === `authorization`)
            })
        }
        _initRealtimeClient(e) {
            return new bt(this.realtimeUrl.href, $($({}, e), {}, {
                params: $($({}, {
                    apikey: this.supabaseKey
                }), e ?.params)
            }))
        }
        _listenForAuthEvents() {
            return this.auth.onAuthStateChange((e, t) => {
                this._handleTokenChanged(e, `CLIENT`, t ?.access_token)
            })
        }
        _handleTokenChanged(e, t, n) {
            (e === `TOKEN_REFRESHED` || e === `SIGNED_IN` || e === `INITIAL_SESSION`) && this.changedAccessToken !== n ? (this.changedAccessToken = n, this.realtime.setAuth(n)) : e === `SIGNED_OUT` && (this.realtime.setAuth(), t == `STORAGE` && this.auth.signOut(), this.changedAccessToken = void 0)
        }
    },
    ta = (e, t, n) => new ea(e, t, n);

function na() {
    if (typeof window < `u` || globalThis.Deno !== void 0) return !1;
    let e = globalThis.process;
    if (!e) return !1;
    let t = e.version;
    if (t == null) return !1;
    let n = t.match(/^v(\d+)\./);
    return n ? parseInt(n[1], 10) <= 20 : !1
}
na() && console.warn(`⚠️  Node.js 20 and below are deprecated and will no longer be supported in future versions of @supabase/supabase-js. Please upgrade to Node.js 22 or later. For more information, visit: https://github.com/orgs/supabase/discussions/45715`);

function ra() {
    if (typeof window > `u`) return;
    let e = location.hostname,
        t = [`lovableproject.com`, `lovableproject-dev.com`, `lovable.app`, `gpt-eng.com`, `gptengineer.run`].some(t => e === t || e.endsWith(`.` + t)) ? e.match(RegExp(`^(?:id-preview(?:-[a-z0-9]+)?|project)--([0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})(?:-dev)?(?=\\.|$)`, `i`)) ?.[1] ?? e.match(RegExp(`^([0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})(?=[.-])`, `i`)) ?.[1] : void 0,
        n = window.parent && window.parent !== window;
    if (!t || !n) return localStorage;
    let r = e.endsWith(`.lovableproject-dev.com`) || e.endsWith(`.gpt-eng.com`),
        i = r ? /^https:\/\/([a-z0-9-]+\.)*(lovable\.dev|gptengineer\.app)$|^http:\/\/localhost:3000$/ : /^https:\/\/([a-z0-9-]+\.)*(lovable\.dev|gptengineer\.app)$/,
        a = location.ancestorOrigins && location.ancestorOrigins[0] || (document.referrer ? new URL(document.referrer).origin : ``),
        o = a && i.test(a) ? [a] : r ? [`https://lovable.dev`, `http://localhost:3000`] : [`https://lovable.dev`],
        s = () => Math.random().toString(36).slice(2) + Date.now().toString(36),
        c = (e, n, r) => new Promise(i => {
            let a = s(),
                c = !1,
                l, u = e => {
                    c || (c = !0, clearTimeout(l), window.removeEventListener(`message`, d), i(e))
                },
                d = e => {
                    if (o.indexOf(e.origin) < 0) return;
                    let t = e.data;
                    t && t.type === `lovable-preview-auth:result` && t.requestId === a && u(t)
                };
            window.addEventListener(`message`, d);
            let f = {
                type: e,
                requestId: a,
                projectId: t,
                key: n
            };
            r !== void 0 && (f.value = r);
            for (let e of o) window.parent.postMessage(f, e);
            l = setTimeout(() => u(null), 2e3)
        }),
        l = !0;
    return {
        getItem: async e => {
            let t = await c(`lovable-preview-auth:get`, e);
            return !t && l && (await new Promise(e => setTimeout(e, 250)), t = await c(`lovable-preview-auth:get`, e)), l = !1, t && t.ok && typeof t.value == `string` ? t.value === `` ? (localStorage.removeItem(e), null) : t.value : localStorage.getItem(e)
        },
        setItem: (e, t) => (localStorage.setItem(e, t), c(`lovable-preview-auth:set`, e, t).then(n => {
            n && n.ok && typeof n.value == `string` && localStorage.getItem(e) === t && (n.value === `` ? localStorage.removeItem(e) : localStorage.setItem(e, n.value))
        })),
        removeItem: e => (localStorage.removeItem(e), c(`lovable-preview-auth:remove`, e).then(() => void 0))
    }
}
var ia = `https://bpqnwqdxvrsaamckwcng.supabase.co`,
    aa = `sb_publishable_BQad07hnyQQOoS9ZURAKow_SyHRzbn6`;

function oa(e) {
    return e.startsWith(`sb_publishable_`) || e.startsWith(`sb_secret_`)
}

function sa(e) {
    return (t, n) => {
        let r = new Headers(typeof Request < `u` && t instanceof Request ? t.headers : void 0);
        return n ?.headers && new Headers(n.headers).forEach((e, t) => r.set(t, e)), oa(e) && r.get(`Authorization`) === `Bearer ${e}` && r.delete(`Authorization`), r.set(`apikey`, e), fetch(t, { ...n,
            headers: r
        })
    }
}
var ca = ta(ia, aa, {
    global: {
        fetch: sa(aa)
    },
    auth: {
        storage: ra(),
        persistSession: !0,
        autoRefreshToken: !0
    }
});
export {
    a as i, n, r, ca as t
};