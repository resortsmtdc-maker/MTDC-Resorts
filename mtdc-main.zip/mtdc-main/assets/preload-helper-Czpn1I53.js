var e = function(e) {
        return `/` + e
    },
    t = {},
    n = function(n, r, i) {
        let a = Promise.resolve();
        if (r && r.length > 0) {
            let n = document.getElementsByTagName(`link`),
                o = document.querySelector(`meta[property=csp-nonce]`),
                s = o ?.nonce || o ?.getAttribute(`nonce`);

            function c(e) {
                return Promise.all(e.map(e => Promise.resolve(e).then(e => ({
                    status: `fulfilled`,
                    value: e
                }), e => ({
                    status: `rejected`,
                    reason: e
                }))))
            }

            function l(e) {
                return import.meta.resolve ?
                    import.meta.resolve(e) : new URL(e,
                        import.meta.url).href
            }
            a = c(r.map(r => {
                if (r = e(r, i), r = l(r), r in t) return;
                t[r] = !0;
                let a = r.endsWith(`.css`);
                for (let e = n.length - 1; e >= 0; e--) {
                    let t = n[e];
                    if (t.href === r && (!a || t.rel === `stylesheet`)) return
                }
                let o = document.createElement(`link`);
                if (o.rel = a ? `stylesheet` : `modulepreload`, a || (o.as = `script`), o.crossOrigin = ``, o.href = r, s && o.setAttribute(`nonce`, s), document.head.appendChild(o), a) return new Promise((e, t) => {
                    o.addEventListener(`load`, e), o.addEventListener(`error`, () => t(Error(`Unable to preload CSS for ${r}`)))
                })
            }))
        }

        function o(e) {
            let t = new Event(`vite:preloadError`, {
                cancelable: !0
            });
            if (t.payload = e, window.dispatchEvent(t), !t.defaultPrevented) throw e
        }
        return a.then(e => {
            for (let t of e || []) t.status === `rejected` && o(t.reason);
            return n().catch(o)
        })
    };
export {
    n as t
};