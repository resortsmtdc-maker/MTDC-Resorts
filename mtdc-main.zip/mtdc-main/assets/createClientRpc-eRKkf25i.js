import {
    K as e,
    x as t
} from "./router-compat-DVALc1LS.js";
var n = `__TSS_CONTEXT`,
    r = Symbol.for(`TSS_SERVER_FUNCTION`),
    i = Symbol.for(`TSS_SERVER_FUNCTION_FACTORY`),
    a = `application/x-tss-framed`;
`${a}`;
var o = () => window.__TSS_START_OPTIONS__;

function s(e) {
    e.statusCode = e.statusCode || e.code || 307;
    let t = new Headers(e.headers);
    e.href && t.get(`Location`) === null && t.set(`Location`, e.href);
    let n = new Response(null, {
        status: e.statusCode,
        headers: t
    });
    if (n.options = e, e.throw) throw n;
    return n
}

function c(e) {
    return e instanceof Response && !!e.options
}

function l(e) {
    if (typeof e == `object` && e && e.isSerializedRedirect) return s(e)
}

function u(e, t = String) {
    let n;
    for (let r in e) {
        let i = e[r];
        i !== void 0 && (n ||= new URLSearchParams).set(r, t(i))
    }
    return n ? n.toString() : ``
}

function d(e) {
    return e ? e === `false` ? !1 : e === `true` ? !0 : e * 0 == 0 && +e + `` === e ? +e : e : ``
}

function f(e) {
    let t = new URLSearchParams(e),
        n = Object.create(null);
    for (let [e, r] of t.entries()) {
        let t = n[e];
        t == null ? n[e] = d(r) : Array.isArray(t) ? t.push(d(r)) : n[e] = [t, d(r)]
    }
    return n
}
var p = Symbol.asyncIterator,
    ee = Symbol.hasInstance,
    m = Symbol.isConcatSpreadable,
    h = Symbol.iterator,
    te = Symbol.match,
    ne = Symbol.matchAll,
    re = Symbol.replace,
    ie = Symbol.search,
    ae = Symbol.species,
    oe = Symbol.split,
    se = Symbol.toPrimitive,
    g = Symbol.toStringTag,
    ce = Symbol.unscopables,
    le = {
        [p]: 0,
        [ee]: 1,
        [m]: 2,
        [h]: 3,
        [te]: 4,
        [ne]: 5,
        [re]: 6,
        [ie]: 7,
        [ae]: 8,
        [oe]: 9,
        [se]: 10,
        [g]: 11,
        [ce]: 12
    },
    ue = {
        0: p,
        1: ee,
        2: m,
        3: h,
        4: te,
        5: ne,
        6: re,
        7: ie,
        8: ae,
        9: oe,
        10: se,
        11: g,
        12: ce
    },
    de = {
        2: !0,
        3: !1,
        1: void 0,
        0: null,
        4: -0,
        5: 1 / 0,
        6: -1 / 0,
        7: NaN
    },
    fe = {
        0: `Error`,
        1: `EvalError`,
        2: `RangeError`,
        3: `ReferenceError`,
        4: `SyntaxError`,
        5: `TypeError`,
        6: `URIError`
    },
    pe = {
        0: Error,
        1: EvalError,
        2: RangeError,
        3: ReferenceError,
        4: SyntaxError,
        5: TypeError,
        6: URIError
    };

function _(e, t, n, r, i, a, o, s, c, l, u, d) {
    return {
        t: e,
        i: t,
        s: n,
        c: r,
        m: i,
        p: a,
        e: o,
        a: s,
        f: c,
        b: l,
        o: u,
        l: d
    }
}

function v(e) {
    return _(2, void 0, e, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0)
}
var me = v(2),
    he = v(3),
    ge = v(1),
    _e = v(0),
    ve = v(4),
    ye = v(5),
    be = v(6),
    xe = v(7),
    Se = 64,
    Ce = /[\x00-\x07\x0b\x0e-\x1f<\u2028\u2029\ud800-\udfff]/;

function we(e) {
    switch (e) {
        case `"`:
            return `\\"`;
        case `\\`:
            return `\\\\`;
        case `
`:
            return `\\n`;
        case `\r`:
            return `\\r`;
        case `\b`:
            return `\\b`;
        case `	`:
            return `\\t`;
        case `\f`:
            return `\\f`;
        case `<`:
            return `\\x3C`;
        case `\u2028`:
            return `\\u2028`;
        case `\u2029`:
            return `\\u2029`;
        default:
            return
    }
}

function y(e) {
    if (e.length >= Se && !Ce.test(e)) return JSON.stringify(e).slice(1, -1);
    let t = ``,
        n = 0,
        r;
    for (let i = 0, a = e.length; i < a; i++) r = we(e[i]), r && (t += e.slice(n, i) + r, n = i + 1);
    return n === 0 ? t = e : t += e.slice(n), t
}

function Te(e) {
    switch (e) {
        case `\\\\`:
            return `\\`;
        case `\\"`:
            return `"`;
        case `\\n`:
            return `
`;
        case `\\r`:
            return `\r`;
        case `\\b`:
            return `\b`;
        case `\\t`:
            return `	`;
        case `\\f`:
            return `\f`;
        case `\\x3C`:
            return `<`;
        case `\\u2028`:
            return `\u2028`;
        case `\\u2029`:
            return `\u2029`;
        default:
            return e
    }
}

function b(e) {
    return typeof e == `string` && !e.includes(`\\`) ? e : e.replace(/(\\\\|\\"|\\n|\\r|\\b|\\t|\\f|\\u2028|\\u2029|\\x3C)/g, Te)
}
var {
    toString: Ee
} = Object.prototype, De = {
    parsing: 1,
    serialization: 2,
    deserialization: 3
};

function Oe(e) {
    return `Seroval Error (step: ${De[e]})`
}
var ke = (e, t) => Oe(e),
    Ae = class extends Error {
        constructor(e, t) {
            super(ke(e, t)), this.cause = t
        }
    },
    je = class extends Ae {
        constructor(e) {
            super(`parsing`, e)
        }
    },
    Me = class extends Ae {
        constructor(e) {
            super(`deserialization`, e)
        }
    };

function x(e) {
    return `Seroval Error (specific: ${e})`
}
var S = class extends Error {
        constructor(e) {
            super(x(1)), this.value = e
        }
    },
    Ne = class extends Error {
        constructor(e) {
            super(x(2))
        }
    },
    Pe = class extends Error {
        constructor(e) {
            super(x(3))
        }
    },
    C = class extends Error {
        constructor(e) {
            super(x(4))
        }
    },
    Fe = class extends Error {
        constructor(e) {
            super(x(5)), this.value = e
        }
    },
    Ie = class extends Error {
        constructor(e) {
            super(x(6))
        }
    },
    Le = class extends Error {
        constructor(e) {
            super(x(7))
        }
    },
    w = class extends Error {
        constructor(e) {
            super(x(8))
        }
    },
    Re = class extends Error {
        constructor(e) {
            super(x(9))
        }
    },
    T = `__SEROVAL_REFS__`,
    ze = new Map,
    E = new Map;

function Be(e) {
    return ze.has(e)
}

function Ve(e) {
    return E.has(e)
}

function He(e) {
    if (Be(e)) return ze.get(e);
    throw new Fe(e)
}

function Ue(e) {
    if (Ve(e)) return E.get(e);
    throw new Ie(e)
}
typeof globalThis < `u` ? Object.defineProperty(globalThis, T, {
    value: E,
    configurable: !0,
    writable: !1,
    enumerable: !1
}) : typeof window < `u` ? Object.defineProperty(window, T, {
    value: E,
    configurable: !0,
    writable: !1,
    enumerable: !1
}) : typeof self < `u` ? Object.defineProperty(self, T, {
    value: E,
    configurable: !0,
    writable: !1,
    enumerable: !1
}) : typeof global < `u` && Object.defineProperty(global, T, {
    value: E,
    configurable: !0,
    writable: !1,
    enumerable: !1
});

function We(e) {
    return e instanceof EvalError ? 1 : e instanceof RangeError ? 2 : e instanceof ReferenceError ? 3 : e instanceof SyntaxError ? 4 : e instanceof TypeError ? 5 : e instanceof URIError ? 6 : 0
}

function Ge(e) {
    let t = fe[We(e)];
    return e.name === t ? e.constructor.name === t ? {} : {
        name: e.constructor.name
    } : {
        name: e.name
    }
}

function Ke(e, t) {
    let n = Ge(e),
        r = Object.getOwnPropertyNames(e);
    for (let i = 0, a = r.length, o; i < a; i++) o = r[i], o !== `name` && o !== `message` && (o === `stack` ? t & 4 && (n ||= {}, n[o] = e[o]) : (n ||= {}, n[o] = e[o]));
    return n
}

function qe(e) {
    return Object.isFrozen(e) ? 3 : Object.isSealed(e) ? 2 : +!Object.isExtensible(e)
}

function Je(e) {
    switch (e) {
        case 1 / 0:
            return ye;
        case -1 / 0:
            return be
    }
    return e === e ? Object.is(e, -0) ? ve : _(0, void 0, e, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0) : xe
}

function Ye(e) {
    return _(1, void 0, y(e), void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0)
}

function Xe(e) {
    return _(3, void 0, `` + e, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0)
}

function Ze(e) {
    return _(4, e, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0)
}

function Qe(e, t) {
    let n = t.valueOf();
    return _(5, e, n === n ? t.toISOString() : ``, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0)
}

function D(e, t, n) {
    return _(36, e, n.toString(), t, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0)
}

function $e(e, t) {
    return _(6, e, void 0, y(t.source), t.flags, void 0, void 0, void 0, void 0, void 0, void 0, void 0)
}

function et(e, t) {
    return _(17, e, le[t], void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0)
}

function tt(e, t) {
    return _(18, e, y(He(t)), void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0)
}

function nt(e, t, n) {
    return _(25, e, n, y(t), void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0)
}

function rt(e, t, n) {
    return _(9, e, void 0, void 0, void 0, void 0, void 0, n, void 0, void 0, qe(t), void 0)
}

function it(e, t) {
    return _(21, e, void 0, void 0, void 0, void 0, void 0, void 0, t, void 0, void 0, void 0)
}
var at = 1e6;

function ot(e, t, n) {
    if (t.length > at) throw new S(t);
    return _(15, e, void 0, t.constructor.name, void 0, void 0, void 0, void 0, n, t.byteOffset, void 0, t.length)
}

function st(e, t, n) {
    if (t.length > at) throw new S(t);
    return _(16, e, void 0, t.constructor.name, void 0, void 0, void 0, void 0, n, t.byteOffset, void 0, t.length)
}

function ct(e, t, n) {
    if (t.byteLength > at) throw new S(t);
    return _(20, e, void 0, void 0, void 0, void 0, void 0, void 0, n, t.byteOffset, void 0, t.byteLength)
}

function lt(e, t, n) {
    return _(13, e, We(t), void 0, y(t.message), n, void 0, void 0, void 0, void 0, void 0, void 0)
}

function ut(e, t, n) {
    return _(14, e, We(t), void 0, y(t.message), n, void 0, void 0, void 0, void 0, void 0, void 0)
}

function dt(e, t) {
    return _(7, e, void 0, void 0, void 0, void 0, void 0, t, void 0, void 0, void 0, void 0)
}

function ft(e, t) {
    return _(28, void 0, void 0, void 0, void 0, void 0, void 0, [e, t], void 0, void 0, void 0, void 0)
}

function pt(e, t) {
    return _(30, void 0, void 0, void 0, void 0, void 0, void 0, [e, t], void 0, void 0, void 0, void 0)
}

function mt(e, t, n) {
    return _(31, e, void 0, void 0, void 0, void 0, void 0, n, t, void 0, void 0, void 0)
}

function ht(e, t) {
    return _(32, e, void 0, void 0, void 0, void 0, void 0, void 0, t, void 0, void 0, void 0)
}

function gt(e, t) {
    return _(33, e, void 0, void 0, void 0, void 0, void 0, void 0, t, void 0, void 0, void 0)
}

function _t(e, t) {
    return _(34, e, void 0, void 0, void 0, void 0, void 0, void 0, t, void 0, void 0, void 0)
}

function vt(e, t, n, r) {
    return _(35, e, n, void 0, void 0, void 0, void 0, t, void 0, void 0, void 0, r)
}
var yt = class {
        constructor(e, t) {
            this.value = e, this.replacement = t
        }
    },
    bt = () => {
        let e = {
            p: 0,
            s: 0,
            f: 0
        };
        return e.p = new Promise((t, n) => {
            e.s = t, e.f = n
        }), e
    },
    xt = e => t => () => {
        let n = 0,
            r = {
                [e]() {
                    return r
                },
                next() {
                    if (n > t.d) return {
                        done: !0,
                        value: void 0
                    };
                    let e = n++,
                        r = t.v[e];
                    if (e === t.t) throw r;
                    return {
                        done: e === t.d,
                        value: r
                    }
                }
            };
        return r
    },
    St = (e, t) => n => () => {
        let r = 0,
            i = -1,
            a = !1,
            o = [],
            s = [],
            c = {
                finalize(e = 0, t = s.length) {
                    for (; e < t; e++) s[e].s({
                        done: !0,
                        value: void 0
                    })
                }
            };
        n.on({
            next(e) {
                let t = s.shift();
                t && t.s({
                    done: !1,
                    value: e
                }), o.push(e)
            },
            throw (e) {
                let t = s.shift();
                t && t.f(e), c.finalize(), i = o.length, a = !0, o.push(e)
            },
            return (e) {
                let t = s.shift();
                t && t.s({
                    done: !0,
                    value: e
                }), c.finalize(), i = o.length, o.push(e)
            }
        });
        let l = {
            [e]() {
                return l
            },
            next() {
                if (i === -1) {
                    let e = r++;
                    if (e >= o.length) {
                        let e = t();
                        return s.push(e), e.p
                    }
                    return {
                        done: !1,
                        value: o[e]
                    }
                }
                if (r > i) return {
                    done: !0,
                    value: void 0
                };
                let e = r++,
                    n = o[e];
                if (e !== i) return {
                    done: !1,
                    value: n
                };
                if (a) throw n;
                return {
                    done: !0,
                    value: n
                }
            }
        };
        return l
    },
    Ct = e => {
        let t = atob(e),
            n = t.length,
            r = new Uint8Array(n);
        for (let e = 0; e < n; e++) r[e] = t.charCodeAt(e);
        return r.buffer
    },
    wt = class {
        constructor(e, t, n) {
            this.v = e, this.t = t, this.d = n
        }
    };

function Tt(e) {
    return e instanceof wt
}

function Et(e, t, n) {
    return new wt(e, t, n)
}

function Dt(e) {
    let t = [],
        n = -1,
        r = -1,
        i = e[h]();
    for (;;) try {
        let e = i.next();
        if (t.push(e.value), e.done) {
            r = t.length - 1;
            break
        }
    } catch (e) {
        n = t.length, r = n, t.push(e);
        break
    }
    return Et(t, n, r)
}
var Ot = xt(h);

function kt(e) {
    return Ot(e)
}
var At = {},
    jt = {},
    Mt = {
        0: {},
        1: {},
        2: {},
        3: {},
        4: {},
        5: {}
    };

function Nt(e, t) {
    if (t.has(e)) throw TypeError(`Cannot initialize the same private elements twice on an object`)
}

function Pt(e, t) {
    Nt(e, t), t.add(e)
}

function O(e, t, n) {
    Nt(e, t), t.set(e, n)
}

function k(e, t, n) {
    if (typeof e == `function` ? e === t : e.has(t)) return arguments.length < 3 ? t : n;
    throw TypeError(`Private element is not present on this object`)
}

function A(e, t) {
    return e.get(k(e, t))
}

function j(e, t, n) {
    return e.set(k(e, t), n), n
}
var M = new WeakMap,
    N = new WeakMap,
    P = new WeakMap,
    F = new WeakMap,
    I = new WeakMap,
    L = new WeakSet,
    Ft = class {
        constructor() {
            Pt(this, L), O(this, M, []), O(this, N, []), O(this, P, !0), O(this, F, !1), O(this, I, 0)
        }
        on(e) {
            let t = A(P, this),
                n = 0;
            if (t) {
                for (; n < A(I, this) && A(N, this)[n]; n++);
                if (n === A(I, this)) {
                    var r;
                    j(I, this, (r = A(I, this), r++, r))
                }
                A(N, this)[n] = e
            }
            return k(L, this, It).call(this, e), () => {
                if (A(P, this) && t) {
                    for (t = !1, A(N, this)[n] = void 0; A(I, this) > 0 && !A(N, this)[A(I, this) - 1];) {
                        var e;
                        j(I, this, (e = A(I, this), e--, e))
                    }
                    A(N, this).length = A(I, this)
                }
            }
        }
        next(e) {
            A(P, this) && (A(M, this).push(e), k(L, this, R).call(this, e, `next`))
        }
        throw (e) {
            A(P, this) && (A(M, this).push(e), k(L, this, R).call(this, e, `throw`), j(P, this, !1), j(F, this, !1), A(N, this).length = 0)
        }
        return (e) {
            A(P, this) && (A(M, this).push(e), k(L, this, R).call(this, e, `return`), j(P, this, !1), j(F, this, !0), A(N, this).length = 0)
        }
    };

function R(e, t) {
    for (let r = 0; r < A(I, this); r++) {
        var n;
        (n = A(N, this)[r]) == null || n[t](e)
    }
}

function It(e) {
    for (let t = 0, n = A(M, this).length; t < n; t++) {
        let r = A(M, this)[t];
        !A(P, this) && t === n - 1 ? e[A(F, this) ? `return` : `throw`](r) : e.next(r)
    }
}

function z(e) {
    return e instanceof Ft
}

function B() {
    return new Ft
}

function Lt(e, t) {
    let n = B(),
        r = e[p](),
        i = !1,
        a = !1;
    t ?.push(() => {
        a || i || (i = !0, Promise.resolve().then(() => r.return ?.call(r)).catch(() => {}))
    });
    async function o() {
        try {
            for (; !i;) {
                let e = await r.next();
                if (i) return;
                if (e.done) {
                    a = !0, n.return(e.value);
                    break
                }
                n.next(e.value)
            }
        } catch (e) {
            a = !0, i || n.throw(e)
        }
    }
    return o().catch(() => {}), n
}
var Rt = St(p, bt);

function zt(e) {
    return Rt(e)
}
async function Bt(e) {
    try {
        return [1, await e]
    } catch (e) {
        return [0, e]
    }
}

function Vt(e, t) {
    return {
        plugins: t.plugins,
        mode: e,
        marked: new Set,
        features: 127 ^ (t.disabledFeatures || 0),
        refs: t.refs || new Map,
        depthLimit: t.depthLimit || 1e3,
        compactArrayBufferViews: t.compactArrayBufferViews ?? !1
    }
}

function V(e, t) {
    e.marked.add(t)
}

function Ht(e, t) {
    let n = e.refs.size;
    return e.refs.set(t, n), n
}

function H(e, t) {
    let n = e.refs.get(t);
    return n == null ? {
        type: 0,
        value: Ht(e, t)
    } : (V(e, n), {
        type: 1,
        value: Ze(n)
    })
}

function Ut(e, t) {
    let n = H(e, t);
    return n.type === 1 ? n : Be(t) ? {
        type: 2,
        value: tt(n.value, t)
    } : n
}

function U(e, t) {
    let n = Ut(e, t);
    if (n.type !== 0) return n.value;
    if (t in le) return et(n.value, t);
    throw new S(t)
}

function W(e, t) {
    let n = H(e, Mt[t]);
    return n.type === 1 ? n.value : _(26, n.value, t, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0, void 0)
}

function Wt(e) {
    let t = H(e, At);
    return t.type === 1 ? t.value : _(27, t.value, void 0, void 0, void 0, void 0, void 0, void 0, U(e, h), void 0, void 0, void 0)
}

function Gt(e) {
    let t = H(e, jt);
    return t.type === 1 ? t.value : _(29, t.value, void 0, void 0, void 0, void 0, void 0, [W(e, 1), U(e, p)], void 0, void 0, void 0, void 0)
}

function Kt(e, t, n, r) {
    return _(n ? 11 : 10, e, void 0, void 0, void 0, r, void 0, void 0, void 0, void 0, qe(t), void 0)
}

function qt(e, t, n, r) {
    return _(8, t, void 0, void 0, void 0, void 0, {
        k: n,
        v: r
    }, void 0, W(e, 0), void 0, void 0, void 0)
}

function Jt(e, t) {
    if (!e.compactArrayBufferViews) return t;
    let n = new Uint8Array(t.buffer, t.byteOffset, t.byteLength).slice().buffer,
        r = t.constructor;
    return new r(n)
}

function Yt(e) {
    if (typeof Buffer < `u`) return Buffer.from(e).toString(`base64`);
    let t = new Uint8Array(e);
    if (typeof t.toBase64 == `function`) return t.toBase64();
    let n = ``;
    for (let e = 0, r = t.length; e < r; e++) n += String.fromCharCode(t[e]);
    return btoa(n)
}

function Xt(e, t, n) {
    return _(19, t, Yt(n), void 0, void 0, void 0, void 0, void 0, W(e, 5), void 0, void 0, void 0)
}

function Zt(e, t) {
    return {
        base: Vt(e, t),
        child: void 0
    }
}
var Qt = class {
    constructor(e, t) {
        this._p = e, this.depth = t
    }
    parse(e) {
        return G(this._p, this.depth, e)
    }
};
async function $t(e, t, n) {
    let r = [];
    for (let i = 0, a = n.length; i < a; i++) i in n ? r[i] = await G(e, t, n[i]) : r[i] = 0;
    return r
}
async function en(e, t, n, r) {
    return rt(n, r, await $t(e, t, r))
}
async function tn(e, t, n) {
    let r = Object.entries(n),
        i = [],
        a = [];
    for (let n = 0, o = r.length; n < o; n++) i.push(y(r[n][0])), a.push(await G(e, t, r[n][1]));
    return h in n && (i.push(U(e.base, h)), a.push(ft(Wt(e.base), await G(e, t, Dt(n))))), p in n && (i.push(U(e.base, p)), a.push(pt(Gt(e.base), await G(e, t, Lt(n))))), g in n && (i.push(U(e.base, g)), a.push(Ye(n[g]))), m in n && (i.push(U(e.base, m)), a.push(n[m] ? me : he)), {
        k: i,
        v: a
    }
}
async function nn(e, t, n, r, i) {
    return Kt(n, r, i, await tn(e, t, r))
}
async function rn(e, t, n, r) {
    return it(n, await G(e, t, r.valueOf()))
}
async function an(e, t, n, r) {
    return r = Jt(e.base, r), ot(n, r, await G(e, t, r.buffer))
}
async function on(e, t, n, r) {
    return r = Jt(e.base, r), st(n, r, await G(e, t, r.buffer))
}
async function sn(e, t, n, r) {
    return r = Jt(e.base, r), ct(n, r, await G(e, t, r.buffer))
}
async function cn(e, t, n, r) {
    let i = Ke(r, e.base.features);
    return lt(n, r, i ? await tn(e, t, i) : void 0)
}
async function ln(e, t, n, r) {
    let i = Ke(r, e.base.features);
    return ut(n, r, i ? await tn(e, t, i) : void 0)
}
async function un(e, t, n, r) {
    let i = [],
        a = [];
    for (let [n, o] of r.entries()) i.push(await G(e, t, n)), a.push(await G(e, t, o));
    return qt(e.base, n, i, a)
}
async function dn(e, t, n, r) {
    let i = [];
    for (let n of r.keys()) i.push(await G(e, t, n));
    return dt(n, i)
}
async function fn(e, t, n, r) {
    let i = e.base.plugins;
    if (i)
        for (let a = 0, o = i.length; a < o; a++) {
            let o = i[a];
            if (o.parse.async && o.test(r)) return nt(n, o.tag, await o.parse.async(r, new Qt(e, t), {
                id: n
            }))
        }
}
async function pn(e, t, n, r) {
    let [i, a] = await Bt(r);
    return _(12, n, i, void 0, void 0, void 0, void 0, void 0, await G(e, t, a), void 0, void 0, void 0)
}

function mn(e, t, n, r, i) {
    let a = [],
        o = n.on({
            next: n => {
                V(this.base, t), G(this, e, n).then(e => {
                    a.push(ht(t, e))
                }, e => {
                    i(e), o()
                })
            },
            throw: n => {
                V(this.base, t), G(this, e, n).then(e => {
                    a.push(gt(t, e)), r(a), o()
                }, e => {
                    i(e), o()
                })
            },
            return: n => {
                V(this.base, t), G(this, e, n).then(e => {
                    a.push(_t(t, e)), r(a), o()
                }, e => {
                    i(e), o()
                })
            }
        })
}
async function hn(e, t, n, r) {
    return mt(n, W(e.base, 4), await new Promise(mn.bind(e, t, n, r)))
}
async function gn(e, t, n, r) {
    let i = [];
    for (let n = 0, a = r.v.length; n < a; n++) i[n] = await G(e, t, r.v[n]);
    return vt(n, i, r.t, r.d)
}
async function _n(e, t, n, r) {
    if (Array.isArray(r)) return en(e, t, n, r);
    if (z(r)) return hn(e, t, n, r);
    if (Tt(r)) return gn(e, t, n, r);
    let i = r.constructor;
    if (i !== void 0 && typeof i != `function`) {
        let e = Object.getPrototypeOf(r);
        i = e === null ? void 0 : e.constructor
    }
    if (i === yt) return G(e, t, r.replacement);
    let a = await fn(e, t, n, r);
    if (a) return a;
    switch (i) {
        case Object:
            return nn(e, t, n, r, !1);
        case void 0:
            return nn(e, t, n, r, !0);
        case Date:
            return Qe(n, r);
        case Error:
        case EvalError:
        case RangeError:
        case ReferenceError:
        case SyntaxError:
        case TypeError:
        case URIError:
            return cn(e, t, n, r);
        case Number:
        case Boolean:
        case String:
        case BigInt:
            return rn(e, t, n, r);
        case ArrayBuffer:
            return Xt(e.base, n, r);
        case Int8Array:
        case Int16Array:
        case Int32Array:
        case Uint8Array:
        case Uint16Array:
        case Uint32Array:
        case Uint8ClampedArray:
        case Float32Array:
        case Float64Array:
            return an(e, t, n, r);
        case DataView:
            return sn(e, t, n, r);
        case Map:
            return un(e, t, n, r);
        case Set:
            return dn(e, t, n, r)
    }
    if (i === Promise || r instanceof Promise) return pn(e, t, n, r);
    let o = e.base.features;
    if (o & 32 && i === RegExp) return $e(n, r);
    if (o & 16) switch (i) {
        case BigInt64Array:
        case BigUint64Array:
            return on(e, t, n, r)
    }
    if (o & 1 && typeof AggregateError < `u` && (i === AggregateError || r instanceof AggregateError)) return ln(e, t, n, r);
    if (o & 64 && typeof Temporal < `u`) switch (i) {
        case Temporal.Instant:
            return D(n, 0, r);
        case Temporal.Duration:
            return D(n, 1, r);
        case Temporal.PlainDate:
            return D(n, 2, r);
        case Temporal.PlainDateTime:
            return D(n, 3, r);
        case Temporal.PlainMonthDay:
            return D(n, 4, r);
        case Temporal.PlainTime:
            return D(n, 5, r);
        case Temporal.PlainYearMonth:
            return D(n, 6, r);
        case Temporal.ZonedDateTime:
            return D(n, 7, r)
    }
    if (r instanceof Error) return cn(e, t, n, r);
    if (h in r || p in r) return nn(e, t, n, r, !!i);
    throw new S(r)
}
async function vn(e, t, n) {
    let r = Ut(e.base, n);
    if (r.type !== 0) return r.value;
    let i = await fn(e, t, r.value, n);
    if (i) return i;
    throw new S(n)
}
async function G(e, t, n) {
    if (t >= e.base.depthLimit) throw new Re(e.base.depthLimit);
    switch (typeof n) {
        case `boolean`:
            return n ? me : he;
        case `undefined`:
            return ge;
        case `string`:
            return Ye(n);
        case `number`:
            return Je(n);
        case `bigint`:
            return Xe(n);
        case `object`:
            if (n) {
                let r = Ut(e.base, n);
                return r.type === 0 ? await _n(e, t + 1, r.value, n) : r.value
            }
            return _e;
        case `symbol`:
            return U(e.base, n);
        case `function`:
            return vn(e, t, n);
        default:
            throw new S(n)
    }
}
async function yn(e, t) {
    try {
        return await G(e, 0, t)
    } catch (e) {
        throw e instanceof je ? e : new je(e)
    }
}

function K(e) {
    return e
}

function bn(e, t) {
    for (let n = 0, r = t.length; n < r; n++) {
        let r = t[n];
        e.has(r) || (e.add(r), r.extends && bn(e, r.extends))
    }
}

function xn(e) {
    if (e) {
        let t = new Set;
        return bn(t, e), [...t]
    }
}

function Sn(e) {
    switch (e) {
        case `Int8Array`:
            return Int8Array;
        case `Int16Array`:
            return Int16Array;
        case `Int32Array`:
            return Int32Array;
        case `Uint8Array`:
            return Uint8Array;
        case `Uint16Array`:
            return Uint16Array;
        case `Uint32Array`:
            return Uint32Array;
        case `Uint8ClampedArray`:
            return Uint8ClampedArray;
        case `Float32Array`:
            return Float32Array;
        case `Float64Array`:
            return Float64Array;
        case `BigInt64Array`:
            return BigInt64Array;
        case `BigUint64Array`:
            return BigUint64Array;
        default:
            throw new Le(e)
    }
}

function Cn(e) {
    switch (e) {
        case `constructor`:
        case `__proto__`:
        case `prototype`:
        case `__defineGetter__`:
        case `__defineSetter__`:
        case `__lookupGetter__`:
        case `__lookupSetter__`:
            return !1;
        default:
            return !0
    }
}

function wn(e) {
    switch (e) {
        case p:
        case m:
        case g:
        case h:
            return !0;
        default:
            return !1
    }
}
var Tn = 1e6,
    En = 512,
    Dn = 1e4,
    On = 2e4;

function kn(e, t) {
    switch (t) {
        case 3:
            return Object.freeze(e);
        case 1:
            return Object.preventExtensions(e);
        case 2:
            return Object.seal(e);
        default:
            return e
    }
}
var An = 1e3;

function jn(e, t) {
    let n = t.maxBase64Length ?? Tn;
    if (!Number.isSafeInteger(n) || n < 0) throw RangeError(`maxBase64Length must be a non-negative safe integer`);
    let r = t.refs || new Map;
    return `types` in r || Object.assign(r, {
        types: new Map
    }), {
        mode: e,
        plugins: t.plugins,
        refs: r,
        features: t.features ?? 127 ^ (t.disabledFeatures || 0),
        depthLimit: t.depthLimit || An,
        maxBase64Length: n
    }
}

function Mn(e) {
    return {
        mode: 2,
        base: jn(2, e),
        child: void 0
    }
}
var Nn = class {
    constructor(e, t) {
        this._p = e, this.depth = t
    }
    deserialize(e) {
        return X(this._p, this.depth, e)
    }
};

function Pn(e, t) {
    if (t < 0 || !Number.isFinite(t) || !Number.isInteger(t)) throw new w({
        t: 4,
        i: t
    });
    if (e.refs.has(t)) throw Error(`Conflicted ref id: ` + t)
}

function Fn(e) {
    return !!e && (typeof e == `object` || typeof e == `function`) && `then` in e && typeof e.then == `function`
}

function In(e, t, n) {
    return Pn(e.base, t), e.state.marked.has(t) && e.base.refs.set(t, n), n
}

function Ln(e, t, n) {
    return Pn(e.base, t), e.base.refs.set(t, n), n
}

function q(e, t, n) {
    return e.mode === 1 ? In(e, t, n) : Ln(e, t, n)
}

function Rn(e, t, n) {
    if (Object.hasOwn(t, n)) return t[n];
    throw new w(e)
}

function zn(e, t) {
    return q(e, t.i, Ue(b(t.s)))
}

function J(e, t) {
    if (!Array.isArray(t)) throw new w(e)
}

function Bn(e, t, n) {
    let r = n.a;
    J(n, r);
    let i = r.length,
        a = q(e, n.i, Array(i));
    for (let n = 0, o; n < i; n++) o = r[n], o && (a[n] = X(e, t, o));
    return kn(a, n.o), a
}

function Vn(e, t, n) {
    Cn(t) ? e[t] = n : Object.defineProperty(e, t, {
        value: n,
        configurable: !0,
        enumerable: !0,
        writable: !0
    })
}

function Hn(e, t, n, r, i) {
    if (typeof r == `string`) Vn(n, b(r), X(e, t, i));
    else {
        let a = X(e, t, r);
        switch (typeof a) {
            case `string`:
                Vn(n, a, X(e, t, i));
                break;
            case `symbol`:
                wn(a) && (n[a] = X(e, t, i));
                break;
            default:
                throw new w(r)
        }
    }
}

function Un(e, t, n) {
    e.base.refs.types.set(t, n)
}

function Y(e, t, n, r) {
    if (e.base.refs.types.get(n) !== r) throw new w(t)
}

function Wn(e, t, n, r) {
    let i = n.k;
    if (J(n, i), J(n, n.v), i.length > 0)
        for (let a = 0, o = n.v, s = i.length; a < s; a++) Hn(e, t, r, i[a], o[a]);
    return r
}

function Gn(e, t, n) {
    let r = q(e, n.i, n.t === 10 ? {} : Object.create(null));
    return Wn(e, t, n.p, r), kn(r, n.o), r
}

function Kn(e, t) {
    return q(e, t.i, new Date(t.s))
}

function qn(e, t) {
    if (!(e.base.features & 64)) throw new Ne(t);
    let n;
    switch (t.c) {
        case 0:
            n = Temporal.Instant.from(t.s);
            break;
        case 1:
            n = Temporal.Duration.from(t.s);
            break;
        case 2:
            n = Temporal.PlainDate.from(t.s);
            break;
        case 3:
            n = Temporal.PlainDateTime.from(t.s);
            break;
        case 4:
            n = Temporal.PlainMonthDay.from(t.s);
            break;
        case 5:
            n = Temporal.PlainTime.from(t.s);
            break;
        case 6:
            n = Temporal.PlainYearMonth.from(t.s);
            break;
        case 7:
            n = Temporal.ZonedDateTime.from(t.s);
            break;
        default:
            throw new w(t)
    }
    return q(e, t.i, n)
}

function Jn(e, t) {
    if (e.base.features & 32) {
        let n = b(t.c);
        if (n.length > On) throw new w(t);
        return q(e, t.i, new RegExp(n, t.m))
    }
    throw new Ne(t)
}

function Yn(e, t, n) {
    let r = q(e, n.i, new Set);
    J(n, n.a);
    for (let i = 0, a = n.a, o = a.length; i < o; i++) r.add(X(e, t, a[i]));
    return r
}

function Xn(e, t, n) {
    let r = q(e, n.i, new Map);
    J(n, n.e.k), J(n, n.e.v);
    for (let i = 0, a = n.e.k, o = n.e.v, s = a.length; i < s; i++) r.set(X(e, t, a[i]), X(e, t, o[i]));
    return r
}

function Zn(e, t) {
    if (typeof t.s != `string`) throw new w(t);
    if (t.s.length > e.base.maxBase64Length) throw RangeError(`ArrayBuffer exceeds maxBase64Length (` + e.base.maxBase64Length + `)`);
    let n = b(t.s),
        r;
    if (n.length < En || typeof Buffer > `u`) r = Ct(n);
    else {
        let e = atob(n);
        r = new ArrayBuffer(e.length), Buffer.from(r).write(e, `latin1`)
    }
    return q(e, t.i, r)
}

function Qn(e, t, n) {
    let r = Sn(n.c),
        i = X(e, t, n.f);
    if (!(i instanceof ArrayBuffer)) throw new w(n);
    let a = n.b ?? 0;
    if (a < 0 || a > i.byteLength) throw new w(n);
    return q(e, n.i, new r(i, a, n.l))
}

function $n(e, t, n) {
    let r = X(e, t, n.f);
    if (!(r instanceof ArrayBuffer)) throw new w(n);
    let i = n.b ?? 0;
    if (i < 0 || i > r.byteLength) throw new w(n);
    return q(e, n.i, new DataView(r, i, n.l))
}

function er(e, t, n, r) {
    if (n.p) {
        let i = Wn(e, t, n.p, {});
        Object.defineProperties(r, Object.getOwnPropertyDescriptors(i))
    }
    return r
}

function tr(e, t, n) {
    return er(e, t, n, q(e, n.i, AggregateError([], b(n.m))))
}

function nr(e, t, n) {
    let r = Rn(n, pe, n.s);
    return er(e, t, n, q(e, n.i, new r(b(n.m))))
}

function rr(e, t, n) {
    let r = bt(),
        i = q(e, n.i, r.p),
        a = X(e, t, n.f);
    if (Fn(a)) throw new w(n.f);
    return n.s ? r.s(a) : r.f(a), i
}

function ir(e, t, n) {
    return q(e, n.i, Object(X(e, t, n.f)))
}

function ar(e, t, n) {
    let r = e.base.plugins;
    if (r) {
        let i = b(n.c);
        for (let a = 0, o = r.length; a < o; a++) {
            let o = r[a];
            if (o.tag === i) return q(e, n.i, o.deserialize(n.s, new Nn(e, t), {
                id: n.i
            }))
        }
    }
    throw new Pe(n.c)
}

function or(e, t) {
    let n = q(e, t.i, q(e, t.s, bt()).p);
    return Un(e, t.s, 22), n
}

function sr(e, t, n) {
    let r = e.base.refs.get(n.i);
    if (r) {
        Y(e, n, n.i, 22);
        let i = X(e, t, n.a[1]);
        if (Fn(i)) throw new w(n.a[1]);
        n.t === 23 ? r.s(i) : r.f(i);
        return
    }
    throw new C(`Promise`)
}

function cr(e, t, n) {
    X(e, t, n.a[0]);
    let r = X(e, t, n.a[1]);
    if (!Tt(r)) throw new w(n.a[1]);
    return kt(r)
}

function lr(e, t, n) {
    X(e, t, n.a[0]);
    let r = X(e, t, n.a[1]);
    if (!z(r)) throw new w(n.a[1]);
    return zt(r)
}

function ur(e, t, n) {
    let r = q(e, n.i, B());
    Un(e, n.i, 31);
    let i = n.a;
    J(n, i);
    let a = i.length;
    if (a)
        for (let n = 0; n < a; n++) X(e, t, i[n]);
    return r
}

function dr(e, t, n) {
    let r = e.base.refs.get(n.i);
    if (r) {
        Y(e, n, n.i, 31), r.next(X(e, t, n.f));
        return
    }
    throw new C(`Stream`)
}

function fr(e, t, n) {
    let r = e.base.refs.get(n.i);
    if (r) {
        Y(e, n, n.i, 31), r.throw(X(e, t, n.f));
        return
    }
    throw new C(`Stream`)
}

function pr(e, t, n) {
    let r = e.base.refs.get(n.i);
    if (r) {
        Y(e, n, n.i, 31), r.return(X(e, t, n.f));
        return
    }
    throw new C(`Stream`)
}

function mr(e, t, n) {
    X(e, t, n.f)
}

function hr(e, t, n) {
    X(e, t, n.a[1])
}

function gr(e, t) {
    return Number.isInteger(e) && e >= -1 && e < t
}

function _r(e, t, n) {
    J(n, n.a);
    let r = n.a.length;
    if (!(gr(n.s, r) && gr(n.l, r))) throw new w(n);
    let i = q(e, n.i, Et([], n.s, n.l));
    for (let a = 0; a < r; a++) i.v[a] = X(e, t, n.a[a]);
    return i
}

function X(e, t, n) {
    if (t > e.base.depthLimit) throw new Re(e.base.depthLimit);
    switch (t += 1, n.t) {
        case 2:
            return Rn(n, de, n.s);
        case 0:
            return Number(n.s);
        case 1:
            return b(String(n.s));
        case 3:
            if (String(n.s).length > Dn) throw new w(n);
            return BigInt(n.s);
        case 4:
            return e.base.refs.get(n.i);
        case 18:
            return zn(e, n);
        case 9:
            return Bn(e, t, n);
        case 10:
        case 11:
            return Gn(e, t, n);
        case 5:
            return Kn(e, n);
        case 6:
            return Jn(e, n);
        case 7:
            return Yn(e, t, n);
        case 8:
            return Xn(e, t, n);
        case 19:
            return Zn(e, n);
        case 16:
        case 15:
            return Qn(e, t, n);
        case 20:
            return $n(e, t, n);
        case 14:
            return tr(e, t, n);
        case 13:
            return nr(e, t, n);
        case 12:
            return rr(e, t, n);
        case 17:
            return Rn(n, ue, n.s);
        case 21:
            return ir(e, t, n);
        case 25:
            return ar(e, t, n);
        case 22:
            return or(e, n);
        case 23:
        case 24:
            return sr(e, t, n);
        case 28:
            return cr(e, t, n);
        case 30:
            return lr(e, t, n);
        case 31:
            return ur(e, t, n);
        case 32:
            return dr(e, t, n);
        case 33:
            return fr(e, t, n);
        case 34:
            return pr(e, t, n);
        case 27:
            return mr(e, t, n);
        case 29:
            return hr(e, t, n);
        case 35:
            return _r(e, t, n);
        case 36:
            return qn(e, n);
        default:
            throw new Ne(n)
    }
}

function vr(e, t) {
    try {
        return X(e, 0, t)
    } catch (e) {
        throw new Me(e)
    }
}

function yr(e, t) {
    let n = xn(t.plugins);
    return vr(Mn({
        maxBase64Length: t.maxBase64Length,
        plugins: n,
        refs: t.refs,
        features: t.features,
        disabledFeatures: t.disabledFeatures,
        depthLimit: t.depthLimit
    }), e)
}
async function br(e, t = {}) {
    let n = xn(t.plugins),
        r = Zt(1, {
            compactArrayBufferViews: t.compactArrayBufferViews,
            plugins: n,
            disabledFeatures: t.disabledFeatures
        });
    return {
        t: await yn(r, e),
        f: r.base.features,
        m: Array.from(r.base.marked)
    }
}

function xr(e) {
    return K({
        tag: `$TSR/t/` + e.key,
        test: e.test,
        parse: {
            sync(t, n) {
                return {
                    v: n.parse(e.toSerializable(t))
                }
            },
            async async (t, n) {
                return {
                    v: await n.parse(e.toSerializable(t))
                }
            },
            stream(t, n) {
                return {
                    v: n.parse(e.toSerializable(t))
                }
            }
        },
        serialize: void 0,
        deserialize(t, n) {
            return e.fromSerializable(n.deserialize(t.v))
        }
    })
}
var Sr = K({
        tag: `$TSR/Error`,
        test(e) {
            return e instanceof Error
        },
        parse: {
            sync(e, t) {
                return {
                    message: t.parse(e.message)
                }
            },
            async async (e, t) {
                return {
                    message: await t.parse(e.message)
                }
            },
            stream(e, t) {
                return {
                    message: t.parse(e.message)
                }
            }
        },
        serialize(e, t) {
            return `new Error(` + t.serialize(e.message) + `)`
        },
        deserialize(e, t) {
            return Error(t.deserialize(e.message))
        }
    }),
    Cr = class {
        constructor(e, t) {
            this.stream = e, this.hint = t ?.hint ?? `binary`
        }
    };

function wr(e) {
    let t = [];
    for (let n = 0; n < e.length; n += 32768) t.push(String.fromCharCode.apply(null, e.subarray(n, n + 32768)));
    return btoa(t.join(``))
}
var Tr = new TextDecoder(`utf-8`, {
    fatal: !0,
    ignoreBOM: !0
});

function Er(e) {
    try {
        return `t` + Tr.decode(e)
    } catch {
        return `b` + wr(e)
    }
}

function Dr(e, t, n) {
    n ?.throwIfAborted();
    let r = B(),
        i = e.getReader(),
        a = !0,
        o = () => {
            a = !1, n ?.removeEventListener(`abort`, c), i.releaseLock()
        },
        s = e => a ? (i.cancel(e).catch(() => {}), o(), !0) : !1,
        c = () => {
            s(n.reason) && r.throw(n.reason)
        };
    return n ?.addEventListener(`abort`, c), (async () => {
        try {
            for (; a;) {
                let {
                    done: e,
                    value: n
                } = await i.read();
                if (!a) return;
                if (e) {
                    o(), r.return(void 0);
                    return
                }
                r.next(t(n))
            }
        } catch (e) {
            s(e) && r.throw(e)
        }
    })(), [r, s]
}

function Or(e) {
    return K({
        tag: `tss/RawStream`,
        test: e => e instanceof Cr,
        parse: {
            async: async (t, n) => {
                let r = await n.parse(t.hint === `text`),
                    [i] = Dr(t.stream, t.hint === `text` ? Er : wr, e);
                return {
                    text: r,
                    stream: await n.parse(i)
                }
            }
        },
        serialize: void 0,
        deserialize: void 0
    })
}
var kr = Or(),
    Z = {},
    Ar = e => new ReadableStream({
        start(t) {
            e.on({
                next(e) {
                    try {
                        t.enqueue(e)
                    } catch {}
                },
                throw (e) {
                    t.error(e)
                },
                return () {
                    try {
                        t.close()
                    } catch {}
                }
            })
        }
    }),
    jr = K({
        tag: `seroval-plugins/web/ReadableStreamFactory`,
        test(e) {
            return e === Z
        },
        parse: {
            sync() {
                return Z
            },
            async async () {
                return await Promise.resolve(Z)
            },
            stream() {
                return Z
            }
        },
        serialize() {
            return Ar.toString()
        },
        deserialize() {
            return Z
        }
    });
async function Mr(e, t) {
    try {
        for (;;) {
            let n = await t.read();
            if (n.done) {
                e.return(n.value), t.releaseLock();
                break
            }
            e.next(n.value)
        }
    } catch (n) {
        t.releaseLock(), e.throw(n)
    }
}

function Nr(e) {
    e.cancel().catch(() => {}), e.releaseLock()
}

function Pr(e) {
    let t = B(),
        n = e.getReader(),
        r = Nr.bind(null, n);
    return Mr(t, n).catch(r), [t, r]
}
var Fr = K({
    tag: `seroval/plugins/web/ReadableStream`,
    extends: [jr],
    test(e) {
        return typeof ReadableStream > `u` ? !1 : e instanceof ReadableStream
    },
    parse: {
        sync(e, t) {
            return {
                factory: t.parse(Z),
                stream: t.parse(B())
            }
        },
        async async (e, t) {
            return {
                factory: await t.parse(Z),
                stream: await t.parse(Pr(e)[0])
            }
        },
        stream(e, t) {
            let [n, r] = Pr(e);
            return t.addCleanup(r), {
                factory: t.parse(Z),
                stream: t.parse(n)
            }
        }
    },
    serialize(e, t) {
        return `(` + t.serialize(e.factory) + `)(` + t.serialize(e.stream) + `)`
    },
    deserialize(e, t) {
        let n = t.deserialize(e.stream);
        if (!n || typeof n != `object` || !z(n)) throw Error(`Expected a stream source.`);
        return Ar(n)
    }
});

function Ir(e) {
    return [Sr, e ? Or(e) : kr, Fr]
}[...Ir()];

function Lr(e) {
    return K({
        tag: `tss/RawStream`,
        test: () => !1,
        parse: {},
        serialize: void 0,
        deserialize(t, n) {
            return e(n.deserialize(t.streamId))
        }
    })
}

function Rr(e) {
    return [...(o() ?.serializationAdapters) ?.map(xr) ?? [], ...e]
}

function zr(e) {
    return Rr(Ir(e))
}
var Br = new TextDecoder,
    Q = new Uint8Array,
    Vr = new ByteLengthQueuingStrategy({
        highWaterMark: 0
    });

function Hr(e) {
    let t = e.getReader(),
        n = new Map,
        r = 0,
        i, a, o = () => {
            i ?.(), i = void 0
        },
        s = (e, t) => {
            let n = e[1];
            e[1] = !1, n && (t === 1 ? n.close() : n.error(t[0]))
        },
        c = new ReadableStream({
            start(e) {
                a = e
            },
            pull: o,
            cancel(e) {
                let i = [e === void 0 ? Error(`Framed response cancelled`) : e];
                r = i, o(), t.cancel(e).catch(() => {});
                for (let e of n.values()) s(e, i)
            }
        });

    function l(e) {
        let t = n.get(e);
        if (t) return t;
        if (n.size >= 1024) throw Error(`Too many raw streams`);
        let i, a = [new ReadableStream({
            start(e) {
                i = e
            },
            cancel() {
                a[1] !== !1 && (a[1] = null)
            }
        }, Vr), i];
        return n.set(e, a), r !== 0 && s(a, r), a
    }

    function u(e) {
        if (e === 0 || e >>> 0 !== e) throw RangeError(`Invalid raw stream ID`);
        return l(e)[0]
    }
    return (async () => {
        let e = Q,
            o = 0;
        async function c() {
            for (; o === e.byteLength;) {
                e = Q, o = 0;
                let n = await t.read();
                if (r !== 0 || n.done) return !1;
                e = n.value
            }
            return !0
        }
        async function u(t, n) {
            if (t === 0) return Q;
            if (!await c()) {
                if (n) return;
                throw Error(`Incomplete frame`)
            }
            if (e.byteLength - o >= t) {
                let n = e.subarray(o, o + t);
                return o += t, o === e.byteLength && (e = Q, o = 0), n
            }
            let r = new Uint8Array(t),
                i = 0;
            for (; i < t;) {
                if (!await c()) throw Error(`Incomplete frame`);
                let n = Math.min(t - i, e.byteLength - o);
                r.set(e.subarray(o, o + n), i), o += n, i += n
            }
            return o === e.byteLength && (e = Q, o = 0), r
        }
        try {
            for (; r === 0;) {
                let e = await u(9, !0);
                if (r !== 0) return;
                if (!e) {
                    for (let e of n.values())
                        if (e[1]) throw Error(`Incomplete raw stream`);
                    r = 1, a.close();
                    return
                }
                let t = e[0],
                    o = (e[1] << 24 | e[2] << 16 | e[3] << 8 | e[4]) >>> 0,
                    c = (e[5] << 24 | e[6] << 16 | e[7] << 8 | e[8]) >>> 0;
                if (e = Q, t > 3 || t === 0 != (o === 0) || c > 16777216 || t === 2 && c !== 0) throw Error(`Invalid frame`);
                let d = t === 0 ? void 0 : l(o);
                if (d ?.[1] === !1) throw Error(`Raw stream already ended`);
                let f = await u(c);
                if (r !== 0) return;
                if (!d) {
                    let e = Br.decode(f);
                    for (f = Q, a.enqueue(e); r === 0 && a.desiredSize <= 0;) await new Promise(e => {
                        i = e
                    });
                    continue
                }
                if (t === 1) {
                    let e = d[1];
                    if (e) {
                        if (-e.desiredSize > 134217728) {
                            e.error(Error(`Raw stream ${o} has too many unread bytes`)), d[1] = null, f = Q;
                            continue
                        }
                        let t = f.byteLength * 4 < f.buffer.byteLength ? f.slice() : f;
                        f = Q, e.enqueue(t)
                    }
                } else s(d, t === 2 ? 1 : [Error(Br.decode(f))])
            }
        } catch (e) {
            if (r === 0) {
                let i = [e];
                r = i, t.cancel(e).catch(() => {}), a.error(e);
                for (let e of n.values()) s(e, i)
            }
        } finally {
            e = Q, t.releaseLock()
        }
    })(), [c, u]
}
var $;

function Ur(e, t, n) {
    try {
        return yr(e, t)
    } catch (e) {
        throw Gr(n), e
    }
}
async function Wr(e) {
    e.length > 0 && (await Promise.allSettled(e), e.length = 0)
}

function Gr(e) {
    for (let t of e) t.catch(() => {});
    e.length = 0
}
var Kr = Object.prototype.hasOwnProperty;

function qr(e) {
    for (let t in e)
        if (Kr.call(e, t)) return !0;
    return !1
}
async function Jr(e, t, n) {
    $ ||= zr();
    let r = t[0],
        i = r.fetch ?? n,
        o = r.data instanceof FormData,
        s = new Headers(r.headers);
    if (s.set(`x-tsr-serverFn`, `true`), o || s.set(`accept`, `${a}, application/x-ndjson, application/json`), r.method === `GET`) {
        if (o) throw Error(`FormData is not supported with GET requests`);
        let t = await Yr(r);
        if (t !== void 0) {
            let n = u({
                payload: t
            });
            e.includes(`?`) ? e += `&${n}` : e += `?${n}`
        }
    }
    let c;
    return r.method === `POST` && (c = await Zr(r), typeof c == `string` && s.set(`content-type`, `application/json`)), Qr(() => i(e, {
        method: r.method,
        headers: s,
        signal: r.signal,
        body: c
    }))
}
async function Yr(e) {
    let t;
    return e.data !== void 0 && (t = {
        data: e.data
    }), e.context && qr(e.context) && ((t ??= {}).context = e.context), t ? Xr(t, e.signal) : void 0
}
async function Xr(e, t) {
    t ?.throwIfAborted();
    let n;
    try {
        n = await br(e, {
            plugins: t ? zr(t) : $
        })
    } finally {
        t ?.throwIfAborted()
    }
    return JSON.stringify(n)
}
async function Zr(e) {
    if (e.data instanceof FormData) {
        let t;
        return e.context && qr(e.context) && (t = await Xr(e.context, e.signal)), t !== void 0 && e.data.set(n, t), e.data
    }
    return Yr(e)
}
async function Qr(n) {
    let r;
    try {
        r = await n()
    } catch (e) {
        if (e instanceof Response) r = e;
        else throw e
    }
    if (r.headers.get(`x-tss-raw`) === `true`) return r;
    let i = r.headers.get(`content-type`);
    if (i || t(), r.headers.get(`x-tss-serialized`)) {
        let e;
        if (i.includes(`application/x-tss-framed`)) {
            let t = /;\s*v=(\d+)/.exec(i) ?.[1];
            if (t && +t != 1) throw Error(`Unsupported framed protocol version ${t}`);
            if (!r.body) throw Error(`No response body for framed response`);
            let [n, a] = Hr(r.body);
            e = await $r(n, [Lr(a), ...$])
        } else if (i.includes(`application/json`)) {
            let t = await r.json(),
                n = [];
            e = Ur(t, {
                plugins: $
            }, n), await Wr(n)
        }
        if (e || t(), e instanceof Error) throw e;
        return e
    }
    if (i.includes(`application/json`)) {
        let t = await r.json(),
            n = l(t);
        if (n) throw n;
        if (e(t)) throw t;
        return t
    }
    if (!r.ok) throw Error(await r.text());
    return r
}
async function $r(e, t) {
    let n = e.getReader(),
        r = {
            refs: new Map,
            plugins: t
        },
        i = e => {
            n.cancel(e).catch(() => {})
        },
        a, o = [];
    try {
        let e = await n.read();
        if (e.done) throw Error(`Stream ended before first object`);
        a = Ur(JSON.parse(e.value), r, o)
    } catch (e) {
        throw i(e), n.releaseLock(), e
    }
    return (async () => {
        let e = [];
        try {
            for (;;) {
                let t = await n.read();
                if (t.done) return;
                Ur(JSON.parse(t.value), r, e), Gr(e)
            }
        } catch (e) {
            i(e), console.error(`Stream processing error:`, e)
        } finally {
            n.releaseLock()
        }
    })(), await Wr(o), a
}

function ei(e) {
    let t = `/_serverFn/` + e;
    return Object.assign((...e) => {
        let n = o() ?.serverFns ?.fetch;
        return Jr(t, e, n ?? fetch)
    }, {
        url: t,
        serverFnMeta: {
            id: e
        },
        [r]: !0
    })
}
export {
    l as a, r as c, c as i, i as l, f as n, s as o, u as r, o as s, ei as t
};