import {
    r as e
} from "./rolldown-runtime-hePW80VL.js";
import {
    n as t
} from "./jsx-runtime-DE3RlOCf.js";
var n = e(t()),
    r = (...e) => e.filter((e, t, n) => !!e && e.trim() !== `` && n.indexOf(e) === t).join(` `).trim(),
    i = e => e.replace(/([a-z0-9])([A-Z])/g, `$1-$2`).toLowerCase(),
    a = e => e.replace(/^([A-Z])|[\s-_]+(\w)/g, (e, t, n) => n ? n.toUpperCase() : t.toLowerCase()),
    o = e => {
        let t = a(e);
        return t.charAt(0).toUpperCase() + t.slice(1)
    },
    s = {
        xmlns: `http://www.w3.org/2000/svg`,
        width: 24,
        height: 24,
        viewBox: `0 0 24 24`,
        fill: `none`,
        stroke: `currentColor`,
        strokeWidth: 2,
        strokeLinecap: `round`,
        strokeLinejoin: `round`
    },
    c = e => {
        for (let t in e)
            if (t.startsWith(`aria-`) || t === `role` || t === `title`) return !0;
        return !1
    },
    l = (0, n.forwardRef)(({
        color: e = `currentColor`,
        size: t = 24,
        strokeWidth: i = 2,
        absoluteStrokeWidth: a,
        className: o = ``,
        children: l,
        iconNode: u,
        ...d
    }, f) => (0, n.createElement)(`svg`, {
        ref: f,
        ...s,
        width: t,
        height: t,
        stroke: e,
        strokeWidth: a ? Number(i) * 24 / Number(t) : i,
        className: r(`lucide`, o),
        ...!l && !c(d) && {
            "aria-hidden": `true`
        },
        ...d
    }, [...u.map(([e, t]) => (0, n.createElement)(e, t)), ...Array.isArray(l) ? l : [l]])),
    u = (e, t) => {
        let a = (0, n.forwardRef)(({
            className: a,
            ...s
        }, c) => (0, n.createElement)(l, {
            ref: c,
            iconNode: t,
            className: r(`lucide-${i(o(e))}`, `lucide-${e}`, a),
            ...s
        }));
        return a.displayName = o(e), a
    };
export {
    u as t
};