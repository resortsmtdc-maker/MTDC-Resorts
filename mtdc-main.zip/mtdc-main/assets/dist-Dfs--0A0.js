import {
    r as e
} from "./rolldown-runtime-hePW80VL.js";
import {
    n as t,
    t as n
} from "./jsx-runtime-DE3RlOCf.js";
import {
    r
} from "./dist-B0Orvaj5.js";
import {
    n as i,
    r as a
} from "./dist-CICBZQnc.js";
import {
    a as o,
    r as s
} from "./dist-B-uvUq6S.js";
import {
    t as c
} from "./dist-BSxqYw3U.js";
import {
    s as l
} from "./dist-DoLknpjQ.js";
import {
    t as u
} from "./dist-D5jZWkLf.js";
var d = e(t(), 1),
    f = n(),
    p = Object.defineProperty,
    m = (e, t) => p(e, `name`, {
        value: t,
        configurable: !0
    });

function h(e) {
    let t = e + `CollectionProvider`,
        [n, r] = a(t),
        [i, c] = n(t, {
            collectionRef: {
                current: null
            },
            itemMap: new Map
        }),
        l = m(e => {
            let {
                scope: t,
                children: n
            } = e, r = d.useRef(null), a = d.useRef(new Map).current;
            return (0, f.jsx)(i, {
                scope: t,
                itemMap: a,
                collectionRef: r,
                children: n
            })
        }, `CollectionProvider`);
    l.displayName = t;
    let u = e + `CollectionSlot`,
        p = s(u),
        h = d.forwardRef((e, t) => {
            let {
                scope: n,
                children: r
            } = e, i = c(u, n), a = o(t, i.collectionRef);
            return (0, f.jsx)(p, {
                ref: a,
                children: r
            })
        });
    h.displayName = u;
    let g = e + `CollectionItemSlot`,
        _ = `data-radix-collection-item`,
        v = s(g),
        y = d.forwardRef((e, t) => {
            let {
                scope: n,
                children: r,
                ...i
            } = e, a = d.useRef(null), s = o(t, a), l = c(g, n);
            return d.useEffect(() => (l.itemMap.set(a, {
                ref: a,
                ...i
            }), () => void l.itemMap.delete(a))), (0, f.jsx)(v, {
                [_]: ``,
                ref: s,
                children: r
            })
        });
    y.displayName = g;

    function b(t) {
        let n = c(e + `CollectionConsumer`, t);
        return d.useCallback(() => {
            let e = n.collectionRef.current;
            if (!e) return [];
            let t = Array.from(e.querySelectorAll(`[${_}]`));
            return Array.from(n.itemMap.values()).sort((e, n) => t.indexOf(e.ref.current) - t.indexOf(n.ref.current))
        }, [n.collectionRef, n.itemMap])
    }
    return m(b, `useCollection`), [{
        Provider: l,
        Slot: h,
        ItemSlot: y
    }, b, r]
}
m(h, `createCollection`);
var g = new WeakMap,
    _ = class e extends Map {
        static {
            m(this, `OrderedDict`)
        }#e;
        constructor(e) {
            super(e), this.#e = [...super.keys()], g.set(this, !0)
        }
        set(e, t) {
            return g.get(this) && (this.has(e) ? this.#e[this.#e.indexOf(e)] = e : this.#e.push(e)), super.set(e, t), this
        }
        insert(e, t, n) {
            let r = this.has(t),
                i = this.#e.length,
                a = b(e),
                o = a >= 0 ? a : i + a,
                s = o < 0 || o >= i ? -1 : o;
            if (s === this.size || r && s === this.size - 1 || s === -1) return this.set(t, n), this;
            let c = this.size + +!r;
            a < 0 && o++;
            let l = [...this.#e],
                u, d = !1;
            for (let e = o; e < c; e++)
                if (o === e) {
                    let i = l[e];
                    l[e] === t && (i = l[e + 1]), r && this.delete(t), u = this.get(i), this.set(t, n)
                } else {
                    !d && l[e - 1] === t && (d = !0);
                    let n = l[d ? e : e - 1],
                        r = u;
                    u = this.get(n), this.delete(n), this.set(n, r)
                }
            return this
        }
        with(t, n, r) {
            let i = new e(this);
            return i.insert(t, n, r), i
        }
        before(e) {
            let t = this.#e.indexOf(e) - 1;
            if (!(t < 0)) return this.entryAt(t)
        }
        setBefore(e, t, n) {
            let r = this.#e.indexOf(e);
            return r === -1 ? this : this.insert(r, t, n)
        }
        after(e) {
            let t = this.#e.indexOf(e);
            if (t = t === -1 || t === this.size - 1 ? -1 : t + 1, t !== -1) return this.entryAt(t)
        }
        setAfter(e, t, n) {
            let r = this.#e.indexOf(e);
            return r === -1 ? this : this.insert(r + 1, t, n)
        }
        first() {
            return this.entryAt(0)
        }
        last() {
            return this.entryAt(-1)
        }
        clear() {
            return this.#e = [], super.clear()
        }
        delete(e) {
            let t = super.delete(e);
            return t && this.#e.splice(this.#e.indexOf(e), 1), t
        }
        deleteAt(e) {
            let t = this.keyAt(e);
            return t !== void 0 && this.delete(t)
        }
        at(e) {
            let t = v(this.#e, e);
            if (t !== void 0) return this.get(t)
        }
        entryAt(e) {
            let t = v(this.#e, e);
            if (t !== void 0) return [t, this.get(t)]
        }
        indexOf(e) {
            return this.#e.indexOf(e)
        }
        keyAt(e) {
            return v(this.#e, e)
        }
        from(e, t) {
            let n = this.indexOf(e);
            if (n === -1) return;
            let r = n + t;
            return r < 0 && (r = 0), r >= this.size && (r = this.size - 1), this.at(r)
        }
        keyFrom(e, t) {
            let n = this.indexOf(e);
            if (n === -1) return;
            let r = n + t;
            return r < 0 && (r = 0), r >= this.size && (r = this.size - 1), this.keyAt(r)
        }
        find(e, t) {
            let n = 0;
            for (let r of this) {
                if (Reflect.apply(e, t, [r, n, this])) return r;
                n++
            }
        }
        findIndex(e, t) {
            let n = 0;
            for (let r of this) {
                if (Reflect.apply(e, t, [r, n, this])) return n;
                n++
            }
            return -1
        }
        filter(t, n) {
            let r = [],
                i = 0;
            for (let e of this) Reflect.apply(t, n, [e, i, this]) && r.push(e), i++;
            return new e(r)
        }
        map(t, n) {
            let r = [],
                i = 0;
            for (let e of this) r.push([e[0], Reflect.apply(t, n, [e, i, this])]), i++;
            return new e(r)
        }
        reduce(...e) {
            let [t, n] = e, r = 0, i = n ?? this.at(0);
            for (let n of this) i = r === 0 && e.length === 1 ? n : Reflect.apply(t, this, [i, n, r, this]), r++;
            return i
        }
        reduceRight(...e) {
            let [t, n] = e, r = n ?? this.at(-1);
            for (let n = this.size - 1; n >= 0; n--) {
                let i = this.at(n);
                r = n === this.size - 1 && e.length === 1 ? i : Reflect.apply(t, this, [r, i, n, this])
            }
            return r
        }
        toSorted(t) {
            let n = [...this.entries()].sort(t);
            return new e(n)
        }
        toReversed() {
            let t = new e;
            for (let e = this.size - 1; e >= 0; e--) {
                let n = this.keyAt(e),
                    r = this.get(n);
                t.set(n, r)
            }
            return t
        }
        toSpliced(...t) {
            let n = [...this.entries()];
            return n.splice(...t), new e(n)
        }
        slice(t, n) {
            let r = new e,
                i = this.size - 1;
            if (t === void 0) return r;
            t < 0 && (t += this.size), n !== void 0 && n > 0 && (i = n - 1);
            for (let e = t; e <= i; e++) {
                let t = this.keyAt(e),
                    n = this.get(t);
                r.set(t, n)
            }
            return r
        }
        every(e, t) {
            let n = 0;
            for (let r of this) {
                if (!Reflect.apply(e, t, [r, n, this])) return !1;
                n++
            }
            return !0
        }
        some(e, t) {
            let n = 0;
            for (let r of this) {
                if (Reflect.apply(e, t, [r, n, this])) return !0;
                n++
            }
            return !1
        }
    };

function v(e, t) {
    if (`at` in Array.prototype) return Array.prototype.at.call(e, t);
    let n = y(e, t);
    return n === -1 ? void 0 : e[n]
}
m(v, `at`);

function y(e, t) {
    let n = e.length,
        r = b(t),
        i = r >= 0 ? r : n + r;
    return i < 0 || i >= n ? -1 : i
}
m(y, `toSafeIndex`);

function b(e) {
    return e !== e || e === 0 ? 0 : Math.trunc(e)
}
m(b, `toSafeInteger`);

function x(e) {
    let t = e + `CollectionProvider`,
        [n, r] = a(t),
        [i, c] = n(t, {
            collectionElement: null,
            collectionRef: {
                current: null
            },
            collectionRefObject: {
                current: null
            },
            itemMap: new _,
            setItemMap: m(() => void 0, `setItemMap`)
        }),
        l = m(({
            state: e,
            ...t
        }) => e ? (0, f.jsx)(p, { ...t,
            state: e
        }) : (0, f.jsx)(u, { ...t
        }), `CollectionProvider`);
    l.displayName = t;
    let u = m(e => {
        let t = C();
        return (0, f.jsx)(p, { ...e,
            state: t
        })
    }, `CollectionInit`);
    u.displayName = t + `Init`;
    let p = m(e => {
        let {
            scope: t,
            children: n,
            state: r
        } = e, a = d.useRef(null), [s, c] = d.useState(null), l = o(a, c), [u, p] = r;
        return d.useEffect(() => {
            if (!s) return;
            let e = T(() => {});
            return e.observe(s, {
                childList: !0,
                subtree: !0
            }), () => {
                e.disconnect()
            }
        }, [s]), (0, f.jsx)(i, {
            scope: t,
            itemMap: u,
            setItemMap: p,
            collectionRef: l,
            collectionRefObject: a,
            collectionElement: s,
            children: n
        })
    }, `CollectionProviderImpl`);
    p.displayName = t + `Impl`;
    let h = e + `CollectionSlot`,
        g = s(h),
        v = d.forwardRef((e, t) => {
            let {
                scope: n,
                children: r
            } = e, i = c(h, n), a = o(t, i.collectionRef);
            return (0, f.jsx)(g, {
                ref: a,
                children: r
            })
        });
    v.displayName = h;
    let y = e + `CollectionItemSlot`,
        b = s(y),
        x = d.forwardRef((e, t) => {
            let {
                scope: n,
                children: r,
                ...i
            } = e, a = d.useRef(null), [s, l] = d.useState(null), u = o(t, a, l), {
                setItemMap: p
            } = c(y, n), m = d.useRef(i);
            S(m.current, i) || (m.current = i);
            let h = m.current;
            return d.useEffect(() => {
                let e = h;
                return p(t => s ? t.has(s) ? t.set(s, { ...e,
                    element: s
                }).toSorted(w) : (t.set(s, { ...e,
                    element: s
                }), t.toSorted(w)) : t), () => {
                    p(e => !s || !e.has(s) ? e : (e.delete(s), new _(e)))
                }
            }, [s, h, p]), (0, f.jsx)(b, {
                "data-radix-collection-item": ``,
                ref: u,
                children: r
            })
        });
    x.displayName = y;

    function C() {
        return d.useState(new _)
    }
    m(C, `useInitCollection`);

    function E(t) {
        let {
            itemMap: n
        } = c(e + `CollectionConsumer`, t);
        return n
    }
    return m(E, `useCollection`), [{
        Provider: l,
        Slot: v,
        ItemSlot: x
    }, {
        createCollectionScope: r,
        useCollection: E,
        useInitCollection: C
    }]
}
m(x, `createCollection`);

function S(e, t) {
    if (e === t) return !0;
    if (typeof e != `object` || typeof t != `object` || e == null || t == null) return !1;
    let n = Object.keys(e),
        r = Object.keys(t);
    if (n.length !== r.length) return !1;
    for (let r of n)
        if (!Object.prototype.hasOwnProperty.call(t, r) || e[r] !== t[r]) return !1;
    return !0
}
m(S, `shallowEqual`);

function C(e, t) {
    return !!(t.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_PRECEDING)
}
m(C, `isElementPreceding`);

function w(e, t) {
    return !e[1].element || !t[1].element ? 0 : C(e[1].element, t[1].element) ? -1 : 1
}
m(w, `sortByDocumentPosition`);

function T(e) {
    return new MutationObserver(t => {
        for (let n of t)
            if (n.type === `childList`) {
                e();
                return
            }
    })
}
m(T, `getChildListObserver`);
var E = Object.defineProperty,
    D = (e, t) => E(e, `name`, {
        value: t,
        configurable: !0
    }),
    O = Object.freeze({
        position: `absolute`,
        border: 0,
        width: 1,
        height: 1,
        padding: 0,
        margin: -1,
        overflow: `hidden`,
        clip: `rect(0, 0, 0, 0)`,
        whiteSpace: `nowrap`,
        wordWrap: `normal`
    }),
    k = d.forwardRef(D(function(e, t) {
        return (0, f.jsx)(c.span, { ...e,
            ref: t,
            style: { ...O,
                ...e.style
            }
        })
    }, `VisuallyHidden`)),
    A = k,
    j = [`top`, `right`, `bottom`, `left`],
    M = Math.min,
    N = Math.max,
    P = Math.round,
    F = Math.floor,
    I = e => ({
        x: e,
        y: e
    }),
    ee = {
        left: `right`,
        right: `left`,
        bottom: `top`,
        top: `bottom`
    };

function te(e, t, n) {
    return N(e, M(t, n))
}

function L(e, t) {
    return typeof e == `function` ? e(t) : e
}

function R(e) {
    return e.split(`-`)[0]
}

function z(e) {
    return e.split(`-`)[1]
}

function B(e) {
    return e === `x` ? `y` : `x`
}

function V(e) {
    return e === `y` ? `height` : `width`
}

function H(e) {
    let t = e[0];
    return t === `t` || t === `b` ? `y` : `x`
}

function ne(e) {
    return B(H(e))
}

function re(e, t, n) {
    n === void 0 && (n = !1);
    let r = z(e),
        i = ne(e),
        a = V(i),
        o = i === `x` ? r === (n ? `end` : `start`) ? `right` : `left` : r === `start` ? `bottom` : `top`;
    return t.reference[a] > t.floating[a] && (o = fe(o)), [o, fe(o)]
}

function ie(e) {
    let t = fe(e);
    return [ae(e), t, ae(t)]
}

function ae(e) {
    return e.includes(`start`) ? e.replace(`start`, `end`) : e.replace(`end`, `start`)
}
var oe = [`left`, `right`],
    se = [`right`, `left`],
    ce = [`top`, `bottom`],
    le = [`bottom`, `top`];

function ue(e, t, n) {
    switch (e) {
        case `top`:
        case `bottom`:
            return n ? t ? se : oe : t ? oe : se;
        case `left`:
        case `right`:
            return t ? ce : le;
        default:
            return []
    }
}

function de(e, t, n, r) {
    let i = z(e),
        a = ue(R(e), n === `start`, r);
    return i && (a = a.map(e => e + `-` + i), t && (a = a.concat(a.map(ae)))), a
}

function fe(e) {
    let t = R(e);
    return ee[t] + e.slice(t.length)
}

function pe(e) {
    return {
        top: e.top ?? 0,
        right: e.right ?? 0,
        bottom: e.bottom ?? 0,
        left: e.left ?? 0
    }
}

function me(e) {
    return typeof e == `number` ? {
        top: e,
        right: e,
        bottom: e,
        left: e
    } : pe(e)
}

function he(e) {
    let {
        x: t,
        y: n,
        width: r,
        height: i
    } = e;
    return {
        width: r,
        height: i,
        top: n,
        left: t,
        right: t + r,
        bottom: n + i,
        x: t,
        y: n
    }
}

function ge(e, t, n) {
    let {
        reference: r,
        floating: i
    } = e, a = H(t), o = ne(t), s = V(o), c = R(t), l = a === `y`, u = r.x + r.width / 2 - i.width / 2, d = r.y + r.height / 2 - i.height / 2, f = r[s] / 2 - i[s] / 2, p;
    switch (c) {
        case `top`:
            p = {
                x: u,
                y: r.y - i.height
            };
            break;
        case `bottom`:
            p = {
                x: u,
                y: r.y + r.height
            };
            break;
        case `right`:
            p = {
                x: r.x + r.width,
                y: d
            };
            break;
        case `left`:
            p = {
                x: r.x - i.width,
                y: d
            };
            break;
        default:
            p = {
                x: r.x,
                y: r.y
            }
    }
    let m = z(t);
    return m && (p[o] += f * (m === `end` ? 1 : -1) * (n && l ? -1 : 1)), p
}
async function _e(e, t) {
    t === void 0 && (t = {});
    let {
        x: n,
        y: r,
        platform: i,
        rects: a,
        elements: o,
        strategy: s
    } = e, {
        boundary: c = `clippingAncestors`,
        rootBoundary: l = `viewport`,
        elementContext: u = `floating`,
        altBoundary: d = !1,
        padding: f = 0
    } = L(t, e), p = me(f), m = o[d ? u === `floating` ? `reference` : `floating` : u], h = he(await i.getClippingRect({
        element: await (i.isElement == null ? void 0 : i.isElement(m)) ?? !0 ? m : m.contextElement || await (i.getDocumentElement == null ? void 0 : i.getDocumentElement(o.floating)),
        boundary: c,
        rootBoundary: l,
        strategy: s
    })), g = u === `floating` ? {
        x: n,
        y: r,
        width: a.floating.width,
        height: a.floating.height
    } : a.reference, _ = await (i.getOffsetParent == null ? void 0 : i.getOffsetParent(o.floating)), v = await (i.isElement == null ? void 0 : i.isElement(_)) && await (i.getScale == null ? void 0 : i.getScale(_)) || {
        x: 1,
        y: 1
    }, y = he(i.convertOffsetParentRelativeRectToViewportRelativeRect ? await i.convertOffsetParentRelativeRectToViewportRelativeRect({
        elements: o,
        rect: g,
        offsetParent: _,
        strategy: s
    }) : g);
    return {
        top: (h.top - y.top + p.top) / v.y,
        bottom: (y.bottom - h.bottom + p.bottom) / v.y,
        left: (h.left - y.left + p.left) / v.x,
        right: (y.right - h.right + p.right) / v.x
    }
}
var ve = 50,
    ye = async (e, t, n) => {
        let {
            placement: r = `bottom`,
            strategy: i = `absolute`,
            middleware: a = [],
            platform: o
        } = n, s = o.detectOverflow ? o : { ...o,
            detectOverflow: _e
        }, c = await (o.isRTL == null ? void 0 : o.isRTL(t)), l = await o.getElementRects({
            reference: e,
            floating: t,
            strategy: i
        }), {
            x: u,
            y: d
        } = ge(l, r, c), f = r, p = 0, m = {};
        for (let n = 0; n < a.length; n++) {
            let h = a[n];
            if (!h) continue;
            let {
                name: g,
                fn: _
            } = h, {
                x: v,
                y,
                data: b,
                reset: x
            } = await _({
                x: u,
                y: d,
                initialPlacement: r,
                placement: f,
                strategy: i,
                middlewareData: m,
                rects: l,
                platform: s,
                elements: {
                    reference: e,
                    floating: t
                }
            });
            u = v ?? u, d = y ?? d, m[g] = { ...m[g],
                ...b
            }, x && p < ve && (p++, typeof x == `object` && (x.placement && (f = x.placement), x.rects && (l = x.rects === !0 ? await o.getElementRects({
                reference: e,
                floating: t,
                strategy: i
            }) : x.rects), {
                x: u,
                y: d
            } = ge(l, f, c)), n = -1)
        }
        return {
            x: u,
            y: d,
            placement: f,
            strategy: i,
            middlewareData: m
        }
    },
    be = e => ({
        name: `arrow`,
        options: e,
        async fn(t) {
            let {
                x: n,
                y: r,
                placement: i,
                rects: a,
                platform: o,
                elements: s,
                middlewareData: c
            } = t, {
                element: l,
                padding: u = 0
            } = L(e, t) || {};
            if (l == null) return {};
            let d = me(u),
                f = {
                    x: n,
                    y: r
                },
                p = ne(i),
                m = V(p),
                h = await o.getDimensions(l),
                g = p === `y`,
                _ = g ? `top` : `left`,
                v = g ? `bottom` : `right`,
                y = g ? `clientHeight` : `clientWidth`,
                b = a.reference[m] + a.reference[p] - f[p] - a.floating[m],
                x = f[p] - a.reference[p],
                S = await (o.getOffsetParent == null ? void 0 : o.getOffsetParent(l)),
                C = S ? S[y] : 0;
            (!C || !await (o.isElement == null ? void 0 : o.isElement(S))) && (C = s.floating[y] || a.floating[m]);
            let w = b / 2 - x / 2,
                T = C / 2 - h[m] / 2 - 1,
                E = M(d[_], T),
                D = M(d[v], T),
                O = C - h[m] - D,
                k = C / 2 - h[m] / 2 + w,
                A = te(E, k, O),
                j = !c.arrow && z(i) != null && k !== A && a.reference[m] / 2 - (k < E ? E : D) - h[m] / 2 < 0,
                N = j ? k < E ? k - E : k - O : 0;
            return {
                [p]: f[p] + N,
                data: {
                    [p]: A,
                    centerOffset: k - A - N,
                    ...j && {
                        alignmentOffset: N
                    }
                },
                reset: j
            }
        }
    }),
    xe = function(e) {
        return e === void 0 && (e = {}), {
            name: `flip`,
            options: e,
            async fn(t) {
                var n;
                let {
                    placement: r,
                    middlewareData: i,
                    rects: a,
                    initialPlacement: o,
                    platform: s,
                    elements: c
                } = t, {
                    mainAxis: l = !0,
                    crossAxis: u = !0,
                    fallbackPlacements: d,
                    fallbackStrategy: f = `bestFit`,
                    fallbackAxisSideDirection: p = `none`,
                    flipAlignment: m = !0,
                    ...h
                } = L(e, t);
                if ((n = i.arrow) != null && n.alignmentOffset) return {};
                let g = R(r),
                    _ = H(o),
                    v = R(o) === o,
                    y = await (s.isRTL == null ? void 0 : s.isRTL(c.floating)),
                    b = d || (v || !m ? [fe(o)] : ie(o)),
                    x = p !== `none`;
                !d && x && b.push(...de(o, m, p, y));
                let S = [o, ...b],
                    C = await s.detectOverflow(t, h),
                    w = [],
                    T = i.flip ?.overflows || [];
                if (l && w.push(C[g]), u) {
                    let e = re(r, a, y);
                    w.push(C[e[0]], C[e[1]])
                }
                if (T = [...T, {
                        placement: r,
                        overflows: w
                    }], !w.every(e => e <= 0)) {
                    let e = (i.flip ?.index || 0) + 1,
                        t = S[e];
                    if (t && (u !== `alignment` || _ === H(t) || T.every(e => H(e.placement) !== _ || e.overflows[0] > 0))) return {
                        data: {
                            index: e,
                            overflows: T
                        },
                        reset: {
                            placement: t
                        }
                    };
                    let n = T.filter(e => e.overflows[0] <= 0).sort((e, t) => e.overflows[1] - t.overflows[1])[0] ?.placement;
                    if (!n) switch (f) {
                        case `bestFit`:
                            {
                                let e = T.filter(e => {
                                    if (x) {
                                        let t = H(e.placement);
                                        return t === _ || t === `y`
                                    }
                                    return !0
                                }).map(e => [e.placement, e.overflows.filter(e => e > 0).reduce((e, t) => e + t, 0)]).sort((e, t) => e[1] - t[1])[0] ?.[0];e && (n = e);
                                break
                            }
                        case `initialPlacement`:
                            n = o
                    }
                    if (r !== n) return {
                        reset: {
                            placement: n
                        }
                    }
                }
                return {}
            }
        }
    };

function Se(e, t) {
    return {
        top: e.top - t.height,
        right: e.right - t.width,
        bottom: e.bottom - t.height,
        left: e.left - t.width
    }
}

function Ce(e) {
    return j.some(t => e[t] >= 0)
}
var we = function(e) {
        return e === void 0 && (e = {}), {
            name: `hide`,
            options: e,
            async fn(t) {
                let {
                    rects: n,
                    platform: r
                } = t, {
                    strategy: i = `referenceHidden`,
                    ...a
                } = L(e, t);
                switch (i) {
                    case `referenceHidden`:
                        {
                            let e = Se(await r.detectOverflow(t, { ...a,
                                elementContext: `reference`
                            }), n.reference);
                            return {
                                data: {
                                    referenceHiddenOffsets: e,
                                    referenceHidden: Ce(e)
                                }
                            }
                        }
                    case `escaped`:
                        {
                            let e = Se(await r.detectOverflow(t, { ...a,
                                altBoundary: !0
                            }), n.floating);
                            return {
                                data: {
                                    escapedOffsets: e,
                                    escaped: Ce(e)
                                }
                            }
                        }
                    default:
                        return {}
                }
            }
        }
    },
    Te = new Set([`left`, `top`]);
async function Ee(e, t) {
    let {
        placement: n,
        platform: r,
        elements: i
    } = e, a = await (r.isRTL == null ? void 0 : r.isRTL(i.floating)), o = R(n), s = z(n), c = H(n) === `y`, l = Te.has(o) ? -1 : 1, u = a && c ? -1 : 1, d = L(t, e), {
        mainAxis: f,
        crossAxis: p,
        alignmentAxis: m
    } = typeof d == `number` ? {
        mainAxis: d,
        crossAxis: 0,
        alignmentAxis: null
    } : {
        mainAxis: d.mainAxis || 0,
        crossAxis: d.crossAxis || 0,
        alignmentAxis: d.alignmentAxis
    };
    return s && typeof m == `number` && (p = s === `end` ? m * -1 : m), c ? {
        x: p * u,
        y: f * l
    } : {
        x: f * l,
        y: p * u
    }
}
var De = function(e) {
        return e === void 0 && (e = 0), {
            name: `offset`,
            options: e,
            async fn(t) {
                var n;
                let {
                    x: r,
                    y: i,
                    placement: a,
                    middlewareData: o
                } = t, s = await Ee(t, e);
                return a === o.offset ?.placement && (n = o.arrow) != null && n.alignmentOffset ? {} : {
                    x: r + s.x,
                    y: i + s.y,
                    data: { ...s,
                        placement: a
                    }
                }
            }
        }
    },
    Oe = function(e) {
        return e === void 0 && (e = {}), {
            name: `shift`,
            options: e,
            async fn(t) {
                let {
                    x: n,
                    y: r,
                    placement: i,
                    platform: a
                } = t, {
                    mainAxis: o = !0,
                    crossAxis: s = !1,
                    limiter: c = {
                        fn: e => {
                            let {
                                x: t,
                                y: n
                            } = e;
                            return {
                                x: t,
                                y: n
                            }
                        }
                    },
                    ...l
                } = L(e, t), u = {
                    x: n,
                    y: r
                }, d = await a.detectOverflow(t, l), f = H(i), p = B(f), m = u[p], h = u[f], g = (e, t) => te(t + d[e === `y` ? `top` : `left`], t, t - d[e === `y` ? `bottom` : `right`]);
                o && (m = g(p, m)), s && (h = g(f, h));
                let _ = c.fn({ ...t,
                    [p]: m,
                    [f]: h
                });
                return { ..._,
                    data: {
                        x: _.x - n,
                        y: _.y - r,
                        enabled: {
                            [p]: o,
                            [f]: s
                        }
                    }
                }
            }
        }
    },
    ke = function(e) {
        return e === void 0 && (e = {}), {
            options: e,
            fn(t) {
                let {
                    x: n,
                    y: r,
                    placement: i,
                    rects: a,
                    middlewareData: o
                } = t, {
                    offset: s = 0,
                    mainAxis: c = !0,
                    crossAxis: l = !0
                } = L(e, t), u = {
                    x: n,
                    y: r
                }, d = H(i), f = B(d), p = u[f], m = u[d], h = L(s, t), g = typeof h == `number` ? {
                    mainAxis: h,
                    crossAxis: 0
                } : {
                    mainAxis: h.mainAxis ?? 0,
                    crossAxis: h.crossAxis ?? 0
                };
                if (c) {
                    let e = f === `y` ? `height` : `width`,
                        t = a.reference[f] - a.floating[e] + g.mainAxis,
                        n = a.reference[f] + a.reference[e] - g.mainAxis;
                    p < t ? p = t : p > n && (p = n)
                }
                if (l) {
                    let e = f === `y` ? `width` : `height`,
                        t = Te.has(R(i)),
                        n = a.reference[d] - a.floating[e] + (t && o.offset ?.[d] || 0) + (t ? 0 : g.crossAxis),
                        r = a.reference[d] + a.reference[e] + (t ? 0 : o.offset ?.[d] || 0) - (t ? g.crossAxis : 0);
                    m < n ? m = n : m > r && (m = r)
                }
                return {
                    [f]: p,
                    [d]: m
                }
            }
        }
    },
    Ae = function(e) {
        return e === void 0 && (e = {}), {
            name: `size`,
            options: e,
            async fn(t) {
                let {
                    placement: n,
                    rects: r,
                    platform: i,
                    elements: a
                } = t, {
                    apply: o = () => {},
                    ...s
                } = L(e, t), c = await i.detectOverflow(t, s), l = R(n), u = z(n), d = H(n) === `y`, {
                    width: f,
                    height: p
                } = r.floating, m, h;
                l === `top` || l === `bottom` ? (m = l, h = u === (await (i.isRTL == null ? void 0 : i.isRTL(a.floating)) ? `start` : `end`) ? `left` : `right`) : (h = l, m = u === `end` ? `top` : `bottom`);
                let g = p - c.top - c.bottom,
                    _ = f - c.left - c.right,
                    v = M(p - c[m], g),
                    y = M(f - c[h], _),
                    b = t.middlewareData.shift,
                    x = !b,
                    S = v,
                    C = y;
                b != null && b.enabled.x && (C = _), b != null && b.enabled.y && (S = g), x && !u && (d ? C = f - 2 * N(c.left, c.right) : S = p - 2 * N(c.top, c.bottom)), await o({ ...t,
                    availableWidth: C,
                    availableHeight: S
                });
                let w = await i.getDimensions(a.floating);
                return f !== w.width || p !== w.height ? {
                    reset: {
                        rects: !0
                    }
                } : {}
            }
        }
    };

function je() {
    return typeof window < `u`
}

function U(e) {
    return Me(e) ? (e.nodeName || ``).toLowerCase() : `#document`
}

function W(e) {
    var t;
    return (e == null || (t = e.ownerDocument) == null ? void 0 : t.defaultView) || window
}

function G(e) {
    return ((Me(e) ? e.ownerDocument : e.document) || window.document) ?.documentElement
}

function Me(e) {
    return je() ? e instanceof Node || e instanceof W(e).Node : !1
}

function K(e) {
    return je() ? e instanceof Element || e instanceof W(e).Element : !1
}

function q(e) {
    return je() ? e instanceof HTMLElement || e instanceof W(e).HTMLElement : !1
}

function Ne(e) {
    return !je() || typeof ShadowRoot > `u` ? !1 : e instanceof ShadowRoot || e instanceof W(e).ShadowRoot
}

function Pe(e) {
    let {
        overflow: t,
        overflowX: n,
        overflowY: r,
        display: i
    } = Y(e);
    return /auto|scroll|overlay|hidden|clip/.test(t + r + n) && i !== `inline` && i !== `contents`
}

function Fe(e) {
    return /^(table|td|th)$/.test(U(e))
}

function Ie(e) {
    try {
        if (e.matches(`:popover-open`)) return !0
    } catch {}
    try {
        return e.matches(`:modal`)
    } catch {
        return !1
    }
}
var Le = /transform|translate|scale|rotate|perspective|filter/,
    Re = /paint|layout|strict|content/,
    J = e => !!e && e !== `none`,
    ze;

function Be(e) {
    let t = K(e) ? Y(e) : e;
    return J(t.transform) || J(t.translate) || J(t.scale) || J(t.rotate) || J(t.perspective) || !He() && (J(t.backdropFilter) || J(t.filter)) || Le.test(t.willChange || ``) || Re.test(t.contain || ``)
}

function Ve(e) {
    let t = X(e);
    for (; q(t) && !Ue(t);) {
        if (Be(t)) return t;
        if (Ie(t)) return null;
        t = X(t)
    }
    return null
}

function He() {
    return ze ??= typeof CSS < `u` && CSS.supports && CSS.supports(`-webkit-backdrop-filter`, `none`), ze
}

function Ue(e) {
    return /^(html|body|#document)$/.test(U(e))
}

function Y(e) {
    return W(e).getComputedStyle(e)
}

function We(e) {
    return K(e) ? {
        scrollLeft: e.scrollLeft,
        scrollTop: e.scrollTop
    } : {
        scrollLeft: e.scrollX,
        scrollTop: e.scrollY
    }
}

function X(e) {
    if (U(e) === `html`) return e;
    let t = e.assignedSlot || e.parentNode || Ne(e) && e.host || G(e);
    return Ne(t) ? t.host : t
}

function Ge(e) {
    let t = X(e);
    return Ue(t) ? (e.ownerDocument || e).body : q(t) && Pe(t) ? t : Ge(t)
}

function Ke(e, t, n) {
    t === void 0 && (t = []), n === void 0 && (n = !0);
    let r = Ge(e),
        i = r === e.ownerDocument ?.body,
        a = W(r);
    if (i) {
        let e = qe(a);
        return t.concat(a, a.visualViewport || [], Pe(r) ? r : [], e && n ? Ke(e) : [])
    }
    return t.concat(r, Ke(r, [], n))
}

function qe(e) {
    return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null
}

function Je(e) {
    let t = Y(e),
        n = parseFloat(t.width) || 0,
        r = parseFloat(t.height) || 0,
        i = q(e),
        a = i ? e.offsetWidth : n,
        o = i ? e.offsetHeight : r,
        s = P(n) !== a || P(r) !== o;
    return s && (n = a, r = o), {
        width: n,
        height: r,
        $: s
    }
}

function Ye(e) {
    return K(e) ? e : e.contextElement
}

function Z(e) {
    let t = Ye(e);
    if (!q(t)) return I(1);
    let n = t.getBoundingClientRect(),
        {
            width: r,
            height: i,
            $: a
        } = Je(t),
        o = (a ? P(n.width) : n.width) / r,
        s = (a ? P(n.height) : n.height) / i;
    return (!o || !Number.isFinite(o)) && (o = 1), (!s || !Number.isFinite(s)) && (s = 1), {
        x: o,
        y: s
    }
}
var Xe = I(0);

function Ze(e) {
    let t = W(e);
    return !He() || !t.visualViewport ? Xe : {
        x: t.visualViewport.offsetLeft,
        y: t.visualViewport.offsetTop
    }
}

function Qe(e, t, n) {
    return t === void 0 && (t = !1), !!n && t && n === W(e)
}

function Q(e, t, n, r) {
    t === void 0 && (t = !1), n === void 0 && (n = !1);
    let i = e.getBoundingClientRect(),
        a = Ye(e),
        o = I(1);
    t && (r ? K(r) && (o = Z(r)) : o = Z(e));
    let s = Qe(a, n, r) ? Ze(a) : I(0),
        c = (i.left + s.x) / o.x,
        l = (i.top + s.y) / o.y,
        u = i.width / o.x,
        d = i.height / o.y;
    if (a && r) {
        let e = W(a),
            t = K(r) ? W(r) : r,
            n = e,
            i = qe(n);
        for (; i && t !== n;) {
            let e = Z(i),
                t = i.getBoundingClientRect(),
                r = Y(i),
                a = t.left + (i.clientLeft + parseFloat(r.paddingLeft)) * e.x,
                o = t.top + (i.clientTop + parseFloat(r.paddingTop)) * e.y;
            c *= e.x, l *= e.y, u *= e.x, d *= e.y, c += a, l += o, n = W(i), i = qe(n)
        }
    }
    return he({
        width: u,
        height: d,
        x: c,
        y: l
    })
}

function $e(e, t) {
    let n = We(e).scrollLeft;
    return t ? t.left + n : Q(G(e)).left + n
}

function et(e, t) {
    let n = e.getBoundingClientRect();
    return {
        x: n.left + t.scrollLeft - $e(e, n),
        y: n.top + t.scrollTop
    }
}

function tt(e) {
    let {
        elements: t,
        rect: n,
        offsetParent: r,
        strategy: i
    } = e, a = i === `fixed`, o = G(r), s = t ? Ie(t.floating) : !1;
    if (r === o || s && a) return n;
    let c = {
            scrollLeft: 0,
            scrollTop: 0
        },
        l = I(1),
        u = I(0),
        d = q(r);
    if ((d || !a) && ((U(r) !== `body` || Pe(o)) && (c = We(r)), d)) {
        let e = Q(r);
        l = Z(r), u.x = e.x + r.clientLeft, u.y = e.y + r.clientTop
    }
    let f = o && !d && !a ? et(o, c) : I(0);
    return {
        width: n.width * l.x,
        height: n.height * l.y,
        x: n.x * l.x - c.scrollLeft * l.x + u.x + f.x,
        y: n.y * l.y - c.scrollTop * l.y + u.y + f.y
    }
}

function nt(e) {
    return e.getClientRects ? Array.from(e.getClientRects()) : []
}

function rt(e) {
    let t = We(e),
        n = e.ownerDocument.body,
        r = N(e.scrollWidth, e.clientWidth, n.scrollWidth, n.clientWidth),
        i = N(e.scrollHeight, e.clientHeight, n.scrollHeight, n.clientHeight),
        a = -t.scrollLeft + $e(e),
        o = -t.scrollTop;
    return Y(n).direction === `rtl` && (a += N(e.clientWidth, n.clientWidth) - r), {
        width: r,
        height: i,
        x: a,
        y: o
    }
}
var it = 25;

function at(e, t, n) {
    n === void 0 && (n = `viewport`);
    let r = n === `layoutViewport`,
        i = W(e),
        a = G(e),
        o = i.visualViewport,
        s = a.clientWidth,
        c = a.clientHeight,
        l = 0,
        u = 0;
    if (o) {
        let e = !He() || t === `fixed`;
        r ? e || (l = -o.offsetLeft, u = -o.offsetTop) : (s = o.width, c = o.height, e && (l = o.offsetLeft, u = o.offsetTop))
    }
    if ($e(a) <= 0) {
        let e = a.ownerDocument,
            t = e.body,
            n = getComputedStyle(t),
            r = e.compatMode === `CSS1Compat` && parseFloat(n.marginLeft) + parseFloat(n.marginRight) || 0,
            i = Math.abs(a.clientWidth - t.clientWidth - r),
            o = getComputedStyle(a).scrollbarGutter === `stable both-edges` ? i / 2 : i;
        o <= it && (s -= o)
    }
    return {
        width: s,
        height: c,
        x: l,
        y: u
    }
}

function ot(e, t) {
    let n = Q(e, !0, t === `fixed`),
        r = n.top + e.clientTop,
        i = n.left + e.clientLeft,
        a = Z(e);
    return {
        width: e.clientWidth * a.x,
        height: e.clientHeight * a.y,
        x: i * a.x,
        y: r * a.y
    }
}

function st(e, t, n) {
    let r;
    if (t === `viewport` || t === `layoutViewport`) r = at(e, n, t);
    else if (t === `document`) r = rt(G(e));
    else if (K(t)) r = ot(t, n);
    else {
        let n = Ze(e);
        r = {
            x: t.x - n.x,
            y: t.y - n.y,
            width: t.width,
            height: t.height
        }
    }
    return he(r)
}

function ct(e, t) {
    let n = t.get(e);
    if (n) return n;
    let r = Ke(e, [], !1).filter(e => K(e) && U(e) !== `body`),
        i = null,
        a = Y(e).position === `fixed`,
        o = a ? X(e) : e;
    for (; K(o) && !Ue(o);) {
        let e = Y(o),
            t = Be(o),
            n = i ? i.position : a ? `fixed` : ``;
        !t && (n === `fixed` || n === `absolute` && e.position === `static`) ? r = r.filter(e => e !== o) : i = e, o = X(o)
    }
    return t.set(e, r), r
}

function lt(e) {
    let {
        element: t,
        boundary: n,
        rootBoundary: r,
        strategy: i
    } = e, a = [...n === `clippingAncestors` ? Ie(t) ? [] : ct(t, this._c) : [].concat(n), r], o = st(t, a[0], i), s = o.top, c = o.right, l = o.bottom, u = o.left;
    for (let e = 1; e < a.length; e++) {
        let n = st(t, a[e], i);
        s = N(n.top, s), c = M(n.right, c), l = M(n.bottom, l), u = N(n.left, u)
    }
    return {
        width: c - u,
        height: l - s,
        x: u,
        y: s
    }
}

function ut(e) {
    let {
        width: t,
        height: n
    } = Je(e);
    return {
        width: t,
        height: n
    }
}

function dt(e, t, n) {
    let r = q(t),
        i = G(t),
        a = n === `fixed`,
        o = Q(e, !0, a, t),
        s = {
            scrollLeft: 0,
            scrollTop: 0
        },
        c = I(0);
    if ((r || !a) && ((U(t) !== `body` || Pe(i)) && (s = We(t)), r)) {
        let e = Q(t, !0, a, t);
        c.x = e.x + t.clientLeft, c.y = e.y + t.clientTop
    }!r && i && (c.x = $e(i));
    let l = i && !r && !a ? et(i, s) : I(0);
    return {
        x: o.left + s.scrollLeft - c.x - l.x,
        y: o.top + s.scrollTop - c.y - l.y,
        width: o.width,
        height: o.height
    }
}

function ft(e) {
    return Y(e).position === `static`
}

function pt(e, t) {
    if (!q(e) || Y(e).position === `fixed`) return null;
    if (t) return t(e);
    let n = e.offsetParent;
    return G(e) === n && (n = n.ownerDocument.body), n
}

function mt(e, t) {
    let n = W(e);
    if (Ie(e)) return n;
    if (!q(e)) {
        let t = X(e);
        for (; t && !Ue(t);) {
            if (K(t) && !ft(t)) return t;
            t = X(t)
        }
        return n
    }
    let r = pt(e, t);
    for (; r && Fe(r) && ft(r);) r = pt(r, t);
    return r && Ue(r) && ft(r) && !Be(r) ? n : r || Ve(e) || n
}
var ht = async function(e) {
    let t = this.getOffsetParent || mt,
        n = this.getDimensions,
        r = await n(e.floating);
    return {
        reference: dt(e.reference, await t(e.floating), e.strategy),
        floating: {
            x: 0,
            y: 0,
            width: r.width,
            height: r.height
        }
    }
};

function gt(e) {
    return Y(e).direction === `rtl`
}
var _t = {
    convertOffsetParentRelativeRectToViewportRelativeRect: tt,
    getDocumentElement: G,
    getClippingRect: lt,
    getOffsetParent: mt,
    getElementRects: ht,
    getClientRects: nt,
    getDimensions: ut,
    getScale: Z,
    isElement: K,
    isRTL: gt
};

function vt(e, t) {
    return e.x === t.x && e.y === t.y && e.width === t.width && e.height === t.height
}

function yt(e, t, n) {
    let r = null,
        i, a = G(e);

    function o() {
        var e;
        clearTimeout(i), (e = r) == null || e.disconnect(), r = null
    }

    function s(n, c) {
        n === void 0 && (n = !1), c === void 0 && (c = 1), o();
        let l = e.getBoundingClientRect(),
            {
                left: u,
                top: d,
                width: f,
                height: p
            } = l;
        if (n || t(), !f || !p) return;
        let m = F(d),
            h = F(a.clientWidth - (u + f)),
            g = F(a.clientHeight - (d + p)),
            _ = F(u),
            v = {
                rootMargin: -m + `px ` + -h + `px ` + -g + `px ` + -_ + `px`,
                threshold: N(0, M(1, c)) || 1
            },
            y = !0;

        function b(t) {
            let n = t[0].intersectionRatio;
            if (!vt(l, e.getBoundingClientRect())) return s();
            if (n !== c) {
                if (!y) return s();
                n ? s(!1, n) : i = setTimeout(() => {
                    s(!1, 1e-7)
                }, 1e3)
            }
            y = !1
        }
        try {
            r = new IntersectionObserver(b, { ...v,
                root: a.ownerDocument
            })
        } catch {
            r = new IntersectionObserver(b, v)
        }
        r.observe(e)
    }
    let c = W(e),
        l = () => s(n);
    return c.addEventListener(`resize`, l), s(!0), () => {
        c.removeEventListener(`resize`, l), o()
    }
}

function bt(e, t, n, r) {
    r === void 0 && (r = {});
    let {
        ancestorScroll: i = !0,
        ancestorResize: a = !0,
        elementResize: o = typeof ResizeObserver == `function`,
        layoutShift: s = typeof IntersectionObserver == `function`,
        animationFrame: c = !1
    } = r, l = Ye(e), u = i || a ? [...l ? Ke(l) : [], ...t ? Ke(t) : []] : [];
    u.forEach(e => {
        i && e.addEventListener(`scroll`, n), a && e.addEventListener(`resize`, n)
    });
    let d = l && s ? yt(l, n, a) : null,
        f = -1,
        p = null;
    o && (p = new ResizeObserver(e => {
        let [r] = e;
        r && r.target === l && p && t && (p.unobserve(t), cancelAnimationFrame(f), f = requestAnimationFrame(() => {
            var e;
            (e = p) == null || e.observe(t)
        })), n()
    }), l && !c && p.observe(l), t && p.observe(t));
    let m, h = c ? Q(e) : null;
    c && g();

    function g() {
        let t = Q(e);
        h && !vt(h, t) && n(), h = t, m = requestAnimationFrame(g)
    }
    return n(), () => {
        var e;
        u.forEach(e => {
            i && e.removeEventListener(`scroll`, n), a && e.removeEventListener(`resize`, n)
        }), d ?.(), (e = p) == null || e.disconnect(), p = null, c && cancelAnimationFrame(m)
    }
}
var xt = De,
    St = Oe,
    Ct = xe,
    wt = Ae,
    Tt = we,
    Et = be,
    Dt = ke,
    Ot = (e, t, n) => {
        let r = new Map,
            i = n ?? {},
            a = { ..._t,
                ...i.platform,
                _c: r
            };
        return ye(e, t, { ...i,
            platform: a
        })
    },
    kt = e(r(), 1),
    At = typeof document < `u` ? d.useLayoutEffect : function() {};

function jt(e, t) {
    if (e === t) return !0;
    if (typeof e != typeof t) return !1;
    if (typeof e == `function` && e.toString() === t.toString()) return !0;
    let n, r, i;
    if (e && t && typeof e == `object`) {
        if (Array.isArray(e)) {
            if (n = e.length, n !== t.length) return !1;
            for (r = n; r-- !== 0;)
                if (!jt(e[r], t[r])) return !1;
            return !0
        }
        if (i = Object.keys(e), n = i.length, n !== Object.keys(t).length) return !1;
        for (r = n; r-- !== 0;)
            if (!{}.hasOwnProperty.call(t, i[r])) return !1;
        for (r = n; r-- !== 0;) {
            let n = i[r];
            if (!(n === `_owner` && e.$$typeof) && !jt(e[n], t[n])) return !1
        }
        return !0
    }
    return e !== e && t !== t
}

function Mt(e) {
    return typeof window > `u` ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1
}

function Nt(e, t) {
    let n = Mt(e);
    return Math.round(t * n) / n
}

function Pt(e) {
    let t = d.useRef(e);
    return At(() => {
        t.current = e
    }), t
}

function Ft(e) {
    e === void 0 && (e = {});
    let {
        placement: t = `bottom`,
        strategy: n = `absolute`,
        middleware: r = [],
        platform: i,
        elements: {
            reference: a,
            floating: o
        } = {},
        transform: s = !0,
        whileElementsMounted: c,
        open: l
    } = e, [u, f] = d.useState({
        x: 0,
        y: 0,
        strategy: n,
        placement: t,
        middlewareData: {},
        isPositioned: !1
    }), [p, m] = d.useState(r);
    jt(p, r) || m(r);
    let [h, g] = d.useState(null), [_, v] = d.useState(null), y = d.useCallback(e => {
        e !== C.current && (C.current = e, g(e))
    }, []), b = d.useCallback(e => {
        e !== w.current && (w.current = e, v(e))
    }, []), x = a || h, S = o || _, C = d.useRef(null), w = d.useRef(null), T = d.useRef(u), E = c != null, D = Pt(c), O = Pt(i), k = Pt(l), A = d.useCallback(() => {
        if (!C.current || !w.current) return;
        let e = {
            placement: t,
            strategy: n,
            middleware: p
        };
        O.current && (e.platform = O.current), Ot(C.current, w.current, e).then(e => {
            let t = { ...e,
                isPositioned: k.current !== !1
            };
            j.current && !jt(T.current, t) && (T.current = t, kt.flushSync(() => {
                f(t)
            }))
        })
    }, [p, t, n, O, k]);
    At(() => {
        l === !1 && T.current.isPositioned && (T.current.isPositioned = !1, f(e => ({ ...e,
            isPositioned: !1
        })))
    }, [l]);
    let j = d.useRef(!1);
    At(() => (j.current = !0, () => {
        j.current = !1
    }), []), At(() => {
        if (x && (C.current = x), S && (w.current = S), x && S) {
            if (D.current) return D.current(x, S, A);
            A()
        }
    }, [x, S, A, D, E]);
    let M = d.useMemo(() => ({
            reference: C,
            floating: w,
            setReference: y,
            setFloating: b
        }), [y, b]),
        N = d.useMemo(() => ({
            reference: x,
            floating: S
        }), [x, S]),
        P = d.useMemo(() => {
            let e = {
                position: n,
                left: 0,
                top: 0
            };
            if (!N.floating) return e;
            let t = Nt(N.floating, u.x),
                r = Nt(N.floating, u.y);
            return s ? { ...e,
                transform: `translate(` + t + `px, ` + r + `px)`,
                ...Mt(N.floating) >= 1.5 && {
                    willChange: `transform`
                }
            } : {
                position: n,
                left: t,
                top: r
            }
        }, [n, s, N.floating, u.x, u.y]);
    return d.useMemo(() => ({ ...u,
        update: A,
        refs: M,
        elements: N,
        floatingStyles: P
    }), [u, A, M, N, P])
}
var It = e => {
        function t(e) {
            return {}.hasOwnProperty.call(e, `current`)
        }
        return {
            name: `arrow`,
            options: e,
            fn(n) {
                let {
                    element: r,
                    padding: i
                } = typeof e == `function` ? e(n) : e;
                return r && t(r) ? r.current == null ? {} : Et({
                    element: r.current,
                    padding: i
                }).fn(n) : r ? Et({
                    element: r,
                    padding: i
                }).fn(n) : {}
            }
        }
    },
    Lt = (e, t) => {
        let n = xt(e);
        return {
            name: n.name,
            fn: n.fn,
            options: [e, t]
        }
    },
    Rt = (e, t) => {
        let n = St(e);
        return {
            name: n.name,
            fn: n.fn,
            options: [e, t]
        }
    },
    zt = (e, t) => ({
        fn: Dt(e).fn,
        options: [e, t]
    }),
    Bt = (e, t) => {
        let n = Ct(e);
        return {
            name: n.name,
            fn: n.fn,
            options: [e, t]
        }
    },
    Vt = (e, t) => {
        let n = wt(e);
        return {
            name: n.name,
            fn: n.fn,
            options: [e, t]
        }
    },
    Ht = (e, t) => {
        let n = Tt(e);
        return {
            name: n.name,
            fn: n.fn,
            options: [e, t]
        }
    },
    Ut = (e, t) => {
        let n = It(e);
        return {
            name: n.name,
            fn: n.fn,
            options: [e, t]
        }
    },
    Wt = Object.defineProperty,
    $ = (e, t) => Wt(e, `name`, {
        value: t,
        configurable: !0
    }),
    Gt = `Popper`,
    [Kt, qt] = a(Gt),
    [Jt, Yt] = Kt(Gt),
    Xt = $(e => {
        let {
            __scopePopper: t,
            children: n
        } = e, [r, i] = d.useState(null), [a, o] = d.useState(void 0);
        return (0, f.jsx)(Jt, {
            scope: t,
            anchor: r,
            onAnchorChange: i,
            placementState: a,
            setPlacementState: o,
            children: n
        })
    }, `Popper`),
    Zt = `PopperAnchor`,
    Qt = d.forwardRef($(function(e, t) {
        let {
            __scopePopper: n,
            virtualRef: r,
            ...i
        } = e, a = Yt(Zt, n), s = d.useRef(null), l = a.onAnchorChange, u = d.useCallback(e => {
            s.current = e, e && l(e)
        }, [l]), p = o(t, u), m = d.useRef(null);
        d.useEffect(() => {
            if (!r) return;
            let e = m.current;
            m.current = r.current, e !== m.current && l(m.current)
        });
        let h = a.placementState && on(a.placementState),
            g = h ?.[0],
            _ = h ?.[1];
        return r ? null : (0, f.jsx)(c.div, {
            "data-radix-popper-side": g,
            "data-radix-popper-align": _,
            ...i,
            ref: p
        })
    }, `PopperAnchor`)),
    $t = `PopperContent`,
    [en, tn] = Kt($t),
    nn = d.forwardRef($(function(e, t) {
        let {
            __scopePopper: n,
            side: r = `bottom`,
            sideOffset: a = 0,
            align: s = `center`,
            alignOffset: p = 0,
            arrowPadding: m = 0,
            avoidCollisions: h = !0,
            collisionBoundary: g = [],
            collisionPadding: _ = 0,
            sticky: v = `partial`,
            hideWhenDetached: y = !1,
            updatePositionStrategy: b = `optimized`,
            onPlaced: x,
            ...S
        } = e, C = Yt($t, n), [w, T] = d.useState(null), E = o(t, T), [D, O] = d.useState(null), k = u(D), A = k ?.width ?? 0, j = k ?.height ?? 0, M = r + (s === `center` ? `` : `-` + s), N = typeof _ == `number` ? _ : {
            top: 0,
            right: 0,
            bottom: 0,
            left: 0,
            ..._
        }, P = Array.isArray(g) ? g : [g], F = P.length > 0, I = {
            padding: N,
            boundary: P.filter(rn),
            altBoundary: F
        }, {
            refs: ee,
            floatingStyles: te,
            placement: L,
            isPositioned: R,
            middlewareData: z
        } = Ft({
            strategy: `fixed`,
            placement: M,
            whileElementsMounted: $((...e) => bt(...e, {
                animationFrame: b === `always`
            }), `whileElementsMounted`),
            elements: {
                reference: C.anchor
            },
            middleware: [Lt({
                mainAxis: a + j,
                alignmentAxis: p
            }), h && Rt({
                mainAxis: !0,
                crossAxis: !1,
                limiter: v === `partial` ? zt() : void 0,
                ...I
            }), h && Bt({ ...I
            }), Vt({ ...I,
                apply: $(({
                    elements: e,
                    rects: t,
                    availableWidth: n,
                    availableHeight: r
                }) => {
                    let {
                        width: i,
                        height: a
                    } = t.reference, o = e.floating.style;
                    o.setProperty(`--radix-popper-available-width`, `${n}px`), o.setProperty(`--radix-popper-available-height`, `${r}px`), o.setProperty(`--radix-popper-anchor-width`, `${i}px`), o.setProperty(`--radix-popper-anchor-height`, `${a}px`)
                }, `apply`)
            }), D && Ut({
                element: D,
                padding: m
            }), an({
                arrowWidth: A,
                arrowHeight: j
            }), y && Ht({
                strategy: `referenceHidden`,
                ...I,
                boundary: F ? I.boundary : void 0
            })]
        }), B = C.setPlacementState;
        i(() => (B(L), () => {
            B(void 0)
        }), [L, B]);
        let [V, H] = on(L), ne = l(x);
        i(() => {
            R && ne ?.()
        }, [R, ne]);
        let re = z.arrow ?.x,
            ie = z.arrow ?.y,
            ae = z.arrow ?.centerOffset !== 0,
            [oe, se] = d.useState();
        return i(() => {
            w && se(window.getComputedStyle(w).zIndex)
        }, [w]), (0, f.jsx)(`div`, {
            ref: ee.setFloating,
            "data-radix-popper-content-wrapper": ``,
            style: { ...te,
                transform: R ? te.transform : `translate(0, -200%)`,
                minWidth: `max-content`,
                zIndex: oe,
                "--radix-popper-transform-origin": [z.transformOrigin ?.x, z.transformOrigin ?.y].join(` `),
                ...z.hide ?.referenceHidden && {
                    visibility: `hidden`,
                    pointerEvents: `none`
                }
            },
            dir: e.dir,
            children: (0, f.jsx)(en, {
                scope: n,
                placedSide: V,
                placedAlign: H,
                onArrowChange: O,
                arrowX: re,
                arrowY: ie,
                shouldHideArrow: ae,
                children: (0, f.jsx)(c.div, {
                    "data-side": V,
                    "data-align": H,
                    ...S,
                    ref: E,
                    style: { ...S.style,
                        animation: R ? S.style ?.animation : `none`
                    }
                })
            })
        })
    }, `PopperContent`));

function rn(e) {
    return e !== null
}
$(rn, `isNotNull`);
var an = $(e => ({
    name: `transformOrigin`,
    options: e,
    fn(t) {
        let {
            placement: n,
            rects: r,
            middlewareData: i
        } = t, a = i.arrow ?.centerOffset !== 0, o = a ? 0 : e.arrowWidth, s = a ? 0 : e.arrowHeight, [c, l] = on(n), u = {
            start: `0%`,
            center: `50%`,
            end: `100%`
        }[l], d = (i.arrow ?.x ?? 0) + o / 2, f = (i.arrow ?.y ?? 0) + s / 2, p = ``, m = ``;
        return c === `bottom` ? (p = a ? u : `${d}px`, m = `${-s}px`) : c === `top` ? (p = a ? u : `${d}px`, m = `${r.floating.height+s}px`) : c === `right` ? (p = `${-s}px`, m = a ? u : `${f}px`) : c === `left` && (p = `${r.floating.width+s}px`, m = a ? u : `${f}px`), {
            data: {
                x: p,
                y: m
            }
        }
    }
}), `transformOrigin`);

function on(e) {
    let [t, n = `center`] = e.split(`-`);
    return [t, n]
}
$(on, `getSideAndAlignFromPlacement`);
var sn = Xt,
    cn = Qt,
    ln = nn;
export {
    A as a, h as c, qt as i, ln as n, O as o, sn as r, k as s, cn as t
};