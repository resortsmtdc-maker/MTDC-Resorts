import {
    r as e
} from "./rolldown-runtime-hePW80VL.js";
import {
    n as t,
    t as n
} from "./jsx-runtime-DE3RlOCf.js";
import {
    r
} from "./dist-B0Orvaj5.js";
import {
    r as i
} from "./dist-B-uvUq6S.js";
var a = e(t(), 1),
    o = e(r(), 1),
    s = n(),
    c = Object.defineProperty,
    l = (e, t) => c(e, `name`, {
        value: t,
        configurable: !0
    }),
    u = [`a`, `button`, `div`, `form`, `h2`, `h3`, `img`, `input`, `label`, `li`, `nav`, `ol`, `p`, `select`, `span`, `svg`, `ul`].reduce((e, t) => {
        let n = i(`Primitive.${t}`),
            r = a.forwardRef((e, r) => {
                let {
                    asChild: i,
                    ...a
                } = e, o = i ? n : t;
                return typeof window < `u` && (window[Symbol.for(`radix-ui`)] = !0), (0, s.jsx)(o, { ...a,
                    ref: r
                })
            });
        return r.displayName = `Primitive.${t}`, { ...e,
            [t]: r
        }
    }, {});

function d(e, t) {
    e && o.flushSync(() => e.dispatchEvent(t))
}
l(d, `dispatchDiscreteCustomEvent`);
export {
    d as n, u as t
};