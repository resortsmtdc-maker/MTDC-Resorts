import {
    t as e
} from "./createLucideIcon-BZ5eRbaK.js";
var t = e(`chevron-down`, [
        [`path`, {
            d: `m6 9 6 6 6-6`,
            key: `qrunsl`
        }]
    ]),
    n = e(`chevron-up`, [
        [`path`, {
            d: `m18 15-6-6-6 6`,
            key: `153udz`
        }]
    ]);
export {
    t as n, n as t
};