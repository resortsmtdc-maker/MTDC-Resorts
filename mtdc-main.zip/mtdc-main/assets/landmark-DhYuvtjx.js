import {
    t as e
} from "./createLucideIcon-BZ5eRbaK.js";
var t = e(`landmark`, [
    [`path`, {
        d: `M10 18v-7`,
        key: `wt116b`
    }],
    [`path`, {
        d: `M11.12 2.198a2 2 0 0 1 1.76.006l7.866 3.847c.476.233.31.949-.22.949H3.474c-.53 0-.695-.716-.22-.949z`,
        key: `1m329m`
    }],
    [`path`, {
        d: `M14 18v-7`,
        key: `vav6t3`
    }],
    [`path`, {
        d: `M18 18v-7`,
        key: `aexdmj`
    }],
    [`path`, {
        d: `M3 22h18`,
        key: `8prr45`
    }],
    [`path`, {
        d: `M6 18v-7`,
        key: `1ivflk`
    }]
]);
export {
    t
};