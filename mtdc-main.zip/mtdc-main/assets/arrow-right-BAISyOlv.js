import {
    t as e
} from "./createLucideIcon-BZ5eRbaK.js";
var t = e(`arrow-right`, [
    [`path`, {
        d: `M5 12h14`,
        key: `1ays0h`
    }],
    [`path`, {
        d: `m12 5 7 7-7 7`,
        key: `xquz4c`
    }]
]);
export {
    t
};