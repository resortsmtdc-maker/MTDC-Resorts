import {
    r as e
} from "./rolldown-runtime-hePW80VL.js";
import {
    n as t,
    t as n
} from "./jsx-runtime-DE3RlOCf.js";
var r = Object.defineProperty,
    i = (e, t) => r(e, `name`, {
        value: t,
        configurable: !0
    }),
    a = !!(typeof window < `u` && window.document && window.document.createElement);

function o(e, t, {
    checkForDefaultPrevented: n = !0
} = {}) {
    return i(function(r) {
        if (e ?.(r), n === !1 || !r || !r.defaultPrevented) return t ?.(r)
    }, `handleEvent`)
}
i(o, `composeEventHandlers`);

function s(e) {
    if (!a) throw Error(`Cannot access window outside of the DOM`);
    return e ?.ownerDocument ?.defaultView ?? window
}
i(s, `getOwnerWindow`);

function c(e) {
    if (!a) throw Error(`Cannot access document outside of the DOM`);
    return e ?.ownerDocument ?? document
}
i(c, `getOwnerDocument`);

function l(e, t = !1) {
    let {
        activeElement: n
    } = c(e);
    if (!n ?.nodeName) return null;
    if (u(n) && n.contentDocument) return l(n.contentDocument.body, t);
    if (t) {
        let e = n.getAttribute(`aria-activedescendant`);
        if (e) {
            let t = c(n).getElementById(e);
            if (t) return t
        }
    }
    return n
}
i(l, `getActiveElement`);

function u(e) {
    return e.tagName === `IFRAME`
}
i(u, `isFrame`);
var d = e(t(), 1),
    f = n(),
    p = Object.defineProperty,
    m = (e, t) => p(e, `name`, {
        value: t,
        configurable: !0
    });

function h(e, t) {
    let n = d.createContext(t);
    n.displayName = e + `Context`;
    let r = m(e => {
        let {
            children: t,
            ...r
        } = e, i = d.useMemo(() => r, Object.values(r));
        return (0, f.jsx)(n.Provider, {
            value: i,
            children: t
        })
    }, `Provider`);
    r.displayName = e + `Provider`;

    function i(r, i = {}) {
        let {
            optional: a = !1
        } = i, o = d.useContext(n);
        if (o) return o;
        if (t !== void 0) return t;
        if (!a) throw Error(`\`${r}\` must be used within \`${e}\``)
    }
    return m(i, `useContext`), [r, i]
}
m(h, `createContext`);

function g(e, t = []) {
    let n = [];

    function r(t, r) {
        let i = d.createContext(r);
        i.displayName = t + `Context`;
        let a = n.length;
        n = [...n, r];
        let o = m(t => {
            let {
                scope: n,
                children: r,
                ...o
            } = t, s = n ?.[e] ?.[a] || i, c = d.useMemo(() => o, Object.values(o));
            return (0, f.jsx)(s.Provider, {
                value: c,
                children: r
            })
        }, `Provider`);
        o.displayName = t + `Provider`;

        function s(n, o, s = {}) {
            let {
                optional: c = !1
            } = s, l = o ?.[e] ?.[a] || i, u = d.useContext(l);
            if (u) return u;
            if (r !== void 0) return r;
            if (!c) throw Error(`\`${n}\` must be used within \`${t}\``)
        }
        return m(s, `useContext`), [o, s]
    }
    m(r, `createContext`);
    let i = m(() => {
        let t = n.map(e => d.createContext(e));
        return m(function(n) {
            let r = n ?.[e] || t;
            return d.useMemo(() => ({
                [`__scope${e}`]: { ...n,
                    [e]: r
                }
            }), [n, r])
        }, `useScope`)
    }, `createScope`);
    return i.scopeName = e, [r, _(i, ...t)]
}
m(g, `createContextScope`);

function _(...e) {
    let t = e[0];
    if (e.length === 1) return t;
    let n = m(() => {
        let n = e.map(e => ({
            useScope: e(),
            scopeName: e.scopeName
        }));
        return m(function(e) {
            let r = n.reduce((t, {
                useScope: n,
                scopeName: r
            }) => {
                let i = n(e)[`__scope${r}`];
                return { ...t,
                    ...i
                }
            }, {});
            return d.useMemo(() => ({
                [`__scope${t.scopeName}`]: r
            }), [r])
        }, `useComposedScopes`)
    }, `createScope`);
    return n.scopeName = t.scopeName, n
}
m(_, `composeContextScopes`);
var v = globalThis ?.document ? d.useLayoutEffect : () => {},
    y = Object.defineProperty,
    b = (e, t) => y(e, `name`, {
        value: t,
        configurable: !0
    }),
    x = d.useEffectEvent,
    S = d.useInsertionEffect;

function C(e) {
    if (typeof x == `function`) return x(e);
    let t = d.useRef(() => {
        throw Error(`Cannot call an event handler while rendering.`)
    });
    return typeof S == `function` ? S(() => {
        t.current = e
    }) : v(() => {
        t.current = e
    }), d.useMemo(() => ((...e) => t.current ?.(...e)), [])
}
b(C, `useEffectEvent`);
var w = Object.defineProperty,
    T = (e, t) => w(e, `name`, {
        value: t,
        configurable: !0
    }),
    E = d.useInsertionEffect || v;

function D({
    prop: e,
    defaultProp: t,
    onChange: n = T(() => {}, `onChange`),
    caller: r
}) {
    let [i, a, o] = O({
        defaultProp: t,
        onChange: n
    }), s = e !== void 0;
    return [s ? e : i, d.useCallback(t => {
        if (s) {
            let n = k(t) ? t(e) : t;
            n !== e && o.current ?.(n)
        } else a(t)
    }, [s, e, a, o])]
}
T(D, `useControllableState`);

function O({
    defaultProp: e,
    onChange: t
}) {
    let [n, r] = d.useState(e), i = d.useRef(n), a = d.useRef(t);
    return E(() => {
        a.current = t
    }, [t]), d.useEffect(() => {
        i.current !== n && (a.current ?.(n), i.current = n)
    }, [n, i]), [n, r, a]
}
T(O, `useUncontrolledState`);

function k(e) {
    return typeof e == `function`
}
T(k, `isFunction`);
var A = Symbol(`RADIX:SYNC_STATE`);

function j(e, t, n, r) {
    let {
        prop: i,
        defaultProp: a,
        onChange: o,
        caller: s
    } = t, c = i !== void 0, l = C(o), u = [{ ...n,
        state: a
    }];
    r && u.push(r);
    let [f, p] = d.useReducer((t, n) => {
        if (n.type === A) return { ...t,
            state: n.state
        };
        let r = e(t, n);
        return c && !Object.is(r.state, t.state) && l(r.state), r
    }, ...u), m = f.state, h = d.useRef(m);
    d.useEffect(() => {
        h.current !== m && (h.current = m, c || l(m))
    }, [m, h, c]);
    let g = d.useMemo(() => i === void 0 ? f : { ...f,
        state: i
    }, [f, i]);
    return d.useEffect(() => {
        c && !Object.is(i, f.state) && p({
            type: A,
            state: i
        })
    }, [i, f.state, c]), [g, p]
}
T(j, `useControllableStateReducer`);
export {
    o as i, v as n, g as r, D as t
};