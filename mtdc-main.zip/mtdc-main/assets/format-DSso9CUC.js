var e = 365.2425,
    t = 6048e5,
    n = 86400;
n * 7, n * e / 12 * 3;
var r = Symbol.for(`constructDateFrom`);

function i(e, t) {
    return typeof e == `function` ? e(t) : e && typeof e == `object` && r in e ? e[r](t) : e instanceof Date ? new e.constructor(t) : new Date(t)
}

function a(e, t) {
    return i(t || e, e)
}
var o = {};

function s() {
    return o
}

function c(e, t) {
    let n = s(),
        r = t ?.weekStartsOn ?? t ?.locale ?.options ?.weekStartsOn ?? n.weekStartsOn ?? n.locale ?.options ?.weekStartsOn ?? 0,
        i = a(e, t ?.in),
        o = i.getDay(),
        c = (o < r ? 7 : 0) + o - r;
    return i.setDate(i.getDate() - c), i.setHours(0, 0, 0, 0), i
}

function l(e, t) {
    return c(e, { ...t,
        weekStartsOn: 1
    })
}

function u(e, t) {
    let n = a(e, t ?.in),
        r = n.getFullYear(),
        o = i(n, 0);
    o.setFullYear(r + 1, 0, 4), o.setHours(0, 0, 0, 0);
    let s = l(o),
        c = i(n, 0);
    c.setFullYear(r, 0, 4), c.setHours(0, 0, 0, 0);
    let u = l(c);
    return n.getTime() >= s.getTime() ? r + 1 : n.getTime() >= u.getTime() ? r : r - 1
}

function d(e) {
    let t = a(e),
        n = new Date(Date.UTC(t.getFullYear(), t.getMonth(), t.getDate(), t.getHours(), t.getMinutes(), t.getSeconds(), t.getMilliseconds()));
    return n.setUTCFullYear(t.getFullYear()), e - +n
}

function f(e, ...t) {
    let n = i.bind(null, e || t.find(e => typeof e == `object`));
    return t.map(n)
}

function p(e, t) {
    let n = a(e, t ?.in);
    return n.setHours(0, 0, 0, 0), n
}

function m(e, t, n) {
    let [r, i] = f(n ?.in, e, t), a = p(r), o = p(i), s = +a - d(a), c = +o - d(o);
    return Math.round((s - c) / 864e5)
}

function h(e, t) {
    let n = u(e, t),
        r = i(t ?.in || e, 0);
    return r.setFullYear(n, 0, 4), r.setHours(0, 0, 0, 0), l(r)
}

function g(e) {
    return e instanceof Date || typeof e == `object` && Object.prototype.toString.call(e) === `[object Date]`
}

function _(e) {
    return !(!g(e) && typeof e != `number` || isNaN(+a(e)))
}

function v(e, t) {
    let n = a(e, t ?.in);
    return n.setFullYear(n.getFullYear(), 0, 1), n.setHours(0, 0, 0, 0), n
}
var y = {
        lessThanXSeconds: {
            one: `less than a second`,
            other: `less than {{count}} seconds`
        },
        xSeconds: {
            one: `1 second`,
            other: `{{count}} seconds`
        },
        halfAMinute: `half a minute`,
        lessThanXMinutes: {
            one: `less than a minute`,
            other: `less than {{count}} minutes`
        },
        xMinutes: {
            one: `1 minute`,
            other: `{{count}} minutes`
        },
        aboutXHours: {
            one: `about 1 hour`,
            other: `about {{count}} hours`
        },
        xHours: {
            one: `1 hour`,
            other: `{{count}} hours`
        },
        xDays: {
            one: `1 day`,
            other: `{{count}} days`
        },
        aboutXWeeks: {
            one: `about 1 week`,
            other: `about {{count}} weeks`
        },
        xWeeks: {
            one: `1 week`,
            other: `{{count}} weeks`
        },
        aboutXMonths: {
            one: `about 1 month`,
            other: `about {{count}} months`
        },
        xMonths: {
            one: `1 month`,
            other: `{{count}} months`
        },
        aboutXYears: {
            one: `about 1 year`,
            other: `about {{count}} years`
        },
        xYears: {
            one: `1 year`,
            other: `{{count}} years`
        },
        overXYears: {
            one: `over 1 year`,
            other: `over {{count}} years`
        },
        almostXYears: {
            one: `almost 1 year`,
            other: `almost {{count}} years`
        }
    },
    b = (e, t, n) => {
        let r, i = y[e];
        return r = typeof i == `string` ? i : t === 1 ? i.one : i.other.replace(`{{count}}`, t.toString()), n ?.addSuffix ? n.comparison && n.comparison > 0 ? `in ` + r : r + ` ago` : r
    };

function x(e) {
    return (t = {}) => {
        let n = t.width ? String(t.width) : e.defaultWidth;
        return e.formats[n] || e.formats[e.defaultWidth]
    }
}
var S = {
        date: x({
            formats: {
                full: `EEEE, MMMM do, y`,
                long: `MMMM do, y`,
                medium: `MMM d, y`,
                short: `MM/dd/yyyy`
            },
            defaultWidth: `full`
        }),
        time: x({
            formats: {
                full: `h:mm:ss a zzzz`,
                long: `h:mm:ss a z`,
                medium: `h:mm:ss a`,
                short: `h:mm a`
            },
            defaultWidth: `full`
        }),
        dateTime: x({
            formats: {
                full: `{{date}} 'at' {{time}}`,
                long: `{{date}} 'at' {{time}}`,
                medium: `{{date}}, {{time}}`,
                short: `{{date}}, {{time}}`
            },
            defaultWidth: `full`
        })
    },
    C = {
        lastWeek: `'last' eeee 'at' p`,
        yesterday: `'yesterday at' p`,
        today: `'today at' p`,
        tomorrow: `'tomorrow at' p`,
        nextWeek: `eeee 'at' p`,
        other: `P`
    },
    w = (e, t, n, r) => C[e];

function T(e) {
    return (t, n) => {
        let r = n ?.context ? String(n.context) : `standalone`,
            i;
        if (r === `formatting` && e.formattingValues) {
            let t = e.defaultFormattingWidth || e.defaultWidth,
                r = n ?.width ? String(n.width) : t;
            i = e.formattingValues[r] || e.formattingValues[t]
        } else {
            let t = e.defaultWidth,
                r = n ?.width ? String(n.width) : e.defaultWidth;
            i = e.values[r] || e.values[t]
        }
        let a = e.argumentCallback ? e.argumentCallback(t) : t;
        return i[a]
    }
}
var E = {
    ordinalNumber: (e, t) => {
        let n = Number(e),
            r = n % 100;
        if (r > 20 || r < 10) switch (r % 10) {
            case 1:
                return n + `st`;
            case 2:
                return n + `nd`;
            case 3:
                return n + `rd`
        }
        return n + `th`
    },
    era: T({
        values: {
            narrow: [`B`, `A`],
            abbreviated: [`BC`, `AD`],
            wide: [`Before Christ`, `Anno Domini`]
        },
        defaultWidth: `wide`
    }),
    quarter: T({
        values: {
            narrow: [`1`, `2`, `3`, `4`],
            abbreviated: [`Q1`, `Q2`, `Q3`, `Q4`],
            wide: [`1st quarter`, `2nd quarter`, `3rd quarter`, `4th quarter`]
        },
        defaultWidth: `wide`,
        argumentCallback: e => e - 1
    }),
    month: T({
        values: {
            narrow: [`J`, `F`, `M`, `A`, `M`, `J`, `J`, `A`, `S`, `O`, `N`, `D`],
            abbreviated: [`Jan`, `Feb`, `Mar`, `Apr`, `May`, `Jun`, `Jul`, `Aug`, `Sep`, `Oct`, `Nov`, `Dec`],
            wide: [`January`, `February`, `March`, `April`, `May`, `June`, `July`, `August`, `September`, `October`, `November`, `December`]
        },
        defaultWidth: `wide`
    }),
    day: T({
        values: {
            narrow: [`S`, `M`, `T`, `W`, `T`, `F`, `S`],
            short: [`Su`, `Mo`, `Tu`, `We`, `Th`, `Fr`, `Sa`],
            abbreviated: [`Sun`, `Mon`, `Tue`, `Wed`, `Thu`, `Fri`, `Sat`],
            wide: [`Sunday`, `Monday`, `Tuesday`, `Wednesday`, `Thursday`, `Friday`, `Saturday`]
        },
        defaultWidth: `wide`
    }),
    dayPeriod: T({
        values: {
            narrow: {
                am: `a`,
                pm: `p`,
                midnight: `mi`,
                noon: `n`,
                morning: `morning`,
                afternoon: `afternoon`,
                evening: `evening`,
                night: `night`
            },
            abbreviated: {
                am: `AM`,
                pm: `PM`,
                midnight: `midnight`,
                noon: `noon`,
                morning: `morning`,
                afternoon: `afternoon`,
                evening: `evening`,
                night: `night`
            },
            wide: {
                am: `a.m.`,
                pm: `p.m.`,
                midnight: `midnight`,
                noon: `noon`,
                morning: `morning`,
                afternoon: `afternoon`,
                evening: `evening`,
                night: `night`
            }
        },
        defaultWidth: `wide`,
        formattingValues: {
            narrow: {
                am: `a`,
                pm: `p`,
                midnight: `mi`,
                noon: `n`,
                morning: `in the morning`,
                afternoon: `in the afternoon`,
                evening: `in the evening`,
                night: `at night`
            },
            abbreviated: {
                am: `AM`,
                pm: `PM`,
                midnight: `midnight`,
                noon: `noon`,
                morning: `in the morning`,
                afternoon: `in the afternoon`,
                evening: `in the evening`,
                night: `at night`
            },
            wide: {
                am: `a.m.`,
                pm: `p.m.`,
                midnight: `midnight`,
                noon: `noon`,
                morning: `in the morning`,
                afternoon: `in the afternoon`,
                evening: `in the evening`,
                night: `at night`
            }
        },
        defaultFormattingWidth: `wide`
    })
};

function D(e) {
    return (t, n = {}) => {
        let r = n.width,
            i = r && e.matchPatterns[r] || e.matchPatterns[e.defaultMatchWidth],
            a = t.match(i);
        if (!a) return null;
        let o = a[0],
            s = r && e.parsePatterns[r] || e.parsePatterns[e.defaultParseWidth],
            c = Array.isArray(s) ? k(s, e => e.test(o)) : O(s, e => e.test(o)),
            l;
        l = e.valueCallback ? e.valueCallback(c) : c, l = n.valueCallback ? n.valueCallback(l) : l;
        let u = t.slice(o.length);
        return {
            value: l,
            rest: u
        }
    }
}

function O(e, t) {
    for (let n in e)
        if (Object.prototype.hasOwnProperty.call(e, n) && t(e[n])) return n
}

function k(e, t) {
    for (let n = 0; n < e.length; n++)
        if (t(e[n])) return n
}

function A(e) {
    return (t, n = {}) => {
        let r = t.match(e.matchPattern);
        if (!r) return null;
        let i = r[0],
            a = t.match(e.parsePattern);
        if (!a) return null;
        let o = e.valueCallback ? e.valueCallback(a[0]) : a[0];
        o = n.valueCallback ? n.valueCallback(o) : o;
        let s = t.slice(i.length);
        return {
            value: o,
            rest: s
        }
    }
}
var j = {
    code: `en-US`,
    formatDistance: b,
    formatLong: S,
    formatRelative: w,
    localize: E,
    match: {
        ordinalNumber: A({
            matchPattern: /^(\d+)(th|st|nd|rd)?/i,
            parsePattern: /\d+/i,
            valueCallback: e => parseInt(e, 10)
        }),
        era: D({
            matchPatterns: {
                narrow: /^(b|a)/i,
                abbreviated: /^(b\.?\s?c\.?|b\.?\s?c\.?\s?e\.?|a\.?\s?d\.?|c\.?\s?e\.?)/i,
                wide: /^(before christ|before common era|anno domini|common era)/i
            },
            defaultMatchWidth: `wide`,
            parsePatterns: {
                any: [/^b/i, /^(a|c)/i]
            },
            defaultParseWidth: `any`
        }),
        quarter: D({
            matchPatterns: {
                narrow: /^[1234]/i,
                abbreviated: /^q[1234]/i,
                wide: /^[1234](th|st|nd|rd)? quarter/i
            },
            defaultMatchWidth: `wide`,
            parsePatterns: {
                any: [/1/i, /2/i, /3/i, /4/i]
            },
            defaultParseWidth: `any`,
            valueCallback: e => e + 1
        }),
        month: D({
            matchPatterns: {
                narrow: /^[jfmasond]/i,
                abbreviated: /^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i,
                wide: /^(january|february|march|april|may|june|july|august|september|october|november|december)/i
            },
            defaultMatchWidth: `wide`,
            parsePatterns: {
                narrow: [/^j/i, /^f/i, /^m/i, /^a/i, /^m/i, /^j/i, /^j/i, /^a/i, /^s/i, /^o/i, /^n/i, /^d/i],
                any: [/^ja/i, /^f/i, /^mar/i, /^ap/i, /^may/i, /^jun/i, /^jul/i, /^au/i, /^s/i, /^o/i, /^n/i, /^d/i]
            },
            defaultParseWidth: `any`
        }),
        day: D({
            matchPatterns: {
                narrow: /^[smtwf]/i,
                short: /^(su|mo|tu|we|th|fr|sa)/i,
                abbreviated: /^(sun|mon|tue|wed|thu|fri|sat)/i,
                wide: /^(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/i
            },
            defaultMatchWidth: `wide`,
            parsePatterns: {
                narrow: [/^s/i, /^m/i, /^t/i, /^w/i, /^t/i, /^f/i, /^s/i],
                any: [/^su/i, /^m/i, /^tu/i, /^w/i, /^th/i, /^f/i, /^sa/i]
            },
            defaultParseWidth: `any`
        }),
        dayPeriod: D({
            matchPatterns: {
                narrow: /^(a|p|mi|n|(in the|at) (morning|afternoon|evening|night))/i,
                any: /^([ap]\.?\s?m\.?|midnight|noon|(in the|at) (morning|afternoon|evening|night))/i
            },
            defaultMatchWidth: `any`,
            parsePatterns: {
                any: {
                    am: /^a/i,
                    pm: /^p/i,
                    midnight: /^mi/i,
                    noon: /^no/i,
                    morning: /morning/i,
                    afternoon: /afternoon/i,
                    evening: /evening/i,
                    night: /night/i
                }
            },
            defaultParseWidth: `any`
        })
    },
    options: {
        weekStartsOn: 0,
        firstWeekContainsDate: 1
    }
};

function M(e, t) {
    let n = a(e, t ?.in);
    return m(n, v(n)) + 1
}

function N(e, n) {
    let r = a(e, n ?.in),
        i = l(r) - +h(r);
    return Math.round(i / t) + 1
}

function P(e, t) {
    let n = a(e, t ?.in),
        r = n.getFullYear(),
        o = s(),
        l = t ?.firstWeekContainsDate ?? t ?.locale ?.options ?.firstWeekContainsDate ?? o.firstWeekContainsDate ?? o.locale ?.options ?.firstWeekContainsDate ?? 1,
        u = i(t ?.in || e, 0);
    u.setFullYear(r + 1, 0, l), u.setHours(0, 0, 0, 0);
    let d = c(u, t),
        f = i(t ?.in || e, 0);
    f.setFullYear(r, 0, l), f.setHours(0, 0, 0, 0);
    let p = c(f, t);
    return +n >= +d ? r + 1 : +n >= +p ? r : r - 1
}

function F(e, t) {
    let n = s(),
        r = t ?.firstWeekContainsDate ?? t ?.locale ?.options ?.firstWeekContainsDate ?? n.firstWeekContainsDate ?? n.locale ?.options ?.firstWeekContainsDate ?? 1,
        a = P(e, t),
        o = i(t ?.in || e, 0);
    return o.setFullYear(a, 0, r), o.setHours(0, 0, 0, 0), c(o, t)
}

function I(e, n) {
    let r = a(e, n ?.in),
        i = c(r, n) - +F(r, n);
    return Math.round(i / t) + 1
}

function L(e, t) {
    return (e < 0 ? `-` : ``) + Math.abs(e).toString().padStart(t, `0`)
}
var R = {
        y(e, t) {
            let n = e.getFullYear(),
                r = n > 0 ? n : 1 - n;
            return L(t === `yy` ? r % 100 : r, t.length)
        },
        M(e, t) {
            let n = e.getMonth();
            return t === `M` ? String(n + 1) : L(n + 1, 2)
        },
        d(e, t) {
            return L(e.getDate(), t.length)
        },
        a(e, t) {
            let n = e.getHours() / 12 >= 1 ? `pm` : `am`;
            switch (t) {
                case `a`:
                case `aa`:
                    return n.toUpperCase();
                case `aaa`:
                    return n;
                case `aaaaa`:
                    return n[0];
                default:
                    return n === `am` ? `a.m.` : `p.m.`
            }
        },
        h(e, t) {
            return L(e.getHours() % 12 || 12, t.length)
        },
        H(e, t) {
            return L(e.getHours(), t.length)
        },
        m(e, t) {
            return L(e.getMinutes(), t.length)
        },
        s(e, t) {
            return L(e.getSeconds(), t.length)
        },
        S(e, t) {
            let n = t.length,
                r = e.getMilliseconds();
            return L(Math.trunc(r * 10 ** (n - 3)), t.length)
        }
    },
    z = {
        am: `am`,
        pm: `pm`,
        midnight: `midnight`,
        noon: `noon`,
        morning: `morning`,
        afternoon: `afternoon`,
        evening: `evening`,
        night: `night`
    },
    B = {
        G: function(e, t, n) {
            let r = +(e.getFullYear() > 0);
            switch (t) {
                case `G`:
                case `GG`:
                case `GGG`:
                    return n.era(r, {
                        width: `abbreviated`
                    });
                case `GGGGG`:
                    return n.era(r, {
                        width: `narrow`
                    });
                default:
                    return n.era(r, {
                        width: `wide`
                    })
            }
        },
        y: function(e, t, n) {
            if (t === `yo`) {
                let t = e.getFullYear(),
                    r = t > 0 ? t : 1 - t;
                return n.ordinalNumber(r, {
                    unit: `year`
                })
            }
            return R.y(e, t)
        },
        Y: function(e, t, n, r) {
            let i = P(e, r),
                a = i > 0 ? i : 1 - i;
            return t === `YY` ? L(a % 100, 2) : t === `Yo` ? n.ordinalNumber(a, {
                unit: `year`
            }) : L(a, t.length)
        },
        R: function(e, t) {
            return L(u(e), t.length)
        },
        u: function(e, t) {
            return L(e.getFullYear(), t.length)
        },
        Q: function(e, t, n) {
            let r = Math.ceil((e.getMonth() + 1) / 3);
            switch (t) {
                case `Q`:
                    return String(r);
                case `QQ`:
                    return L(r, 2);
                case `Qo`:
                    return n.ordinalNumber(r, {
                        unit: `quarter`
                    });
                case `QQQ`:
                    return n.quarter(r, {
                        width: `abbreviated`,
                        context: `formatting`
                    });
                case `QQQQQ`:
                    return n.quarter(r, {
                        width: `narrow`,
                        context: `formatting`
                    });
                default:
                    return n.quarter(r, {
                        width: `wide`,
                        context: `formatting`
                    })
            }
        },
        q: function(e, t, n) {
            let r = Math.ceil((e.getMonth() + 1) / 3);
            switch (t) {
                case `q`:
                    return String(r);
                case `qq`:
                    return L(r, 2);
                case `qo`:
                    return n.ordinalNumber(r, {
                        unit: `quarter`
                    });
                case `qqq`:
                    return n.quarter(r, {
                        width: `abbreviated`,
                        context: `standalone`
                    });
                case `qqqqq`:
                    return n.quarter(r, {
                        width: `narrow`,
                        context: `standalone`
                    });
                default:
                    return n.quarter(r, {
                        width: `wide`,
                        context: `standalone`
                    })
            }
        },
        M: function(e, t, n) {
            let r = e.getMonth();
            switch (t) {
                case `M`:
                case `MM`:
                    return R.M(e, t);
                case `Mo`:
                    return n.ordinalNumber(r + 1, {
                        unit: `month`
                    });
                case `MMM`:
                    return n.month(r, {
                        width: `abbreviated`,
                        context: `formatting`
                    });
                case `MMMMM`:
                    return n.month(r, {
                        width: `narrow`,
                        context: `formatting`
                    });
                default:
                    return n.month(r, {
                        width: `wide`,
                        context: `formatting`
                    })
            }
        },
        L: function(e, t, n) {
            let r = e.getMonth();
            switch (t) {
                case `L`:
                    return String(r + 1);
                case `LL`:
                    return L(r + 1, 2);
                case `Lo`:
                    return n.ordinalNumber(r + 1, {
                        unit: `month`
                    });
                case `LLL`:
                    return n.month(r, {
                        width: `abbreviated`,
                        context: `standalone`
                    });
                case `LLLLL`:
                    return n.month(r, {
                        width: `narrow`,
                        context: `standalone`
                    });
                default:
                    return n.month(r, {
                        width: `wide`,
                        context: `standalone`
                    })
            }
        },
        w: function(e, t, n, r) {
            let i = I(e, r);
            return t === `wo` ? n.ordinalNumber(i, {
                unit: `week`
            }) : L(i, t.length)
        },
        I: function(e, t, n) {
            let r = N(e);
            return t === `Io` ? n.ordinalNumber(r, {
                unit: `week`
            }) : L(r, t.length)
        },
        d: function(e, t, n) {
            return t === `do` ? n.ordinalNumber(e.getDate(), {
                unit: `date`
            }) : R.d(e, t)
        },
        D: function(e, t, n) {
            let r = M(e);
            return t === `Do` ? n.ordinalNumber(r, {
                unit: `dayOfYear`
            }) : L(r, t.length)
        },
        E: function(e, t, n) {
            let r = e.getDay();
            switch (t) {
                case `E`:
                case `EE`:
                case `EEE`:
                    return n.day(r, {
                        width: `abbreviated`,
                        context: `formatting`
                    });
                case `EEEEE`:
                    return n.day(r, {
                        width: `narrow`,
                        context: `formatting`
                    });
                case `EEEEEE`:
                    return n.day(r, {
                        width: `short`,
                        context: `formatting`
                    });
                default:
                    return n.day(r, {
                        width: `wide`,
                        context: `formatting`
                    })
            }
        },
        e: function(e, t, n, r) {
            let i = e.getDay(),
                a = (i - r.weekStartsOn + 8) % 7 || 7;
            switch (t) {
                case `e`:
                    return String(a);
                case `ee`:
                    return L(a, 2);
                case `eo`:
                    return n.ordinalNumber(a, {
                        unit: `day`
                    });
                case `eee`:
                    return n.day(i, {
                        width: `abbreviated`,
                        context: `formatting`
                    });
                case `eeeee`:
                    return n.day(i, {
                        width: `narrow`,
                        context: `formatting`
                    });
                case `eeeeee`:
                    return n.day(i, {
                        width: `short`,
                        context: `formatting`
                    });
                default:
                    return n.day(i, {
                        width: `wide`,
                        context: `formatting`
                    })
            }
        },
        c: function(e, t, n, r) {
            let i = e.getDay(),
                a = (i - r.weekStartsOn + 8) % 7 || 7;
            switch (t) {
                case `c`:
                    return String(a);
                case `cc`:
                    return L(a, t.length);
                case `co`:
                    return n.ordinalNumber(a, {
                        unit: `day`
                    });
                case `ccc`:
                    return n.day(i, {
                        width: `abbreviated`,
                        context: `standalone`
                    });
                case `ccccc`:
                    return n.day(i, {
                        width: `narrow`,
                        context: `standalone`
                    });
                case `cccccc`:
                    return n.day(i, {
                        width: `short`,
                        context: `standalone`
                    });
                default:
                    return n.day(i, {
                        width: `wide`,
                        context: `standalone`
                    })
            }
        },
        i: function(e, t, n) {
            let r = e.getDay(),
                i = r === 0 ? 7 : r;
            switch (t) {
                case `i`:
                    return String(i);
                case `ii`:
                    return L(i, t.length);
                case `io`:
                    return n.ordinalNumber(i, {
                        unit: `day`
                    });
                case `iii`:
                    return n.day(r, {
                        width: `abbreviated`,
                        context: `formatting`
                    });
                case `iiiii`:
                    return n.day(r, {
                        width: `narrow`,
                        context: `formatting`
                    });
                case `iiiiii`:
                    return n.day(r, {
                        width: `short`,
                        context: `formatting`
                    });
                default:
                    return n.day(r, {
                        width: `wide`,
                        context: `formatting`
                    })
            }
        },
        a: function(e, t, n) {
            let r = e.getHours() / 12 >= 1 ? `pm` : `am`;
            switch (t) {
                case `a`:
                case `aa`:
                    return n.dayPeriod(r, {
                        width: `abbreviated`,
                        context: `formatting`
                    });
                case `aaa`:
                    return n.dayPeriod(r, {
                        width: `abbreviated`,
                        context: `formatting`
                    }).toLowerCase();
                case `aaaaa`:
                    return n.dayPeriod(r, {
                        width: `narrow`,
                        context: `formatting`
                    });
                default:
                    return n.dayPeriod(r, {
                        width: `wide`,
                        context: `formatting`
                    })
            }
        },
        b: function(e, t, n) {
            let r = e.getHours(),
                i;
            switch (i = r === 12 ? z.noon : r === 0 ? z.midnight : r / 12 >= 1 ? `pm` : `am`, t) {
                case `b`:
                case `bb`:
                    return n.dayPeriod(i, {
                        width: `abbreviated`,
                        context: `formatting`
                    });
                case `bbb`:
                    return n.dayPeriod(i, {
                        width: `abbreviated`,
                        context: `formatting`
                    }).toLowerCase();
                case `bbbbb`:
                    return n.dayPeriod(i, {
                        width: `narrow`,
                        context: `formatting`
                    });
                default:
                    return n.dayPeriod(i, {
                        width: `wide`,
                        context: `formatting`
                    })
            }
        },
        B: function(e, t, n) {
            let r = e.getHours(),
                i;
            switch (i = r >= 17 ? z.evening : r >= 12 ? z.afternoon : r >= 4 ? z.morning : z.night, t) {
                case `B`:
                case `BB`:
                case `BBB`:
                    return n.dayPeriod(i, {
                        width: `abbreviated`,
                        context: `formatting`
                    });
                case `BBBBB`:
                    return n.dayPeriod(i, {
                        width: `narrow`,
                        context: `formatting`
                    });
                default:
                    return n.dayPeriod(i, {
                        width: `wide`,
                        context: `formatting`
                    })
            }
        },
        h: function(e, t, n) {
            if (t === `ho`) {
                let t = e.getHours() % 12;
                return t === 0 && (t = 12), n.ordinalNumber(t, {
                    unit: `hour`
                })
            }
            return R.h(e, t)
        },
        H: function(e, t, n) {
            return t === `Ho` ? n.ordinalNumber(e.getHours(), {
                unit: `hour`
            }) : R.H(e, t)
        },
        K: function(e, t, n) {
            let r = e.getHours() % 12;
            return t === `Ko` ? n.ordinalNumber(r, {
                unit: `hour`
            }) : L(r, t.length)
        },
        k: function(e, t, n) {
            let r = e.getHours();
            return r === 0 && (r = 24), t === `ko` ? n.ordinalNumber(r, {
                unit: `hour`
            }) : L(r, t.length)
        },
        m: function(e, t, n) {
            return t === `mo` ? n.ordinalNumber(e.getMinutes(), {
                unit: `minute`
            }) : R.m(e, t)
        },
        s: function(e, t, n) {
            return t === `so` ? n.ordinalNumber(e.getSeconds(), {
                unit: `second`
            }) : R.s(e, t)
        },
        S: function(e, t) {
            return R.S(e, t)
        },
        X: function(e, t, n) {
            let r = e.getTimezoneOffset();
            if (r === 0) return `Z`;
            switch (t) {
                case `X`:
                    return H(r);
                case `XXXX`:
                case `XX`:
                    return U(r);
                default:
                    return U(r, `:`)
            }
        },
        x: function(e, t, n) {
            let r = e.getTimezoneOffset();
            switch (t) {
                case `x`:
                    return H(r);
                case `xxxx`:
                case `xx`:
                    return U(r);
                default:
                    return U(r, `:`)
            }
        },
        O: function(e, t, n) {
            let r = e.getTimezoneOffset();
            switch (t) {
                case `O`:
                case `OO`:
                case `OOO`:
                    return `GMT` + V(r, `:`);
                default:
                    return `GMT` + U(r, `:`)
            }
        },
        z: function(e, t, n) {
            let r = e.getTimezoneOffset();
            switch (t) {
                case `z`:
                case `zz`:
                case `zzz`:
                    return `GMT` + V(r, `:`);
                default:
                    return `GMT` + U(r, `:`)
            }
        },
        t: function(e, t, n) {
            return L(Math.trunc(e / 1e3), t.length)
        },
        T: function(e, t, n) {
            return L(+e, t.length)
        }
    };

function V(e, t = ``) {
    let n = e > 0 ? `-` : `+`,
        r = Math.abs(e),
        i = Math.trunc(r / 60),
        a = r % 60;
    return a === 0 ? n + String(i) : n + String(i) + t + L(a, 2)
}

function H(e, t) {
    return e % 60 == 0 ? (e > 0 ? `-` : `+`) + L(Math.abs(e) / 60, 2) : U(e, t)
}

function U(e, t = ``) {
    let n = e > 0 ? `-` : `+`,
        r = Math.abs(e),
        i = L(Math.trunc(r / 60), 2),
        a = L(r % 60, 2);
    return n + i + t + a
}
var W = (e, t) => {
        switch (e) {
            case `P`:
                return t.date({
                    width: `short`
                });
            case `PP`:
                return t.date({
                    width: `medium`
                });
            case `PPP`:
                return t.date({
                    width: `long`
                });
            default:
                return t.date({
                    width: `full`
                })
        }
    },
    G = (e, t) => {
        switch (e) {
            case `p`:
                return t.time({
                    width: `short`
                });
            case `pp`:
                return t.time({
                    width: `medium`
                });
            case `ppp`:
                return t.time({
                    width: `long`
                });
            default:
                return t.time({
                    width: `full`
                })
        }
    },
    K = {
        p: G,
        P: (e, t) => {
            let n = e.match(/(P+)(p+)?/) || [],
                r = n[1],
                i = n[2];
            if (!i) return W(e, t);
            let a;
            switch (r) {
                case `P`:
                    a = t.dateTime({
                        width: `short`
                    });
                    break;
                case `PP`:
                    a = t.dateTime({
                        width: `medium`
                    });
                    break;
                case `PPP`:
                    a = t.dateTime({
                        width: `long`
                    });
                    break;
                default:
                    a = t.dateTime({
                        width: `full`
                    })
            }
            return a.replace(`{{date}}`, W(r, t)).replace(`{{time}}`, G(i, t))
        }
    },
    q = /^D+$/,
    J = /^Y+$/,
    Y = [`D`, `DD`, `YY`, `YYYY`];

function X(e) {
    return q.test(e)
}

function Z(e) {
    return J.test(e)
}

function Q(e, t, n) {
    let r = $(e, t, n);
    if (console.warn(r), Y.includes(e)) throw RangeError(r)
}

function $(e, t, n) {
    let r = e[0] === `Y` ? `years` : `days of the month`;
    return `Use \`${e.toLowerCase()}\` instead of \`${e}\` (in \`${t}\`) for formatting ${r} to the input \`${n}\`; see: https://github.com/date-fns/date-fns/blob/master/docs/unicodeTokens.md`
}
var ee = /[yYQqMLwIdDecihHKkms]o|(\w)\1*|''|'(''|[^'])+('|$)|./g,
    te = /P+p+|P+|p+|''|'(''|[^'])+('|$)|./g,
    ne = /^'([^]*?)'?$/,
    re = /''/g,
    ie = /[a-zA-Z]/;

function ae(e, t, n) {
    let r = s(),
        i = n ?.locale ?? r.locale ?? j,
        o = n ?.firstWeekContainsDate ?? n ?.locale ?.options ?.firstWeekContainsDate ?? r.firstWeekContainsDate ?? r.locale ?.options ?.firstWeekContainsDate ?? 1,
        c = n ?.weekStartsOn ?? n ?.locale ?.options ?.weekStartsOn ?? r.weekStartsOn ?? r.locale ?.options ?.weekStartsOn ?? 0,
        l = a(e, n ?.in);
    if (!_(l)) throw RangeError(`Invalid time value`);
    let u = t.match(te).map(e => {
        let t = e[0];
        if (t === `p` || t === `P`) {
            let n = K[t];
            return n(e, i.formatLong)
        }
        return e
    }).join(``).match(ee).map(e => {
        if (e === `''`) return {
            isToken: !1,
            value: `'`
        };
        let t = e[0];
        if (t === `'`) return {
            isToken: !1,
            value: oe(e)
        };
        if (B[t]) return {
            isToken: !0,
            value: e
        };
        if (t.match(ie)) throw RangeError("Format string contains an unescaped latin alphabet character `" + t + "`");
        return {
            isToken: !1,
            value: e
        }
    });
    i.localize.preprocessor && (u = i.localize.preprocessor(l, u));
    let d = {
        firstWeekContainsDate: o,
        weekStartsOn: c,
        locale: i
    };
    return u.map(r => {
        if (!r.isToken) return r.value;
        let a = r.value;
        (!n ?.useAdditionalWeekYearTokens && Z(a) || !n ?.useAdditionalDayOfYearTokens && X(a)) && Q(a, t, String(e));
        let o = B[a[0]];
        return o(l, a, i.localize, d)
    }).join(``)
}

function oe(e) {
    let t = e.match(ne);
    return t ? t[1].replace(re, `'`) : e
}
export {
    v as a, p as c, c as d, s as f, j as i, f as l, i as m, I as n, g as o, a as p, N as r, m as s, ae as t, l as u
};