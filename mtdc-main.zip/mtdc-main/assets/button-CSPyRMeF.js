import {
    r as e
} from "./rolldown-runtime-hePW80VL.js";
import {
    n as t,
    t as n
} from "./jsx-runtime-DE3RlOCf.js";
import {
    n as r,
    t as i
} from "./dist-B-uvUq6S.js";
import {
    t as a
} from "./utils-DojpP95n.js";
var o = e(t(), 1),
    s = n(),
    c = i(`inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0`, {
        variants: {
            variant: {
                default: `bg-primary text-primary-foreground hover:bg-primary/90`,
                destructive: `bg-destructive text-destructive-foreground hover:bg-destructive/90`,
                outline: `border border-input bg-background hover:bg-accent hover:text-accent-foreground`,
                secondary: `bg-secondary text-secondary-foreground hover:bg-secondary/80`,
                ghost: `hover:bg-accent hover:text-accent-foreground`,
                link: `text-primary underline-offset-4 hover:underline`
            },
            size: {
                default: `h-10 px-4 py-2`,
                sm: `h-9 rounded-md px-3`,
                lg: `h-11 rounded-md px-8`,
                icon: `h-10 w-10`
            }
        },
        defaultVariants: {
            variant: `default`,
            size: `default`
        }
    }),
    l = o.forwardRef(({
        className: e,
        variant: t,
        size: n,
        asChild: i = !1,
        ...o
    }, l) => (0, s.jsx)(i ? r : `button`, {
        className: a(c({
            variant: t,
            size: n,
            className: e
        })),
        ref: l,
        ...o
    }));
l.displayName = `Button`;
export {
    c as n, l as t
};