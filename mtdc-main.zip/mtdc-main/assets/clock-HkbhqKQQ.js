import {
    t as e
} from "./createLucideIcon-BZ5eRbaK.js";
var t = e(`clock`, [
    [`circle`, {
        cx: `12`,
        cy: `12`,
        r: `10`,
        key: `1mglay`
    }],
    [`path`, {
        d: `M12 6v6l4 2`,
        key: `mmk7yg`
    }]
]);
export {
    t
};