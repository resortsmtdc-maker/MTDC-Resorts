var e = Object.create,
    t = Object.defineProperty,
    n = Object.getOwnPropertyDescriptor,
    r = Object.getOwnPropertyNames,
    i = Object.getPrototypeOf,
    a = Object.prototype.hasOwnProperty,
    o = (e, t) => () => (t || (e((t = {
        exports: {}
    }).exports, t), e = null), t.exports),
    s = (e, n) => {
        let r = {};
        for (var i in e) t(r, i, {
            get: e[i],
            enumerable: !0
        });
        return n || t(r, Symbol.toStringTag, {
            value: `Module`
        }), r
    },
    c = (e, i, o, s) => {
        if (i && typeof i == `object` || typeof i == `function`)
            for (var c = r(i), l = 0, u = c.length, d; l < u; l++) d = c[l], !a.call(e, d) && d !== o && t(e, d, {
                get: (e => i[e]).bind(null, d),
                enumerable: !(s = n(i, d)) || s.enumerable
            });
        return e
    },
    l = (n, r, o) => (o = n == null ? {} : e(i(n)), c(r || !n || !n.__esModule || !a.call(n, `default`) ? t(o, `default`, {
        value: n,
        enumerable: !0
    }) : o, n));
export {
    s as n, l as r, o as t
};