import {
    r as e
} from "./rolldown-runtime-hePW80VL.js";
import {
    n as t
} from "./jsx-runtime-DE3RlOCf.js";
import {
    n
} from "./utils-DojpP95n.js";
var r = e(t(), 1),
    i = Object.defineProperty,
    a = (e, t) => i(e, `name`, {
        value: t,
        configurable: !0
    });

function o(e, t) {
    if (typeof e == `function`) return e(t);
    e != null && (e.current = t)
}
a(o, `setRef`);

function s(...e) {
    return t => {
        let n = !1,
            r = e.map(e => {
                let r = o(e, t);
                return !n && typeof r == `function` && (n = !0), r
            });
        if (n) return () => {
            for (let t = 0; t < r.length; t++) {
                let n = r[t];
                typeof n == `function` ? n() : o(e[t], null)
            }
        }
    }
}
a(s, `composeRefs`);

function c(...e) {
    return r.useCallback(s(...e), e)
}
a(c, `useComposedRefs`);
var l = Object.defineProperty,
    u = (e, t) => l(e, `name`, {
        value: t,
        configurable: !0
    });

function d(e) {
    let t = r.forwardRef((t, n) => {
        let {
            children: i,
            ...a
        } = t, o = null, s = !1, l = [];
        b(i) && typeof w == `function` && (i = w(i._payload)), r.Children.forEach(i, e => {
            if (v(e)) {
                s = !0;
                let t = e,
                    n = `child` in t.props ? t.props.child : t.props.children;
                b(n) && typeof w == `function` && (n = w(n._payload)), o = h(t, n), l.push(o ?.props ?.children)
            } else l.push(e)
        }), o ? o = r.cloneElement(o, void 0, l) : !s && r.Children.count(i) === 1 && r.isValidElement(i) && (o = i);
        let u = o ? _(o) : void 0,
            d = c(n, u);
        if (!o) {
            if (i || i === 0) throw Error(s ? C(e) : S(e));
            return i
        }
        let f = g(a, o.props ?? {});
        return o.type !== r.Fragment && (f.ref = n ? d : u), r.cloneElement(o, f)
    });
    return t.displayName = `${e}.Slot`, t
}
u(d, `createSlot`);
var f = d(`Slot`),
    p = Symbol.for(`radix.slottable`);

function m(e) {
    let t = u(e => `child` in e ? e.children(e.child) : e.children, `Slottable`);
    return t.displayName = `${e}.Slottable`, t.__radixId = p, t
}
u(m, `createSlottable`);
var h = u((e, t) => {
    if (`child` in e.props) {
        let t = e.props.child;
        return r.isValidElement(t) ? r.cloneElement(t, void 0, e.props.children(t.props.children)) : null
    }
    return r.isValidElement(t) ? t : null
}, `getSlottableElementFromSlottable`);

function g(e, t) {
    let n = { ...t
    };
    for (let r in t) {
        let i = e[r],
            a = t[r];
        /^on[A-Z]/.test(r) ? i && a ? n[r] = (...e) => {
            let t = a(...e);
            return i(...e), t
        } : i && (n[r] = i) : r === `style` ? n[r] = { ...i,
            ...a
        } : r === `className` && (n[r] = [i, a].filter(Boolean).join(` `))
    }
    return { ...e,
        ...n
    }
}
u(g, `mergeProps`);

function _(e) {
    let t = Object.getOwnPropertyDescriptor(e.props, `ref`) ?.get,
        n = t && `isReactWarning` in t && t.isReactWarning;
    return n ? e.ref : (t = Object.getOwnPropertyDescriptor(e, `ref`) ?.get, n = t && `isReactWarning` in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref)
}
u(_, `getElementRef`);

function v(e) {
    return r.isValidElement(e) && typeof e.type == `function` && `__radixId` in e.type && e.type.__radixId === p
}
u(v, `isSlottable`);
var y = Symbol.for(`react.lazy`);

function b(e) {
    return typeof e == `object` && !!e && `$$typeof` in e && e.$$typeof === y && `_payload` in e && x(e._payload)
}
u(b, `isLazyComponent`);

function x(e) {
    return typeof e == `object` && !!e && `then` in e
}
u(x, `isPromiseLike`);
var S = u(e => `${e} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`, `createSlotError`),
    C = u(e => `${e} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`, `createSlottableError`),
    w = r.use,
    T = e => typeof e == `boolean` ? `${e}` : e === 0 ? `0` : e,
    E = n,
    D = (e, t) => n => {
        if (t ?.variants == null) return E(e, n ?.class, n ?.className);
        let {
            variants: r,
            defaultVariants: i
        } = t, a = Object.keys(r).map(e => {
            let t = n ?.[e],
                a = i ?.[e];
            if (t === null) return null;
            let o = T(t) || T(a);
            return r[e][o]
        }), o = n && Object.entries(n).reduce((e, t) => {
            let [n, r] = t;
            return r === void 0 || (e[n] = r), e
        }, {});
        return E(e, a, t ?.compoundVariants ?.reduce((e, t) => {
            let {
                class: n,
                className: r,
                ...a
            } = t;
            return Object.entries(a).every(e => {
                let [t, n] = e;
                return Array.isArray(n) ? n.includes({ ...i,
                    ...o
                }[t]) : { ...i,
                    ...o
                }[t] === n
            }) ? [...e, n, r] : e
        }, []), n ?.class, n ?.className)
    };
export {
    c as a, m as i, f as n, d as r, D as t
};