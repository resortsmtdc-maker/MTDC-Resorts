import {
    t as e
} from "./createLucideIcon-BZ5eRbaK.js";
var t = e(`user`, [
    [`path`, {
        d: `M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2`,
        key: `975kel`
    }],
    [`circle`, {
        cx: `12`,
        cy: `7`,
        r: `4`,
        key: `17ys0d`
    }]
]);
export {
    t
};