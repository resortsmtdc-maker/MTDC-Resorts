import {
    t as e
} from "./createLucideIcon-BZ5eRbaK.js";
var t = e(`calendar-check`, [
    [`path`, {
        d: `M8 2v4`,
        key: `1cmpym`
    }],
    [`path`, {
        d: `M16 2v4`,
        key: `4m81vk`
    }],
    [`rect`, {
        width: `18`,
        height: `18`,
        x: `3`,
        y: `4`,
        rx: `2`,
        key: `1hopcy`
    }],
    [`path`, {
        d: `M3 10h18`,
        key: `8toen8`
    }],
    [`path`, {
        d: `m9 16 2 2 4-4`,
        key: `19s6y9`
    }]
]);
export {
    t
};